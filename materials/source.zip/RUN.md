# 运行方法

Python 3.11+。在此目录执行：

```powershell
python -m pip install -r requirements.txt
$env:DEMO_READ_ONLY = "1"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

打开 http://127.0.0.1:8000/ 。首次启动读取data/jobs.jsonl。Lexmount各步操作见提交包02_开发流程。website为公开页源码，引用在线数据与材料，可用python -m http.server 8001预览。
