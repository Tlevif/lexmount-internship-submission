"""Recover technical roles missed by narrow title and verb dictionaries."""
import re
from .classification import SKILLS, hit

def recover_scope(raw, rejected):
    title=str(raw.get('title') or '')
    role=title
    duties=str(raw.get('responsibilities') or '')
    if '日常实习：' in duties:duties=duties[duties.rfind('日常实习：'):]
    m=re.search(r'(?:^|\n)\s*1[、.．)）]',duties)
    work=duties[m.start():] if m else duties
    req=str(raw.get('requirements') or '')
    required=re.split(r'加分项|加分条件|Bonus|Nice.to.have',req,flags=re.I)[0]
    # A skill before “优先” in a mixed mandatory/bonus line is still required.
    required='\n'.join(clause for clause in re.split(r'[；;。\n，,]',required) if not hit(r'优先|加分|bonus|nice.to.have',clause))
    languages=r'python|c\+\+|c语言|java\b|golang|javascript|typescript|rust|\bsql\b|编程|编码|coding|pytorch|tensorflow|shader|hlsl|glsl|verilog|数据结构|操作系统|计算机网络|JVM|Spring|深度学习|强化学习|机器学习|神经网络|自然语言处理|大模型|语言模型|Agent|智能体|CUDA|自动化测试|渗透测试|软件开发|DeepSpeed|Megatron|网络基础|TCP/IP|物理仿真|数据处理框架|可运行系统|实现能力|算法开发'
    technical_req=hit(languages+r'|代码|计算机|软件工程|算法|Kubernetes|RDMA|Faiss|DiskANN|3D几何|NLP|工程或研究能力',required)
    technical_field='requirements'
    # Interdisciplinary model roles may require model/data/engineering ability
    # without naming a programming language or a degree subject.
    if not technical_req:technical_req=hit(r'工程实现|数据与训练链路|算法基础|模型训练|数据工程|计算机体系结构|网络协议|网络架构|网络运维|分布式计算',required)
    business=hit(r'产品|Product Intern|运营|策划|营销|市场|销售|商务|人力|财务|法务|行政|商业分析|业务分析|用户研究|设计师|招聘|\bPM\b|PMO|采购|公关|编剧|创意|美术|美学|内容识别|资产管理|项目经理|项目管理|战略|经营分析|政策分析|内容策略|策略分析|增长|品牌|活动|内容供给|内容创作|内容制作|模型知识研究|行业研究|医学专家|人文训练|培训生|英语项目|技术拓展|\bHR\b|设计实习|SOP|标注|音频生成评测|语音模型评测',role)
    explicit=hit(r'开发(?!者)|研发|工程师|技术美术|Shader|渲染|程序',role)
    if business and not explicit:return rejected
    if hit(r'电气|暖通|热设计|机械|结构与材料|可靠性仿真|工业设计|灵巧手设计|动捕',role) and not hit(r'软件|算法|代码|固件|驱动',role):return rejected
    if hit(r'AI Agent 策略',role) and not hit(r'编程|Python|算法|训练|开发经验',required):return rejected
    if not technical_req and hit(r'工程师|数据管线开发',role) and hit(r'全栈.{0,10}研发|软件设计开发|工具链开发|算法开发|工程化',work):
        technical_req=hit(r'全栈.{0,10}研发|软件设计开发|工具链开发|算法开发|工程化',work)
        technical_field='responsibilities'
    if not technical_req:return rejected
    if hit(r'风格训练师|素材IE|数据支持|治理研判|风控策略|金融策略模型|钱效|策略数据',role):return rejected
    hard=hit(r'python|c\+\+|c语言|java\b|golang|javascript|typescript|rust|编程|编码|coding|pytorch|tensorflow|shader|hlsl|glsl|verilog|数据结构|操作系统|JVM|CUDA|DeepSpeed|Megatron|自然语言处理|软件开发|渗透测试|网络基础|TCP/IP|数据处理框架|物理仿真|可运行系统',required)
    actual_engineering=hit(r'代码|编程|编码|脚本|(?:研发|开发|构建|搭建|实现).{0,22}(?:框架|软件|系统|平台|引擎|流水线|管线|Pipeline|算法)|(?:模型|系统|算法).{0,15}(?:训练|开发|研发|优化)|数据仓库运维',work)
    if not hard and hit(r'标注|人工评测|主观.{0,8}评|人工.{0,8}评|测评/数据标注|策略规则|业务分析|数据统计分析|兴趣|问答场景',work) and not hit(r'代码|脚本|(?:研发|开发|实现).{0,18}(?:框架|引擎|算法)|模型训练全链路',work):return rejected
    if hit(r'投稿玩法|电商策略|支付业务策略|广告策略|机审策略|反作弊实习生',role) and not hit(r'算法研发|代码|模型训练|脚本|自动化开发',work):return rejected
    if hit(r'AI解决方案',role) and not (hit(r'编程语言|Python|Java|代码',required) and actual_engineering):return rejected
    if hit(r'音视频大模型生成评测|海外技术支持|IM Agent|语言学|交互人因|机器人物理仿真',role):return rejected
    categories=[
      ('前端开发',r'前端|React|Vue|javascript|typescript',r'前端|网页|页面组件'),
      ('后端与分布式服务',r'Java|JVM|Spring|服务端|后端|微服务',r'研发|开发|编写|设计|维护|系统|平台|服务|程序'),
      ('计算机安全',r'渗透|安全测试|漏洞|攻防|安全工程|OWASP',r'安全测试|渗透|漏洞|攻防|代码审计'),
      ('软件测试与质量工程',r'自动化测试|测试脚本|测试框架|软件测试|测试工程|质量保证',r'测试|质量|用例|缺陷'),
      ('系统与计算基础设施',r'CPU|GPU|推理引擎|推理系统|推理加速|训练框架|分布式计算|虚拟化|Linux内核|软硬件协同|芯片|计算机体系结构|资源调度|量子计算|量子电路|高性能网络',r'开发|研发|设计|实现|优化|研究|维护'),
      ('数据工程与数据库',r'数据管线|数据合成Pipeline|数据工程|数据技术|数据应用|数据平台|数据开发|数据仓库运维|向量检索系统',r'代码|脚本|管线|Pipeline|数据处理|数据分析|预处理|链路|数据库|开发|构建|优化'),
      ('人工智能与算法',r'大模型|语言模型|机器学习|深度学习|神经网络|多模态|Agent|智能体|模型|算法|AI4|AI.*研究|AI.*工程|AI.*应用|数据挖掘',r'研究|研发|开发|实现|构建|搭建|训练|优化|复现|设计|评测|评估|探索|生成|建模'),
      ('图形图像与游戏技术',r'音视频|编解码|转码|图形|渲染|特效|Shader|仿真|Unity',r'开发|算法|模型|优化|编码|编程|仿真|模拟|SDK'),
      ('网络与IT基础设施',r'IT服务|IT支持|技术支持|网络架构',r'网络|运维|故障|系统升级|终端|服务器'),
      ('软件开发',r'系统|软件|技术支持|工具|平台|项目|C\+\+',r'代码编写|软件开发|程序开发|系统.{0,12}(?:设计|开发)|开发.{0,12}(?:系统|平台|工具)|核心组件.{0,8}研发'),
    ]
    for category,subject,task in categories:
        sm=hit(subject,role+'\n'+work+('\n'+required if category=='后端与分布式服务' else ''))
        tm=hit(task,work)
        if not (sm and tm):continue
        if category=='前端开发' and not (hit(r'前端',role) or hit(r'(?:开发|实现).{0,15}(?:网页|页面组件|前端界面)',work)):continue
        if category=='后端与分布式服务' and not (hit(r'Java|后端|服务端|技术支持|运营开发|数据应用',role) or hit(r'(?:开发|研发).{0,12}(?:后端|服务端|微服务)',work)):continue
        if category=='系统与计算基础设施' and not hit(subject,role) and not hit(r'(?:开发|研发|实现|优化).{0,18}(?:推理引擎|内核|虚拟化|分布式计算|训练框架)',work) and not hit(r'计算机体系结构',required):continue
        if category=='人工智能与算法' and hit(r'音乐评测|艺术|美学|手工|人工标注|数据标注',role) and not hit(r'训练|算法|代码|自动化',work):continue
        result=dict(rejected,keep=True,category=category,version='technical-scope-review-20261028',reason='职责包含具体计算机技术任务，任职要求明确相应技术能力')
        result['skills']=[name for name,pattern in SKILLS.items() if hit(pattern,work+'\n'+req)]
        result['evidence']=[{'field':'responsibilities','text':tm.group(0)},{'field':technical_field,'text':technical_req.group(0)}]
        result['scope_recovery']={'subject':sm.group(0),'task':tm.group(0),'required_technical_skill':technical_req.group(0)}
        return result
    if hit(r'模型|研究|Agent|智能体|多模态|Benchmark|基模|自进化|神经网络|数据智多星|Algorithm Engineer',role) and hit(r'模型|算法|编程|训练|智能体|深度学习|PyTorch|TensorFlow|LLM|生成|检索|神经网络|Agentic|language models|生成|优化',work+'\n'+required):
        result=dict(rejected,keep=True,category='人工智能与算法',version='technical-scope-review-20261028',reason='计算研究岗位的交付对象与必需技术能力明确')
        result['skills']=[name for name,pattern in SKILLS.items() if hit(pattern,work+'\n'+req)]
        result['evidence']=[{'field':'title','text':role},{'field':'requirements','text':technical_req.group(0)}]
        return result
    return rejected
