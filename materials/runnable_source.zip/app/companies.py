"""Atomic, idempotent updates to the project's existing company directory."""
from __future__ import annotations

import json
import os
import re
import tempfile
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

COMPANY_FILE = Path(__file__).resolve().parents[1] / "data" / "companies.json"
SHARED_ATS_HOSTS = {"app.mokahr.com", "jobs.feishu.cn", "beisen.com", "northstarhr.com", "zhiye.com"}
VERIFICATION_RANK = {"pending": 1, "candidate": 1, "pending_verification": 1,
                     "recruitment_verified": 2, "job_verified": 3}


@contextmanager
def _directory_lock(path: Path):
    """Serialize writers across threads and processes on Windows and Unix."""
    lock_path = path.with_name(path.name + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as lock_file:
        if lock_file.seek(0, os.SEEK_END) == 0:
            lock_file.write(b"0")
            lock_file.flush()
        lock_file.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            lock_file.seek(0)
            if os.name == "nt":
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def _name_key(value: str) -> str:
    return re.sub(r"[\s\u3000（）()·._-]+", "", value).casefold()


def _url_key(value: object, *, company_site: bool = False) -> str:
    if not isinstance(value, str) or not value.strip():
        return ""
    parts = urlsplit(value.strip())
    host = parts.netloc.casefold()
    if host.startswith("www."):
        host = host[4:]
    if company_site:
        return f"site:{host}"
    if host in SHARED_ATS_HOSTS or any(host.endswith("." + domain) for domain in SHARED_ATS_HOSTS):
        # Same ATS provider serves many employers; tenant path distinguishes them.
        tenant = "/".join(segment for segment in parts.path.split("/") if segment)[:100]
        return f"ats:{host}/{tenant}"
    return f"site:{host}"


def _identity_keys(row: dict) -> tuple[set[str], set[str]]:
    names = {str(row.get("name") or row.get("company_name") or "")}
    aliases = row.get("aliases", [])
    if isinstance(aliases, str):
        aliases = [aliases]
    names.update(str(alias) for alias in aliases if alias)
    return ({_name_key(name) for name in names if name.strip()},
            {key for key in (_url_key(row.get("website"), company_site=True), _url_key(row.get("career_url"))) if key})


def upsert_companies(companies: list[dict], path: Path | None = None) -> dict:
    """Merge verified or pending discoveries into data/companies.json atomically."""
    target = path or COMPANY_FILE
    inserted = updated = unchanged = 0
    results = []
    with _directory_lock(target):
        try:
            rows = json.loads(target.read_text(encoding="utf-8")) if target.exists() else []
        except (OSError, ValueError) as exc:
            raise ValueError(f"企业目录无法读取：{exc}") from exc
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError("企业目录格式必须是对象数组")

        for candidate in companies:
            if not isinstance(candidate, dict):
                raise ValueError("企业记录必须是对象")
            name = str(candidate.get("name") or candidate.get("company_name") or "").strip()
            if not name:
                raise ValueError("企业记录缺少 name")
            incoming = dict(candidate)
            incoming.pop("company_name", None)
            incoming["name"] = name
            aliases = incoming.get("aliases", [])
            if isinstance(aliases, str):
                incoming["aliases"] = [aliases]
            incoming.setdefault("verification_status", "pending")
            if not str(incoming.get("source") or "").strip():
                raise ValueError(f"企业记录缺少来源证据：{name}")
            candidate_names, candidate_urls = _identity_keys(incoming)
            match = None
            for row in rows:
                existing_names, existing_urls = _identity_keys(row)
                if candidate_names & existing_names or candidate_urls & existing_urls:
                    match = row
                    break
            if match is None:
                rows.append(incoming)
                inserted += 1
                results.append({"name": name, "action": "inserted"})
                continue

            before = dict(match)
            # Do not discard existing evidence or downgrade an already verified entry.
            existing_name = str(match.get("name") or match.get("company_name") or "")
            if existing_name and _name_key(existing_name) != _name_key(name):
                match["aliases"] = list(dict.fromkeys([*(match.get("aliases") or []), name]))
            for key, value in incoming.items():
                if key == "name" and existing_name:
                    continue
                if value is None or value == "" or value == []:
                    continue
                if key == "verification_status" and VERIFICATION_RANK.get(value, 0) < VERIFICATION_RANK.get(match.get(key), 0):
                    continue
                if key == "aliases":
                    existing_aliases = match.get(key) or []
                    if isinstance(existing_aliases, str):
                        existing_aliases = [existing_aliases]
                    match[key] = list(dict.fromkeys([*existing_aliases, *value]))
                elif key == "discovery_evidence":
                    prior_evidence = match.get(key) or []
                    match[key] = list(dict.fromkeys([
                        json.dumps(item, ensure_ascii=False, sort_keys=True) for item in [*prior_evidence, *value]
                    ]))
                    match[key] = [json.loads(item) for item in match[key]]
                elif key == "source" and match.get(key) and match[key] != value:
                    prior = str(match[key])
                    additions = str(value)
                    match[key] = prior if additions in prior else f"{prior}; {additions}"
                else:
                    match[key] = value
            if match == before:
                unchanged += 1
                action = "unchanged"
            else:
                updated += 1
                action = "updated"
            results.append({"name": match.get("name", name), "action": action})

        target.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(rows, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, target)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)
    return {"inserted": inserted, "updated": updated, "unchanged": unchanged, "items": results}
