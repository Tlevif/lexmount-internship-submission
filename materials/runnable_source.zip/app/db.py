"""SQLite store. A failed collection never changes a job's availability."""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from .core import normalize_job

DEFAULT_DB = Path(__file__).resolve().parents[1] / "data" / "jobs.sqlite3"


def db_path() -> Path:
    return Path(os.environ.get("INTERNSHIP_DB", str(DEFAULT_DB)))


def connect() -> sqlite3.Connection:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    return con


def init_db() -> None:
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS jobs (
          id INTEGER PRIMARY KEY, fingerprint TEXT UNIQUE NOT NULL,
          company_name TEXT NOT NULL, company_website TEXT, career_url TEXT,
          title TEXT NOT NULL, category TEXT NOT NULL, category_evidence TEXT,
          cities TEXT NOT NULL, recruitment_type TEXT, raw_category TEXT,
          responsibilities TEXT, requirements TEXT, published_at TEXT,
          first_seen_at TEXT NOT NULL, last_collected_at TEXT NOT NULL,
          last_confirmed_at TEXT NOT NULL, detail_url TEXT NOT NULL,
          source_url TEXT NOT NULL, source_job_id TEXT, collection_method TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'active', raw_payload TEXT
        );
        CREATE INDEX IF NOT EXISTS jobs_company ON jobs(company_name);
        CREATE INDEX IF NOT EXISTS jobs_category ON jobs(category);
        CREATE TABLE IF NOT EXISTS discovery_state (
          key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks (
          id TEXT PRIMARY KEY, status TEXT NOT NULL, companies TEXT NOT NULL,
          started_at TEXT NOT NULL, finished_at TEXT, collected INTEGER DEFAULT 0,
          inserted INTEGER DEFAULT 0, updated INTEGER DEFAULT 0, errors TEXT DEFAULT '[]',
          paused INTEGER DEFAULT 0, task_type TEXT NOT NULL DEFAULT 'collection',
          config TEXT NOT NULL DEFAULT '{}', events TEXT NOT NULL DEFAULT '[]'
        );
        """)
        columns = {row[1] for row in con.execute("PRAGMA table_info(tasks)")}
        for name, declaration in (
            ("task_type", "TEXT NOT NULL DEFAULT 'collection'"),
            ("config", "TEXT NOT NULL DEFAULT '{}'"),
            ("events", "TEXT NOT NULL DEFAULT '[]'"),
        ):
            if name not in columns:
                con.execute(f"ALTER TABLE tasks ADD COLUMN {name} {declaration}")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def upsert_jobs(raw_jobs: list[dict]) -> dict:
    init_db()
    counts = {"collected": len(raw_jobs), "inserted": 0, "updated": 0}
    with connect() as con:
        for raw in raw_jobs:
            job = normalize_job(raw)
            stamp = now()
            scope_status = "active" if job["classification"]["keep"] and job.get("responsibilities") and job.get("requirements") else "uncertain" if job["category"]=="待核验" or not job.get("requirements") else "excluded"
            old = con.execute("SELECT id FROM jobs WHERE fingerprint=?", (job["fingerprint"],)).fetchone()
            fields = {key: job.get(key) for key in (
                "fingerprint", "company_name", "company_website", "career_url", "title", "category",
                "category_evidence", "recruitment_type", "raw_category", "responsibilities", "requirements",
                "published_at", "detail_url", "source_url", "source_job_id", "collection_method")}
            fields["cities"] = json.dumps(job["cities"], ensure_ascii=False)
            payload=dict(job.get("raw_payload") or {})
            payload["classification"]=job["classification"]
            fields["raw_payload"] = json.dumps(payload, ensure_ascii=False, default=str)
            if old:
                fields.update(last_collected_at=stamp, last_confirmed_at=stamp, status=scope_status)
                set_sql = ",".join(f"{k}=?" for k in fields if k != "fingerprint")
                con.execute(f"UPDATE jobs SET {set_sql} WHERE fingerprint=?",
                            [v for k, v in fields.items() if k != "fingerprint"] + [job["fingerprint"]])
                counts["updated"] += 1
            else:
                fields.update(first_seen_at=stamp, last_collected_at=stamp, last_confirmed_at=stamp, status=scope_status)
                columns = ",".join(fields)
                marks = ",".join("?" for _ in fields)
                con.execute(f"INSERT INTO jobs ({columns}) VALUES ({marks})", list(fields.values()))
                counts["inserted"] += 1
    return counts


def row_to_job(row: sqlite3.Row) -> dict:
    job = dict(row)
    job["cities"] = json.loads(job["cities"])
    job["raw_payload"] = json.loads(job["raw_payload"] or "null")
    job["classification"] = (job["raw_payload"] or {}).get("classification")
    job["detail_sources"] = (job["raw_payload"] or {}).get("detail_sources",[])
    job["detail_enrichment"] = (job["raw_payload"] or {}).get("detail_enrichment")
    from .category_tree import category_fields
    job.update(category_fields(job))
    return job


def query_jobs(q: str = "", city: str = "", category: str = "", company: str = "",
               recruitment_type: str = "", status: str = "active", limit: int = 50, offset: int = 0,
               direction: str = "", specialization: str = "") -> dict:
    init_db()
    clauses, args = [], []
    for field, value in (("category", category), ("company_name", company),
                         ("recruitment_type", recruitment_type), ("status", status)):
        if value:
            clauses.append(f"{field}=?")
            args.append(value)
    if city:
        clauses.append("cities LIKE ?")
        args.append(f'%"{city}"%')
    if q:
        clauses.append("(title LIKE ? OR company_name LIKE ? OR responsibilities LIKE ? OR requirements LIKE ?)")
        args.extend([f"%{q}%"] * 4)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with connect() as con:
        if direction or specialization:
            rows=con.execute("SELECT * FROM jobs"+where+" ORDER BY last_confirmed_at DESC,id DESC",args).fetchall()
            items=[row_to_job(r) for r in rows]
            items=[j for j in items if (not direction or j['category_group']==direction) and (not specialization or j['category_label']==specialization)]
            return {"total":len(items),"items":items[offset:offset+limit],"limit":limit,"offset":offset}
        total = con.execute("SELECT COUNT(*) FROM jobs" + where, args).fetchone()[0]
        rows = con.execute("SELECT * FROM jobs" + where + " ORDER BY last_confirmed_at DESC,id DESC LIMIT ? OFFSET ?",
                           args + [limit, offset]).fetchall()
    return {"total": total, "items": [row_to_job(r) for r in rows], "limit": limit, "offset": offset}
