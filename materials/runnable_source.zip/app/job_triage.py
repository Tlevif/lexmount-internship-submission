"""Conservative triage for internship postings from heterogeneous career sites.

`include` means the role can be placed in the catalog with an evidence-based
category. Clear business roles are included under their work-family category;
`review` is reserved for roles that remain unclassifiable from the available
title and responsibilities.
"""
from __future__ import annotations

import re
from .core import classify_business_role

Decision = tuple[str, str]


def _matches(pattern: str, value: str) -> bool:
    return re.search(pattern, value, flags=re.IGNORECASE) is not None


def _role(title: str) -> str:
    # The suffix after a separator normally identifies a business group.
    # Its AI/technology name must not turn a marketing job into a tech job.
    role = re.split(r"\s+[–—-]\s+", title, maxsplit=1)[0].strip()
    return role if role != title else re.split(r"实习生\s*[-–—]", title, maxsplit=1)[0].strip()


def _duties(raw: dict) -> str:
    text = str(raw.get("responsibilities") or "")
    # ByteDance often prefixes every posting with a lengthy team overview.
    # Score the actual numbered responsibilities when available.
    match = re.search(r"(?:^|\n|\s)1[、.．]", text)
    return text[match.start():] if match else text


DATA_ROLE = r"数据分析|数据科学|数据产品|数据工程|数据治理|数据挖掘|数仓|商业智能|\bBI\b"
DATA_WORK = r"指标体系|数仓|数据仓库|数据清洗|数据提取|数据查询|数据字典|数据看板|数据集|数据模型|数据加工|归因分析|实验分析|A/B\s*实验|AB\s*实验|数据可视化|数据统计与分析|数据平台"
AI_ROLE = r"(?<![a-z])AI(?![a-z])|AIGC|Agent|LLM|VLM|大模型|智能体|世界模型|模型训练|机器学习"
TECH_PRODUCT_WORK = r"模型|智能体|Agent|Prompt|评测集|数据集|推理|架构|\bAPI\b|代码|编程|脚本|训练|工作流|AI\s*Coding|算法|技术方案|功能设计|系统设计"
TECH_EVAL_WORK = r"评测工程|搭建.{0,8}评测|评测环境|自动评分|评分方法|评测集.{0,8}(?:建设|构建|设计)|Benchmark|Pipeline|Agent-as-Judge|开发.{0,8}(?:工具|能力)|数据合成|工程开发|自动化提效"
PURE_NONTECH = r"招聘|人力|\bHR\b|财务|法务|行政|采购|出纳|销售|商务拓展|公关|品牌营销|达人营销|商家运营|活动运营|市场营销|短剧制片|短剧编剧"
OPERATIONAL = r"运营|营销|市场|销售|商务|投放|内容策划|项目管理"
VISUAL_DESIGN = r"\bUI\b|\bUX\b|交互设计|视觉设计|游戏策划|3D美术|游戏美术|用户研究"


def triage_job(raw: dict) -> Decision:
    """Return `(include|review|exclude, short evidence-based reason)`.

    Caller should first establish that the posting is an internship in scope
    geographically. Missing responsibilities push ambiguous roles to review.
    """
    role = _role(str(raw.get("title") or ""))
    category = str(raw.get("raw_category") or "")
    duties = _duties(raw)
    if not role:
        return "review", "缺少岗位名称"

    # A vague AI evaluation title with only manual SOP scoring must remain
    # reviewable even when the source site labels its department as operations.
    if _matches(r"AI搜评测|人工评测|搜索评测", role) and _matches(r"SOP|人工打分|手工打分", duties):
        return "review", "评测职责以人工 SOP 打分为主，技术工作证据不足"

    business_role = classify_business_role(raw)
    if business_role:
        label, _ = business_role
        return "include", f"岗位职责已归类为{label}，不进入待审核队列"

    # A job in an AI department may still be recruitment, marketing or admin.
    # Do not scan the team suffix or generic introduction for positive terms.
    if _matches(PURE_NONTECH, role):
        return "exclude", "岗位职责名称属于非技术职能"

    data_role = _matches(DATA_ROLE, role)
    data_category = _matches(r"数据分析|数据科学|数据工程", category)
    data_work = _matches(DATA_WORK, duties)
    if data_category and len(re.findall(r"数据清洗|数据查询|数据字典|数据提取|数据统计与分析|A/B\s*实验|数仓|指标体系", duties, re.I)) >= 2:
        return "include", "原站数据分析分类与多项实际数据处理职责相互印证"
    ai_data_work = _matches(AI_ROLE, duties) and _matches(TECH_EVAL_WORK, duties)
    if (data_role or data_category) and (data_work or ai_data_work) and not _matches(r"运营|营销|市场|销售", role):
        return "include", "数据岗位名称或原站分类与实际数据工作相互印证"

    ai_role = _matches(AI_ROLE, role)
    eval_role = _matches(r"评测|评价|数据策略|自动化|训练", role)
    if ai_role and eval_role and _matches(TECH_EVAL_WORK, duties):
        # Content promotion and manual SOP rating are common false positives.
        if _matches(r"内容种草|营销|市场|招聘|短剧", role):
            return "review", "评测与非技术内容工作混合"
        return "include", "AI/模型评测或数据策略有工程建设证据"

    product_category = category.startswith("产品")
    product_role = _matches(r"产品|模型训练", role)
    if product_category and product_role and ai_role and _matches(TECH_PRODUCT_WORK, duties):
        if _matches(r"运营|营销", role) and not _matches(r"模型训练|技术产品", role):
            return "review", "AI 产品与业务运营混合"
        if _matches(r"短剧|漫剧|内容种草", role) and not _matches(r"代码|API|模型训练|推理|算法|工作流", duties):
            return "review", "内容产品的技术职责不明确"
        return "include", "AI 产品方向与具体模型或软件能力相互印证"

    # A title can understate an engineering role, but require direct creation
    # evidence rather than merely mentioning collaboration with engineering.
    if _matches(r"技术产品|推荐中台产品|开发者平台产品|数据平台产品", role) and _matches(
        r"产品架构|系统设计|平台能力|技术方案|数据平台|接口设计|\bAPI\b", duties
    ):
        return "include", "技术平台产品与平台建设职责相互印证"

    if data_role or data_category or ai_role or product_category or product_role:
        return "review", "存在技术或产品线索，但岗位工作证据不足"
    if _matches(VISUAL_DESIGN, role):
        return "review", "设计或游戏岗位需按项目边界人工判断"
    if _matches(OPERATIONAL, role) or _matches(r"职能|市场|销售|运营", category):
        return "exclude", "岗位角色主要为业务运营或非技术职能"
    return "review", "名称与职责不足以确定岗位方向"
