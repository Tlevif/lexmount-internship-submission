"""Route postings by verified computer-science tasks and requirements."""
from .classification import classify_content

def triage_job(raw:dict)->tuple[str,str]:
    result=classify_content(raw)
    if result['keep']:return 'include',result['reason']
    return ('review' if result['category']=='待核验' else 'exclude'),result['reason']
