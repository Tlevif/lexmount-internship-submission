"""Shared task records and event trail stored in the existing tasks table."""
from __future__ import annotations

import json
import uuid

from .db import connect, init_db, now


def create_discovery_task(config: dict, companies: list[str] | None = None) -> dict:
    init_db()
    task_id = uuid.uuid4().hex
    names = companies or []
    event = {"at": now(), "stage": "queued", "message": "发现任务已排队"}
    with connect() as con:
        con.execute(
            "INSERT INTO tasks(id,status,companies,started_at,task_type,config,events) VALUES(?,?,?,?,?,?,?)",
            (task_id, "queued", json.dumps(names, ensure_ascii=False), now(), "discovery",
             json.dumps(config, ensure_ascii=False), json.dumps([event], ensure_ascii=False)),
        )
    return {"id": task_id, "status": "queued", "task_type": "discovery", "companies": names}


def list_tasks(task_type: str = "", limit: int = 50) -> list[dict]:
    init_db()
    with connect() as con:
        if task_type:
            rows = con.execute("SELECT * FROM tasks WHERE task_type=? ORDER BY started_at DESC LIMIT ?",
                               (task_type, limit)).fetchall()
        else:
            rows = con.execute("SELECT * FROM tasks ORDER BY started_at DESC LIMIT ?", (limit,)).fetchall()
    return [task_to_dict(row) for row in rows]


def task_to_dict(row) -> dict:
    result = dict(row)
    for key in ("companies", "errors", "config", "events"):
        try:
            result[key] = json.loads(result.get(key) or ("{}" if key == "config" else "[]"))
        except ValueError:
            result[key] = {} if key == "config" else []
    return result


def get_discovery_strategy() -> dict:
    """Read rolling query-channel scores and expansion terms from shared SQLite."""
    init_db()
    with connect() as con:
        row = con.execute("SELECT value FROM discovery_state WHERE key='search_strategy'").fetchone()
    if row is None:
        return {}
    try:
        value = json.loads(row["value"])
        return value if isinstance(value, dict) else {}
    except ValueError:
        return {}


def save_discovery_strategy(value: dict) -> None:
    """Persist strategy metrics in the existing platform database."""
    init_db()
    with connect() as con:
        con.execute(
            "INSERT INTO discovery_state(key,value,updated_at) VALUES('search_strategy',?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
            (json.dumps(value, ensure_ascii=False), now()),
        )


def requeue_running_discovery_tasks(reason: str = "发现调度器重启，任务返回队列") -> int:
    """Requeue interrupted work after acquiring the process-wide worker lock."""
    init_db()
    changed = 0
    with connect() as con:
        rows = con.execute("SELECT id,events FROM tasks WHERE task_type='discovery' AND status='running'").fetchall()
        for row in rows:
            events = json.loads(row["events"] or "[]")
            events.append({"at": now(), "stage": "requeued", "message": reason})
            changed += con.execute("UPDATE tasks SET status='queued',paused=0,events=? WHERE id=? AND status='running'",
                                   (json.dumps(events, ensure_ascii=False), row["id"])).rowcount
    return changed


def requeue_discovery_task(task_id: str, reason: str) -> bool:
    init_db()
    with connect() as con:
        row = con.execute("SELECT events FROM tasks WHERE id=? AND task_type='discovery' AND status='running'", (task_id,)).fetchone()
        if row is None:
            return False
        events = json.loads(row["events"] or "[]")
        events.append({"at": now(), "stage": "requeued", "message": reason})
        con.execute("UPDATE tasks SET status='queued',paused=0,events=? WHERE id=?",
                    (json.dumps(events, ensure_ascii=False), task_id))
        return True


def claim_discovery_task(task_id: str) -> bool:
    init_db()
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT events FROM tasks WHERE id=? AND task_type='discovery' AND status='queued' AND paused=0",
                          (task_id,)).fetchone()
        if row is None:
            return False
        events = json.loads(row["events"] or "[]")
        events.append({"at": now(), "stage": "claimed", "message": "发现调度器已认领任务"})
        con.execute("UPDATE tasks SET status='running',events=? WHERE id=?",
                    (json.dumps(events, ensure_ascii=False), task_id))
        return True


def append_task_events(task_id: str, events: list[dict]) -> dict | None:
    init_db()
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT task_type,events FROM tasks WHERE id=?", (task_id,)).fetchone()
        if row is None:
            return None
        if row["task_type"] != "discovery":
            raise ValueError("仅发现任务接受 Agent 执行轨迹")
        trail = json.loads(row["events"] or "[]")
        for event in events:
            item = dict(event)
            item.setdefault("at", now())
            trail.append(item)
        con.execute("UPDATE tasks SET events=? WHERE id=?", (json.dumps(trail, ensure_ascii=False), task_id))
        return {"id": task_id, "events_added": len(events), "event_count": len(trail)}


def finish_discovery_task(task_id: str, status: str, summary: dict | None = None,
                          errors: list[dict] | None = None) -> dict | None:
    init_db()
    finished_at = now()
    with connect() as con:
        con.execute("BEGIN IMMEDIATE")
        row = con.execute("SELECT task_type,events FROM tasks WHERE id=?", (task_id,)).fetchone()
        if row is None:
            return None
        if row["task_type"] != "discovery":
            raise ValueError("该接口只结束发现任务")
        events = json.loads(row["events"] or "[]")
        events.append({"at": finished_at, "stage": status, "message": "发现任务已结束", "summary": summary or {}})
        def count(key: str) -> int:
            try:
                return max(0, int((summary or {}).get(key, 0) or 0))
            except (TypeError, ValueError):
                return 0

        collected, inserted, updated = (count(key) for key in ("collected", "inserted", "updated"))
        con.execute("UPDATE tasks SET status=?,finished_at=?,events=?,errors=?,collected=?,inserted=?,updated=? WHERE id=?",
                    (status, finished_at, json.dumps(events, ensure_ascii=False),
                     json.dumps(errors or [], ensure_ascii=False), collected, inserted, updated, task_id))
        return {"id": task_id, "status": status, "finished_at": finished_at}
