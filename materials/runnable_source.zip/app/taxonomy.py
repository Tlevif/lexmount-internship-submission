"""Classify technical work by its deliverable, after the existing CS scope gate."""
import re

VERSION = 'technical-taxonomy-20261028'
SOURCES = [
    {'title': 'Anthropic: research and engineering roles', 'url': 'https://www.anthropic.com/careers/jobs'},
    {'title': 'OpenAI: Applied AI, training and inference roles', 'url': 'https://openai.com/careers/search/?c=applied-ai'},
]
LLM = r'大模型|语言模型|基座模型|基模|基础模型|\bLLM\b|\bVLM\b|\bMLLM\b|\bGPT\b|多模态|生成式|生成模型|文生|图生|图像生成|视频生成|音频生成|语音生成|\bRAG\b|Agent|智能体|\bSFT\b|RLHF|\bDPO\b|Megatron|SGLang|vLLM|后训练|pre.?train|post.?train'
# Title matches express the hired role; duty matches resolve broad algorithm titles.
# Qualification-only mentions cannot move a job into a large-model category.
RULES = [
 ('大模型训练系统与算力', r'训练系统|训练框架|训练.*(?:Infra|优化)|RL\s*Infra|后训练系统|训推|算力|AI.?Infra|大模型.*(?:基础设施|基础架构)|高性能.*训练|分布式.*训练', r'训练框架|训练系统|训练平台|分布式训练|并行训练|通信优化|算力调度|训练加速|Megatron|DeepSpeed|FSDP|\bVerl\b|训练稳定性|训推系统'),
 ('大模型推理优化与部署', r'推理(?:优化|系统|框架|引擎|加速)|推理方向|Infra.*推理|模型部署|部署优化|蒸馏加速', r'推理加速|推理优化|推理引擎|推理框架|推理系统|推理性能|推理速度|推理延迟|模型部署|量化压缩|模型量化|KV.?Cache|vLLM|SGLang|TensorRT|算子优化|kernel'),
 ('大模型数据工程与合成', r'大模型.*数据|多模态.*数据|模型数据|AI数据|数据.*(?:合成|生成)|预训练数据|pre.?train.{0,8}data|LLM.{0,12}data', r'训练数据.{0,12}(?:构建|处理|清洗|合成|质量)|(?:构建|清洗|合成).{0,12}(?:训练数据|语料|数据集)|数据合成|合成数据|语料清洗|数据配比|数据流水线|数据飞轮'),
 ('大模型评测与安全', r'评测|Evaluation|安全|对齐|可解释|红队', r'评测|模型评估|benchmark|红队|越狱|安全对齐|模型安全|可解释性|幻觉检测'),
 ('大模型后训练与强化学习', r'后训练|Post.?train|强化学习|\bRL\b|\bSFT\b|对齐训练', r'后训练|post.?train|RLHF|RLAIF|\bDPO\b|\bPPO\b|\bGRPO\b|强化学习|奖励模型|偏好优化|监督微调|\bSFT\b|指令微调'),
 ('大模型预训练', r'预训练|pre.?train|Midtrain|持续训练', r'预训练|pre.?train|mid.?train|持续预训练|训练语料配比|scaling\s*law|训练缩放'),
 ('大模型基模架构与模型研究', r'基模架构|模型架构|基座模型|基座大模型|基础模型|基模|基础大模型', r'模型架构|架构创新|注意力机制|attention机制|\bMoE\b|混合专家|长上下文|长文本建模|基础模型|基座模型'),
 ('大模型多模态与生成', r'多模态|视频生成|图像生成|图片生成|音频生成|语音生成|语音交互|AudioLLM|生图|文生|图生|世界模型|3D生成|\bVLM\b', r'多模态|视频生成|图像生成|音频生成|语音生成|音频理解|文生|图生|\bDiffusion\b|扩散模型|flow.?matching|视觉语言模型|世界模型'),
 ('大模型Agent算法', r'Agent.*(?:算法|研究|策略|强化)|智能体.*(?:算法|研究)|多智能体', r'智能体.{0,16}(?:规划|决策|算法|学习)|Agent.{0,16}(?:planning|算法|规划|策略|强化)|多智能体|multi.?agent|工具学习|长程任务|自主决策'),
 ('大模型应用开发', r'应用开发|应用后端|Agent.*(?:开发|研发|工程|Harness)|Agentic\s*(?:Engineering|Infra)|智能体.*(?:开发|工程)|FDE', r'(?:开发|搭建|构建|实现).{0,22}(?:Agent|智能体|RAG|大模型应用|LLM应用|工作流)|(?:Agent|智能体|RAG|大模型应用|LLM应用).{0,22}(?:开发|工程化|集成|落地)|LangChain|LangGraph|Dify|模型API|API集成'),
 ('大模型应用算法', r'应用算法|AI搜索|AI搜算法|生成式搜索|知识问答|检索增强|领域适配|推荐大模型|大模型推荐', r'检索增强|\bRAG\b|领域适配|领域微调|知识问答|生成式搜索|prompt.{0,8}(?:优化|engineering)|优化.{0,8}prompt|提示词优化|大模型应用算法|生成式推荐|LLM4Rec|LLM.{0,12}应用'),
]
TRADITIONAL = [
 ('推荐搜索与广告算法', r'推荐|搜索|广告|排序|召回|精排|粗排|CTR|CVR'),
 ('具身智能与机器人算法', r'具身|机器人|自动驾驶|智能驾驶|感知|SLAM|路径规划|运动控制|飞控'),
 ('计算机视觉与图像算法', r'视觉|图像|图形|视频|3D|三维|OCR|目标检测|图像分割|计算摄影'),
 ('语音与音频算法', r'语音|音频|声学|ASR|TTS|说话人|声纹'),
 ('自然语言处理算法', r'自然语言|NLP|文本|语义|语言学|机器翻译|实体识别'),
 ('决策优化与数据挖掘', r'数据挖掘|运筹|因果|风控|反作弊|异常检测|预测|优化求解|决策|增长算法|博弈'),
]

def match(pattern, text):
    return re.search(pattern, text, re.I | re.ASCII)

def refine_category(raw, decision):
    title = str(raw.get('title') or '')
    # Do not let a department suffix such as “多模态团队” override a backend role.
    role = re.split(r'\s+[–—-]\s+', title, maxsplit=1)[0]
    duties = str(raw.get('responsibilities') or '')
    start = re.search(r'(?:^|\n)\s*1[、.．]', duties)
    work = duties[start.start():] if start else duties
    previous = decision['category']
    result = dict(decision, version=VERSION)
    protected = {'前端开发','客户端与移动开发','软件测试与质量工程','图形图像与游戏技术','芯片与数字系统','数据科学与计算分析'}
    is_llm = bool(match(LLM, role) or match(LLM, work) or match(r'RL\s*Infra', role))
    if is_llm and previous not in protected:
        # An ordinary backend/data role is specialized only when its actual work
        # concerns model systems, model data or application construction.
        candidates = []
        for index, (category, tp, wp) in enumerate(RULES):
            tm = match(tp, role)
            wm = match(wp, work)
            if category == '大模型训练系统与算力' and tm and not wm and not match(r'训练|训推|RL\s*Infra', role):
                continue
            if tm and (match(LLM, work) or previous == '人工智能与算法') or wm and previous == '人工智能与算法':
                score = (100 if tm else 0) + min(18, len(re.findall(wp, work, re.I | re.ASCII)))
                # “AI Infra / 推理方向” is specifically inference, not training.
                if tm and category == '大模型推理优化与部署': score += 15
                if tm and category in {'大模型后训练与强化学习','大模型预训练'}:score += 25
                if tm and category in {'大模型应用算法','大模型评测与安全','大模型数据工程与合成'}:score += 35
                if tm and category == '大模型训练系统与算力' and match(r'训练系统|训练框架|RL\s*Infra|后训练系统|训练.*Infra|训练优化',role):score += 45
                candidates.append((score, -index, category, tm, wm))
        if candidates:
            _, _, category, tm, wm = max(candidates, key=lambda x:x[:2])
            result.update(category=category, reason='按核心交付任务细分技术方向')
            result['taxonomy_evidence'] = ([{'field':'title','text':tm.group(0)}] if tm else []) + ([{'field':'responsibilities','text':wm.group(0)}] if wm else [])
            return result
        if previous == '人工智能与算法':
            if not match(LLM, role):
                for text, field in [(role,'title'),(work,'responsibilities')]:
                    for category, pattern in TRADITIONAL:
                        m=match(pattern,text)
                        if m:
                            result.update(category=category,reason='核心算法任务明确，大模型仅为可探索技术',taxonomy_evidence=[{'field':field,'text':m.group(0)}])
                            return result
            result.update(category='大模型综合算法', reason='职责涉及大模型，现有原文未明确单一研发阶段')
            return result
    if previous == '人工智能与算法':
        for text, field in [(role,'title'), (work,'responsibilities')]:
            for category, pattern in TRADITIONAL:
                m=match(pattern,text)
                if m:
                    result.update(category=category,reason='按实际算法问题与技术对象分类',taxonomy_evidence=[{'field':field,'text':m.group(0)}])
                    return result
        result.update(category='机器学习与通用算法', reason='职责为机器学习或通用算法研发')
    return result
