"""Content-first computer-science scope and role classification, version 2."""
from __future__ import annotations
import re

VERSION='cs-content-v2'
def hit(p,s):return re.search(p,s,re.I|re.ASCII)

SKILLS={
 'Python':r'\bpython\b','C/C++':r'\bc\+\+|\bc语言|\bc/c\+\+',
 'Java':r'\bjava\b','Go':r'\bgolang\b|\bgo\s*(?:语言|开发|编程)|\bgo\b(?=\s*[/、,])',
 'Rust':r'\brust\b','JavaScript/TypeScript':r'javascript|typescript|\bjs\b|\bts\b',
 'SQL':r'\bsql\b|mysql|postgres|hive\b','Linux':r'linux|unix',
 '机器学习框架':r'pytorch|tensorflow|paddle|jax\b|scikit',
 'CUDA/算子':r'cuda|triton|cutlass|算子开发','Web前端':r'react|vue|angular|html|css',
 '移动端':r'android|\bios\b|swift|flutter|kotlin|objective.c',
 '图形编程':r'shader|hlsl|glsl|opengl|vulkan|directx|渲染管线',
 '数字逻辑':r'verilog|systemverilog|\bvhdl\b|\bfpga\b',
 '分布式与数据系统':r'kubernetes|docker|redis|kafka|flink|spark|clickhouse|hadoop',
 '计算机基础':r'数据结构|操作系统|计算机网络|计算机体系结构|网络协议|编译原理',
 '模型与算法':r'机器学习|深度学习|神经网络|强化学习|自然语言处理|计算机视觉|transformer|LoRA|QLoRA',
 '软件工程':r'编程|编码|软件开发|代码开发|脚本开发|程序设计|接口开发|代码评审',
}
CS_MAJOR=r'计算机|软件工程|computer\s*science|信息安全|网络空间安全|人工智能|电子信息|自动化'
BUILD=r'(?:开发|编写|实现|搭建|构建|优化|设计|研发|建设|维护|训练|调试|部署|研究).{0,22}(?:代码|脚本|系统|软件|接口|平台|服务|算法|模型|引擎|框架|算子|数据管道|数据仓库|自动化|工作流|benchmark)|(?:代码|脚本|系统|软件|算法|模型|引擎|框架|数据管道|数仓).{0,16}(?:开发|编写|实现|训练|优化|调试|部署|研究)'
NONTECH=r'法务|法律|律师|人力|招聘|\bHR\b|财务|审计|行政|采购|出纳|客户服务|客服|商家运营|达人|制片|编剧|剪辑|文案|品牌|公关|市场|营销|销售|商务|活动|用户研究|视觉设计|交互设计|平面设计|产品设计|游戏策划|内容|业务分析|商业分析|战略分析|行业分析|运营|产品经理|产品实习|产品策划|产品助理|项目管理|项目经理'
RULES=[
 ('客户端与移动开发',r'客户端|android|\bios\b|移动端|移动开发|flutter|鸿蒙|多端|音视频终端',r'android|\bios\b|swift|kotlin|flutter|客户端|移动端'),
 ('前端开发',r'前端|大前端|front.?end|web开发',r'react|vue|angular|前端|javascript|typescript'),
 ('全栈与应用开发',r'全栈|full.?stack|product\s*engineer|应用开发|低代码开发',r'全栈|full.?stack|api|接口|应用开发|数据库'),
 ('计算机安全',r'安全(?:工程|研发|研究|开发|技术|攻防|实习)|业务安全|隐私计算|网络安全|信息安全|攻防|渗透|反入侵|漏洞|威胁情报|SDL',r'漏洞|渗透|攻防|网络安全|信息安全|安全评估|代码审计|逆向|恶意代码|CTF'),
 ('软件测试与质量工程',r'测试开发|测试工程|测试实习|软件测试|质量(?:工程|保障|研发)|自动化测试|测试技术|\bQA\b|\bSDET\b',r'测试用例|自动化测试|接口测试|软件测试|测试框架|性能测试|CI/CD|测试工具'),
 ('数据工程与数据库',r'数据(?:工程|开发|仓库|平台|研发|架构)|数据库|数仓|大数据|\bBI开发|ETL',r'数仓|数据仓库|ETL|数据管道|数据平台|数据库|flink|spark|hadoop|kafka'),
 ('图形图像与游戏技术',r'技术美术|游戏技术|三维重建|游戏UI客户端|技术动画|图形|渲染|游戏(?:引擎|开发|研发|客户端)|引擎开发|TA实习|多媒体开发',r'shader|hlsl|glsl|opengl|vulkan|渲染|游戏引擎|unreal|unity|图形学'),
 ('嵌入式与机器人软件',r'嵌入式|固件|驱动(?:开发|软件|工程|程序)|bsp|机器人软件|机器人开发|机器人系统|机器人控制|自动驾驶|智能驾驶|车载软件|SLAM|\bROS\b',r'嵌入式|固件|设备驱动|驱动开发|驱动程序|rtos|\bros\b|slam|自动驾驶|单片机'),
 ('芯片与数字系统',r'IP设计|芯片与器件设计|ESL建模|FPGA|数字(?:芯片|电路|设计)|芯片(?:设计|验证|架构)|SoC|IC设计|RTL|EDA|计算架构',r'verilog|systemverilog|vhdl|fpga|rtl|数字逻辑|计算机体系结构|EDA'),
 ('系统与计算基础设施',r'Infra|OS软件|高性能.*(?:训练|推理|网络)|推荐(?:系统|架构)|搜索系统架构|工具链软件|算力|存储工程|服务器|运维|\binfra\b|基础架构|基础设施|系统(?:研发|开发|软件)|操作系统|编译|高性能计算|分布式系统|训练系统|推理系统|推理优化|云计算|云原生|SRE|运维开发|DevOps|容器',r'linux|分布式|操作系统|编译|kubernetes|docker|cuda|推理框架|高性能计算|内核|云原生'),
 ('后端与分布式服务',r'后端|后台开发|服务端|server.?side|back.?end|Java开发|Golang|Go开发|Rust开发',r'服务端|后端|后台|分布式|微服务|数据库|接口|redis|java|golang'),
 ('人工智能与算法',r'AI模型|大模型工程|模型优化|基础模型|语音生成|视频生成|AI\s*Security|算法|机器学习|深度学习|数据挖掘|计算机视觉|自然语言|NLP|LLM|大模型.*(?:研究|研发|训练|评测)|模型.*(?:训练|推理|研究)|推荐(?:策略|研发)|计算语言|Research\s*(?:Scientist|Engineer)|Agent.*(?:算法|研发|开发|工程|训练|评测)|AI\s*Coding|后训练|Post.?train',r'机器学习|深度学习|模型训练|神经网络|强化学习|算法|pytorch|tensorflow|大模型|LLM|NLP|多模态|agent|智能体'),
 ('数据科学与计算分析',r'数据科学|数据分析|数科|数据统计|商业智能|数据策略|数据治理',r'统计|实验|数据分析|数据清洗|数据处理|因果|A/B|指标|数据集|数据查询'),
 ('网络与IT基础设施',r'网络(?:工程|研发|实习)|IT(?:支持|运维|工程)|桌面(?:支持|运维)|信息系统|网络与IT',r'网络协议|网络设备|TCP|IP协议|linux|windows|网络架构|网络运维|交换机|路由器'),
 ('软件开发',r'FDE|程序类|SDK开发|Agent\s*Development|软件(?:工程|开发|研发)|研发(?:工程师|实习)|开发(?:工程师|实习)|程序员|开发实习|工程开发|developer|software\s*engineer',r'代码|编程|软件|接口|系统|算法|架构|python|java|c\+\+'),
]

def _classify_scope(raw:dict)->dict:
    title=str(raw.get('title') or '').strip()
    role=re.split(r'\s+[–—-]\s+',title,maxsplit=1)[0]
    duties=str(raw.get('responsibilities') or '')
    # Remove a generic employer/team introduction before numbered duties.
    start=re.search(r'(?:^|\n)\s*1[、.．]',duties)
    work=duties[start.start():] if start else duties
    req=str(raw.get('requirements') or '')
    text=work+'\n'+req
    skills=[label for label,p in SKILLS.items() if hit(p,text)]
    evidence=[]
    def decision(keep,category,reason):
        return {'version':VERSION,'keep':keep,'category':category,'reason':reason,'skills':skills,'evidence':evidence}
    if not title:return decision(False,'待核验','缺少岗位名称')
    build=hit(BUILD,work)
    # Computer use, AI tool use, Office and Excel alone are not CS requirements.
    concrete=bool(skills)
    req_cs=bool(hit(CS_MAJOR,req))
    if build:evidence.append({'field':'responsibilities','text':build.group(0)})
    for k,p in SKILLS.items():
        m=hit(p,req) or hit(p,work)
        if m and len(evidence)<5:evidence.append({'field':'requirements' if hit(p,req) else 'responsibilities','skill':k,'text':m.group(0)})
    # Business job families require actual coding work and a required technical skill.
    business_title=hit(r'运营|产品|营销|策划|客服|设计师|业务分析|商业分析',role)
    engineer_title=hit(r'开发|研发|工程师|前端|后端|全栈|技术美术|Shader|渲染|数字.*设计|芯片.*设计|IP设计',role)
    required=re.split(r'加分项|加分条件|Bonus|Nice.to.have',req,flags=re.I)[0]
    required='\n'.join(x for x in required.split('\n') if '优先' not in x and '加分' not in x)
    coding_required=hit(r'编程|编码|coding|代码|python|c\+\+|java\b|golang|pytorch|tensorflow|数据结构|操作系统',required)
    engineering_work=hit(r'(?:开发|编写|实现|研发|维护|构建).{0,20}(?:代码|脚本|软件|系统|网页|服务|接口|框架|管道|工具)|(?:代码|脚本|软件|服务端|后端|接口|框架|数据管道).{0,12}(?:开发|编写|实现|研发|维护)',work)
    if business_title and not engineer_title and not (coding_required and engineering_work):
        return decision(False,'非计算机岗位','核心岗位为产品、运营、设计或业务职能，未要求承担计算机工程开发')
    # Resolve explicit engineering roles before business vocabulary in team names.
    for category,role_pattern,work_pattern in RULES:
        m=hit(role_pattern,role)
        if not m:continue
        direct=bool(hit(work_pattern,text))
        if category=='数据科学与计算分析':
            programming=hit(r'python|\bsql\b|\bR语言\b|pandas|spark|统计建模|机器学习',req)
            if not programming or not hit(r'数据|建模|实验|因果|A/B',work):continue
        if category=='芯片与数字系统' and not hit(r'verilog|systemverilog|vhdl|fpga|rtl|EDA|计算机体系结构',text):continue
        # A PM, commercial or content role must have actual engineering work.
        business=hit(NONTECH,role)
        explicit_engineer=hit(r'开发|研发|工程师|算法|infra|engineer|数据科学|数科|数据分析|技术美术|计算语言|渲染|编译|前端|后端|全栈|客户端|软件|系统|安全|基础架构|Infra',role)
        if business and not explicit_engineer and not (build and concrete and req_cs):continue
        if category=='全栈与应用开发' and hit(r'前端实现|前端架构|前端开发',work) and hit(r'javascript|typescript|react|vue',req) and not hit(r'后端|服务端|数据库',work):
            return decision(True,'前端开发','标题为全栈，实际职责和要求明确侧重前端开发')
        technical_task=hit(r'开发|实现|研发|编码|编写|设计|构建|优化|研究|测试|维护|训练|调试|部署|评测',work)
        if (direct or (technical_task and explicit_engineer and (concrete or req_cs))) and (concrete or req_cs or (build and explicit_engineer)):
            evidence.insert(0,{'field':'title','text':m.group(0)})
            return decision(True,category,'岗位名称、实际技术任务与要求相互印证')
    # A vague operations/product title can conceal coding work: require both.
    required=re.split(r'加分项|加分条件|Bonus|Nice.to.have',req,flags=re.I)[0]
    required='\n'.join(x for x in required.split('\n') if '优先' not in x and '加分' not in x)
    mandatory=hit(r'编程|编码|coding|开发经验|代码|python|c\+\+|java\b|golang|pytorch|tensorflow|数据结构|计算机网络|操作系统|软件工程',required)
    engineering=hit(r'(?:开发|编写|实现|研发|维护).{0,20}(?:代码|脚本|软件|系统|服务端|后端|接口|框架|管道|工具)|(?:代码|脚本|软件|服务端|后端|接口|框架|数据管道).{0,12}(?:开发|编写|实现|研发|维护)',work)
    if engineering and concrete and mandatory and hit(r'网页工具|web|全栈|内部平台|工具开发',work) and not hit(r'底层|操作系统|内核',work):
        return decision(True,'全栈与应用开发','实际职责为工具或应用开发，任职要求包含编程能力')
    if build and concrete and mandatory and (not hit(NONTECH+'|语言学|人文|美学|美术',role) or engineering):
        ranked=sorted(RULES,key=lambda x:len(re.findall(x[2],work,re.I|re.ASCII)),reverse=True)
        for category,_,work_pattern in ranked:
            if category in {'软件测试与质量工程','数据工程与数据库','图形图像与游戏技术','系统与计算基础设施','后端与分布式服务','前端开发','人工智能与算法','嵌入式与机器人软件'} and hit(work_pattern,work):
                hard=hit(r'编程|编码|开发经验|代码|python|c\+\+|java\b|golang|pytorch|tensorflow|数据结构|计算机网络|操作系统|软件工程|计算机相关|计算机科学',req)
                if hard:return decision(True,category,'岗位虽含业务词，职责含工程建设，要求含计算机或编程能力')
    if hit(NONTECH,role):return decision(False,'非计算机岗位','核心职责为业务、内容或职能工作，缺少计算机工程要求')
    if hit(r'机械|结构|材料|光学|热设计|可靠性|电气|射频|天线|电源|电路|硬件|医学|临床|生物|化学',role):
        return decision(False,'非计算机岗位','核心方向为其他学科，未核验到计算机研发任务与要求')
    return decision(False,'待核验','现有岗位名称、职责及要求不足以确认计算机技术工作')

def classify_content(raw:dict)->dict:
    from .taxonomy import refine_category
    review=(raw.get('raw_payload') or {}).get('scope_review')
    if review:
        return dict(version='technical-scope-review-20261028', keep=review['keep'], category=review['category'], reason=review['reason'], skills=review.get('skills',[]), evidence=review.get('evidence',[]), reviewed=True)
    if raw.get('company_name')=='DeepSeek' and raw.get('title')=='Agent Harness 团队':
        return dict(version='technical-scope-review-20261028',keep=False,category='综合招聘入口',reason='团队入口已由具体岗位覆盖',skills=[],evidence=[])
    decision = _classify_scope(raw)
    if not decision['keep']:
        from .scope_recovery import recover_scope
        decision = recover_scope(raw, decision)
    if decision['keep']:
        decision = refine_category(raw, decision)
    return decision
