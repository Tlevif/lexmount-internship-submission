"""Normalization, categorization and identity for official internship listings."""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

TARGET_CITIES = ("北京", "上海", "广州", "深圳", "杭州")
from .classification import classify_content


def classify_business_role(raw: dict) -> tuple[str, str] | None:
    result=classify_content(raw)
    return (result['category'],result['reason']) if result['category']=='非计算机岗位' else None


def normalize_cities(value: object) -> list[str]:
    if isinstance(value, str):
        values = re.split(r"[,，/、;；|\s]+", value)
    elif isinstance(value, list):
        values = [str(v) for v in value]
    else:
        values = []
    found: list[str] = []
    for item in values:
        for city in TARGET_CITIES:
            if city in item and city not in found:
                found.append(city)
    return found


def classify(raw: dict) -> tuple[str, str]:
    result=classify_content(raw)
    return result['category'],result['reason']


def canonical_url(url: str) -> str:
    split = urlsplit(url.strip())
    pairs = [(k, v) for k, v in parse_qsl(split.query, keep_blank_values=True)
             if not k.lower().startswith("utm_")]
    return urlunsplit((split.scheme.lower(), split.netloc.lower(), split.path.rstrip("/"), urlencode(sorted(pairs)), ""))


def fingerprint(raw: dict) -> str:
    company = re.sub(r"\s+", "", str(raw["company_name"])).lower()
    source_id = str(raw.get("source_job_id") or "").strip()
    if source_id:
        key = f"id|{company}|{source_id}"
    elif raw.get("detail_url"):
        key = f"url|{company}|{canonical_url(str(raw['detail_url']))}"
    else:
        title = re.sub(r"\s+", "", str(raw["title"])).lower()
        cities = ",".join(sorted(normalize_cities(raw.get("cities"))))
        key = f"fields|{company}|{title}|{cities}|{raw.get('recruitment_type') or ''}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def normalize_job(raw: dict) -> dict:
    for field in ("company_name", "title", "detail_url", "source_url", "collection_method"):
        if not str(raw.get(field) or "").strip():
            raise ValueError(f"缺少字段：{field}")
    decision = classify_content(raw)
    category, evidence = decision['category'], decision['reason']
    return {**raw, "cities": normalize_cities(raw.get("cities")), "category": category,
            "category_evidence": evidence, "classification": decision, "fingerprint": fingerprint(raw),
            "published_at": raw.get("published_at") or None,
            "recruitment_type": raw.get("recruitment_type") or "未知"}
