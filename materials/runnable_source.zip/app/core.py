"""Normalization, categorization and identity for official internship listings."""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

TARGET_CITIES = ("北京", "上海", "广州", "深圳", "杭州")
CATEGORIES = {
    "人工智能与算法": ("大模型", "机器学习", "深度学习", "算法", "人工智能", "ai", "世界模型", "推荐策略", "自然语言", "nlp", "计算机视觉", "cv", "生成式"),
    "数据": ("数据科学", "数据分析", "数据工程", "数据库", "数仓", "大数据"),
    "后端与基础架构": ("后端", "服务端", "基础架构", "云计算", "分布式", "java", "golang", "go开发", "python开发"),
    "前端与客户端": ("前端", "客户端", "移动端", "android", "ios", "web开发"),
    "安全与测试": ("网络安全", "安全研发", "测试开发", "软件测试", "质量保障"),
    "嵌入式与自动驾驶": ("嵌入式", "自动驾驶", "智能驾驶", "车载", "固件"),
    "硬件与芯片": ("芯片", "SoC", "硬件开发", "硬件测试", "硬件工程"),
    "软件工程": ("软件工程", "软件开发", "运营开发", "游戏引擎", "全栈", "研发工程师", "开发工程师", "程序员"),
}

BUSINESS_ROLES = {
    "活动策划": r"活动|赛事|会务.{0,3}(?:策划|运营|执行)|(?:策划|运营|执行).{0,3}活动",
    "营销": r"营销|市场|品牌|投放|广告|公关|传播|推广|达人",
    "销售": r"销售|商务|业务拓展|客户开发|渠道拓展|合作伙伴|区域合作|渠道合作|\bBD\b",
    "运营": r"运营|用户增长|增长运营|用户运营|社区运营|商家运营|策略运营|资源管理",
    "游戏策划": r"游戏策划|关卡策划|数值策划",
    "项目管理": r"项目管理|项目经理|项目助理",
    "设计": r"设计|\bUI\b|\bUX\b|交互",
    "业务分析": r"经营分析|商业分析|行业分析|战略分析",
    "内容策划": r"内容|编辑|文案|编剧|短视频|新媒体|制片|影视|剧本",
    "产品经理": r"产品|产品经理|产品实习|产品助理|产品策划|产品岗",
    "客户服务": r"客服|客户服务|客户支持",
    "人力资源": r"招聘|人力|人才|HR(?:BP|实习生)?",
    "财务": r"财务|会计|审计|出纳",
    "法务": r"法务|法律顾问",
    "行政与采购": r"行政|采购|助理",
}

TECHNICAL_PRODUCT_WORK = r"(?:开发|编写|实现|训练|部署).{0,12}(?:代码|脚本|算法|模型|数据管道|自动化工具|评测工具)|(?:代码|脚本|算法|模型|数据管道).{0,12}(?:开发|编写|实现|训练|部署)"
TECHNICAL_ROLE = r"运营开发|算法|数据科学|数据分析|机器学习|深度学习|研发|前端|后端|客户端|服务端|测试开发|软件测试|自动驾驶|嵌入式|SoC|系统设计|工程师|工程实习生|芯片.{0,12}(?:设计|工程|研发|开发|测试)|(?:设计|工程|研发|开发|测试).{0,12}芯片|硬件(?:开发|测试|工程|设计|研发)|(?:全栈|大前端|(?:前端|后端|客户端|服务端|软件|应用|硬件|芯片)?开发(?:工程师|实习生|工程|岗|$|[（(]))"


def classify_business_role(raw: dict) -> tuple[str, str] | None:
    """Classify clear business roles from their title, then use duties as fallback."""
    title = str(raw.get("title") or "")
    role = re.split(r"\s+[–—-]\s+", title, maxsplit=1)[0].strip()
    if role == title:
        role = re.split(r"实习生\s*[-–—]", title, maxsplit=1)[0].strip()
    duties = str(raw.get("responsibilities") or "")
    raw_category = str(raw.get("raw_category") or "")

    # A technical role must not be reclassified because its team or duties
    # mention content, campaigns, or operations.
    if re.search(TECHNICAL_ROLE, role, re.I):
        return None

    for label, pattern in BUSINESS_ROLES.items():
        if label == "产品经理":
            continue
        if re.search(pattern, role, re.I):
            return label, f"岗位名称归类：{label}"

    if re.search(r"产品", role, re.I):
        if re.search(TECHNICAL_PRODUCT_WORK, duties, re.I):
            return None
        return "产品经理", "岗位名称归类：产品经理"

    # Use specific work signals only when the title is generic (for example,
    # “实习生” or “策划”); broad terms such as “内容” alone are too noisy.
    if not (re.fullmatch(r"(?:实习生|暑期实习生|校招|策划|项目|项目助理|助理|专员)", role)
            or (role.endswith("实习生") and not re.search(TECHNICAL_ROLE, role, re.I))):
        return None
    duty_signals = (
        ("活动策划", r"(?:策划|组织|执行|复盘).{0,12}(?:活动|赛事|会务)|(?:活动|赛事|会务).{0,12}(?:策划|组织|执行|复盘)"),
        ("内容策划", r"撰写.{0,8}(?:文案|脚本|稿件)|内容(?:策划|策略|运营|制作|审核|创作)|短视频|剧本|选题|稿件编辑"),
        ("营销", r"品牌推广|市场推广|营销活动|广告投放|公关传播|达人合作"),
        ("销售", r"开发客户|销售转化|商务拓展|渠道拓展|客户签约"),
        ("运营", r"用户运营|商家运营|社群运营|用户增长|数据运营|任务分发|运营活动|运营策略"),
        ("产品经理", r"需求调研|产品需求|需求文档|产品规划|产品方案|产品迭代|PRD"),
        ("项目管理", r"项目排期|项目进度|跨团队协同|项目交付|项目复盘"),
        ("客户服务", r"客户咨询|客户支持|工单处理|售后服务"),
        ("人力资源", r"简历筛选|面试安排|招聘流程|员工入离职"),
        ("财务", r"报销审核|账务处理|财务报表|发票管理"),
        ("法务", r"合同审核|法律检索|合规审查"),
        ("行政与采购", r"办公采购|供应商管理|行政支持|会议安排"),
    )
    for label, pattern in duty_signals:
        if re.search(pattern, duties, re.I):
            return label, f"岗位职责内容归类：{label}"
    for label, pattern in BUSINESS_ROLES.items():
        if re.search(pattern, raw_category, re.I):
            return label, f"原站细分岗位分类：{label}"
    return None


def normalize_cities(value: object) -> list[str]:
    if isinstance(value, str):
        values = re.split(r"[,，/、;；|\s]+", value)
    elif isinstance(value, list):
        values = [str(v) for v in value]
    else:
        values = []
    found: list[str] = []
    for item in values:
        for city in TARGET_CITIES:
            if city in item and city not in found:
                found.append(city)
    return found


def classify(raw: dict) -> tuple[str, str]:
    business_role = classify_business_role(raw)
    if business_role:
        return business_role
    fields = [("原站分类", str(raw.get("raw_category") or "")),
              ("岗位名称", str(raw.get("title") or "")),
              ("岗位内容", " ".join(str(raw.get(k) or "") for k in ("responsibilities", "requirements")))]
    for origin, value in fields:
        low = value.lower()
        for category, terms in CATEGORIES.items():
            match = next((term for term in terms if term in low), None)
            if match:
                return category, f"{origin}关键词：{match}"
    return "待审核", "未匹配规则"


def canonical_url(url: str) -> str:
    split = urlsplit(url.strip())
    pairs = [(k, v) for k, v in parse_qsl(split.query, keep_blank_values=True)
             if not k.lower().startswith("utm_")]
    return urlunsplit((split.scheme.lower(), split.netloc.lower(), split.path.rstrip("/"), urlencode(sorted(pairs)), ""))


def fingerprint(raw: dict) -> str:
    company = re.sub(r"\s+", "", str(raw["company_name"])).lower()
    source_id = str(raw.get("source_job_id") or "").strip()
    if source_id:
        key = f"id|{company}|{source_id}"
    elif raw.get("detail_url"):
        key = f"url|{company}|{canonical_url(str(raw['detail_url']))}"
    else:
        title = re.sub(r"\s+", "", str(raw["title"])).lower()
        cities = ",".join(sorted(normalize_cities(raw.get("cities"))))
        key = f"fields|{company}|{title}|{cities}|{raw.get('recruitment_type') or ''}"
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def normalize_job(raw: dict) -> dict:
    for field in ("company_name", "title", "detail_url", "source_url", "collection_method"):
        if not str(raw.get(field) or "").strip():
            raise ValueError(f"缺少字段：{field}")
    category, evidence = classify(raw)
    return {**raw, "cities": normalize_cities(raw.get("cities")), "category": category,
            "category_evidence": evidence, "fingerprint": fingerprint(raw),
            "published_at": raw.get("published_at") or None,
            "recruitment_type": raw.get("recruitment_type") or "未知"}
