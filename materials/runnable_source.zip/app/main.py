"""FastAPI search and collection control."""
from __future__ import annotations

import importlib
import json
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .db import connect, init_db, now, query_jobs, row_to_job, upsert_jobs
from .companies import upsert_companies
from .tasks import (append_task_events, claim_discovery_task, create_discovery_task,
                    finish_discovery_task, list_tasks, task_to_dict)

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "sites"
FRONTEND = ROOT / "frontend"
app = FastAPI(title="企业实习岗位聚合平台", version="0.1.0")
executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="collector")
running: set[str] = set()
run_lock = threading.Lock()


@app.on_event("startup")
def startup() -> None:
    init_db()
    # Render's free demo uses an ephemeral database. Rebuild its read-only
    # snapshot from the checked-in public job data whenever the instance starts.
    with connect() as con:
        job_count = con.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
    seed_file = ROOT / "data" / "jobs.jsonl"
    if os.environ.get("DEMO_READ_ONLY") == "1" and job_count == 0 and seed_file.exists():
        seed_jobs = []
        for line in seed_file.read_text(encoding="utf-8").split("\n"):
            if line.strip():
                job = json.loads(line)
                seed_jobs.append(job)
        upsert_jobs(seed_jobs)
    # Discovery work runs in the separately locked discovery.worker process;
    # only that worker may recover its running tasks after acquiring the lock.
    # Other in-memory collection work cannot be resumed after this process exits.
    with connect() as con:
        rows = con.execute("SELECT id,errors,task_type,events FROM tasks WHERE status='running'").fetchall()
        for row in rows:
            if row["task_type"] == "discovery":
                continue
            errors = json.loads(row["errors"])
            errors.append({"company": "task", "error": "服务重启，任务已中断"})
            con.execute("UPDATE tasks SET status='failed',finished_at=?,errors=? WHERE id=?",
                        (now(), json.dumps(errors, ensure_ascii=False), row["id"]))


@app.middleware("http")
async def demo_read_only(request, call_next):
    if (request.method in {"POST", "PUT", "PATCH", "DELETE"}
            and os.environ.get("DEMO_READ_ONLY") == "1"):
        return JSONResponse(status_code=405, content={"detail": "演示站只开放浏览和查询"})
    return await call_next(request)


@app.get("/api/jobs")
def jobs(q: str = "", city: str = "", category: str = "", company: str = "",
         recruitment_type: str = "", status: str = "active",
         limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
         direction: str = "", specialization: str = "") -> dict:
    return query_jobs(q, city, category, company, recruitment_type, status, limit, offset,direction,specialization)


@app.get("/api/jobs/export.csv")
def export_jobs(q: str = "", city: str = "", category: str = "", company: str = "",
                recruitment_type: str = "", status: str = "active", direction: str = "", specialization: str = ""):
    """Export the same unified query result as UTF-8 CSV for spreadsheet tools."""
    import csv
    import io

    def rows():
        buffer = io.StringIO(newline="")
        writer = csv.writer(buffer)
        writer.writerow(["企业", "岗位", "分类", "城市", "招聘类型", "发布时间", "岗位链接", "来源页", "最近确认"])
        yield "\ufeff" + buffer.getvalue()
        offset = 0
        while True:
            page = query_jobs(q, city, category, company, recruitment_type, status, 200, offset,direction,specialization)
            if not page["items"]:
                break
            buffer.seek(0)
            buffer.truncate(0)
            for item in page["items"]:
                writer.writerow([item.get("company_name"), item.get("title"), ' / '.join(item['category_path']),
                                 "、".join(item.get("cities") or []), item.get("recruitment_type"),
                                 item.get("published_at") or "", item.get("detail_url"), item.get("source_url"),
                                 item.get("last_confirmed_at")])
            yield buffer.getvalue()
            offset += len(page["items"])
            if offset >= page["total"]:
                break

    return StreamingResponse(rows(), media_type="text/csv; charset=utf-8",
                             headers={"Content-Disposition": "attachment; filename=jobs.csv"})


@app.get("/api/jobs/{job_id}")
def job_detail(job_id: int) -> dict:
    init_db()
    with connect() as con:
        row = con.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "岗位不存在")
    return row_to_job(row)


@app.get("/api/companies")
def companies() -> list[dict]:
    init_db()
    data: dict[str, dict] = {}
    source = ROOT / "data" / "companies.json"
    if source.exists():
        try:
            loaded = json.loads(source.read_text(encoding="utf-8"))
            for row in loaded:
                name = row.get("name") or row.get("company_name")
                if name:
                    data[name] = {**row, "name": name, "website": row.get("website"),
                                  "career_url": row.get("career_url"),
                                  "verification_status": row.get("verification_status"), "job_count": 0}
        except (ValueError, OSError):
            pass
    with connect() as con:
        rows = con.execute("SELECT company_name,MAX(company_website) website,MAX(career_url) career_url,COUNT(*) count FROM jobs WHERE status='active' GROUP BY company_name").fetchall()
    for row in rows:
        entry = data.setdefault(row["company_name"], {"name": row["company_name"], "verification_status": "job_verified"})
        entry.update(website=row["website"] or entry.get("website"), career_url=row["career_url"] or entry.get("career_url"), job_count=row["count"])
    return sorted(data.values(), key=lambda x: (-x.get("job_count", 0), x["name"]))


@app.get("/api/stats")
def stats() -> dict:
    init_db()
    company_file = ROOT / "data" / "companies.json"
    company_rows = json.loads(company_file.read_text(encoding="utf-8")) if company_file.exists() else []
    company_names = {
        row.get("name") or row.get("company_name")
        for row in company_rows
        if isinstance(row, dict) and (row.get("name") or row.get("company_name"))
    }
    verified_companies = len({
        row.get("name") or row.get("company_name")
        for row in company_rows
        if row.get("verification_status") in {"job_verified", "recruitment_verified"}
        and (row.get("name") or row.get("company_name"))
    })
    with connect() as con:
        total = con.execute("SELECT COUNT(*) FROM jobs WHERE status='active'").fetchone()[0]
        active_employers = {row[0] for row in con.execute("SELECT DISTINCT company_name FROM jobs WHERE status='active'")}
        by_category = [dict(r) for r in con.execute("SELECT category,COUNT(*) count FROM jobs WHERE status='active' GROUP BY category ORDER BY count DESC")]
        by_city = [dict(r) for r in con.execute("SELECT value city,COUNT(*) count FROM jobs,json_each(jobs.cities) WHERE status='active' GROUP BY value ORDER BY count DESC")]
        tasks = con.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
        from .category_tree import tree_counts
        category_tree=tree_counts([dict(r) for r in con.execute("SELECT title,responsibilities,category FROM jobs WHERE status='active'")])
    return {"jobs": total, "companies": len(company_names | active_employers),
            "active_employers": len(active_employers), "verified_companies": verified_companies,
            "by_category": by_category,
            "category_tree": category_tree,
            "by_city": by_city, "tasks": tasks}


class ImportPayload(BaseModel):
    jobs: list[dict] = Field(default_factory=list, max_length=1000)


@app.post("/api/jobs/import")
def import_jobs(payload: ImportPayload) -> dict:
    try:
        return upsert_jobs(payload.jobs)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


class CompanyImportPayload(BaseModel):
    companies: list[dict] = Field(default_factory=list, max_length=1000)


@app.post("/api/companies/upsert")
def companies_upsert(payload: CompanyImportPayload) -> dict:
    try:
        return upsert_companies(payload.companies)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc


class DiscoveryTaskPayload(BaseModel):
    config: dict = Field(default_factory=dict)
    companies: list[str] = Field(default_factory=list)


@app.post("/api/discovery/tasks")
def create_discovery(payload: DiscoveryTaskPayload) -> dict:
    return create_discovery_task(payload.config, payload.companies)


@app.get("/api/tasks")
def tasks_list(task_type: str = "", limit: int = Query(50, ge=1, le=200)) -> list[dict]:
    return list_tasks(task_type, limit)


@app.post("/api/tasks/{task_id}/claim")
def claim_task(task_id: str) -> dict:
    if not claim_discovery_task(task_id):
        raise HTTPException(409, "发现任务不存在、已认领或未处于排队状态")
    return {"id": task_id, "status": "running"}


class TaskEventsPayload(BaseModel):
    events: list[dict] = Field(default_factory=list, max_length=500)


@app.post("/api/tasks/{task_id}/events")
def add_task_events(task_id: str, payload: TaskEventsPayload) -> dict:
    try:
        result = append_task_events(task_id, payload.events)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    if result is None:
        raise HTTPException(404, "任务不存在")
    return result


class FinishDiscoveryPayload(BaseModel):
    status: str
    summary: dict = Field(default_factory=dict)
    errors: list[dict] = Field(default_factory=list)


@app.post("/api/tasks/{task_id}/finish")
def finish_task(task_id: str, payload: FinishDiscoveryPayload) -> dict:
    if payload.status not in {"completed", "completed_with_errors", "failed", "cancelled"}:
        raise HTTPException(422, "不支持的任务结束状态")
    try:
        result = finish_discovery_task(task_id, payload.status, payload.summary, payload.errors)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    if result is None:
        raise HTTPException(404, "任务不存在")
    return result


class CollectPayload(BaseModel):
    companies: list[str] = Field(default_factory=list)


def available_configs() -> dict[str, Path]:
    configs = {}
    for path in CONFIG_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if data.get("verified_for_collection") is not True:
                continue
            name = data.get("name") or data.get("company_name") or path.stem
            configs[name] = path
        except (ValueError, OSError):
            continue
    return configs


def _run(task_id: str, names: list[str]) -> None:
    errors: list[dict] = []
    totals = {"collected": 0, "inserted": 0, "updated": 0}
    try:
        collector = importlib.import_module("collector")
        for name in names:
            with connect() as con:
                paused = con.execute("SELECT paused FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
            while paused:
                threading.Event().wait(0.5)
                with connect() as con:
                    paused = con.execute("SELECT paused FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
            path = available_configs()[name]
            config = json.loads(path.read_text(encoding="utf-8"))
            for attempt in range(1, 3):
                try:
                    raw = collector.collect_company(config)
                    result = upsert_jobs(raw)
                    for key in totals:
                        totals[key] += result[key]
                    break
                except Exception as exc:
                    if attempt == 2:
                        errors.append({"company": name, "error": str(exc)[:500], "attempts": attempt})
                    else:
                        time.sleep(1)
            with connect() as con:
                con.execute("UPDATE tasks SET collected=?,inserted=?,updated=?,errors=? WHERE id=?",
                            (*totals.values(), json.dumps(errors, ensure_ascii=False), task_id))
        status = "completed_with_errors" if errors else "completed"
    except Exception as exc:
        errors.append({"company": "task", "error": str(exc)[:500]})
        status = "failed"
    finally:
        with connect() as con:
            con.execute("UPDATE tasks SET status=?,finished_at=?,errors=? WHERE id=?",
                        (status, now(), json.dumps(errors, ensure_ascii=False), task_id))
        with run_lock:
            for name in names:
                running.discard(name)


@app.post("/api/collect")
def collect(payload: CollectPayload) -> dict:
    configs = available_configs()
    names = payload.companies or list(configs)
    if not names:
        raise HTTPException(400, "没有可运行的网站配置")
    missing = [name for name in names if name not in configs]
    if missing:
        raise HTTPException(400, f"未知配置：{', '.join(missing)}")
    with run_lock:
        overlapping = set(names) & running
        if overlapping:
            raise HTTPException(409, f"正在采集：{', '.join(overlapping)}")
        running.update(names)
    task_id = uuid.uuid4().hex
    init_db()
    with connect() as con:
        con.execute("INSERT INTO tasks(id,status,companies,started_at) VALUES(?,?,?,?)",
                    (task_id, "running", json.dumps(names, ensure_ascii=False), now()))
    executor.submit(_run, task_id, names)
    return {"id": task_id, "status": "running", "companies": names}


@app.get("/api/tasks/{task_id}")
def task(task_id: str) -> dict:
    init_db()
    with connect() as con:
        row = con.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    if not row:
        raise HTTPException(404, "任务不存在")
    return task_to_dict(row)


@app.post("/api/tasks/{task_id}/pause")
def pause(task_id: str) -> dict:
    with connect() as con:
        updated = con.execute("UPDATE tasks SET paused=1,status=CASE WHEN status='queued' THEN 'paused' ELSE status END "
                              "WHERE id=? AND status IN ('running','queued')", (task_id,)).rowcount
    if not updated:
        raise HTTPException(404, "运行中任务不存在")
    return {"id": task_id, "paused": True}


@app.post("/api/tasks/{task_id}/resume")
def resume(task_id: str) -> dict:
    with connect() as con:
        row = con.execute("SELECT task_type FROM tasks WHERE id=? AND status='paused'", (task_id,)).fetchone()
        if row and row["task_type"] == "discovery":
            updated = con.execute("UPDATE tasks SET paused=0,status='queued' WHERE id=?", (task_id,)).rowcount
        else:
            updated = con.execute("UPDATE tasks SET paused=0 WHERE id=? AND status='running'", (task_id,)).rowcount
    if not updated:
        raise HTTPException(404, "运行中任务不存在")
    return {"id": task_id, "paused": False}


@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")


app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
