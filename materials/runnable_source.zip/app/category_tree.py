"""Short, two-level navigation labels for the reviewed technical categories."""
import re

VERSION='category-tree-20261028'
TREE={
    '大模型':['基模','预训练','后训练','AI Infra','推理','数据','评测','多模态','Agent算法','应用算法','应用开发','综合算法'],
    '开发':['前端','后端','客户端','全栈','软件','嵌入式'],
    '算法':['推荐搜索','具身智能','视觉','语音','NLP','机器学习','决策优化'],
    '数据':['数据工程','数据科学'],
    '基础设施':['系统','网络'],
    '安全':['安全'],
    '测试':['测试'],
    '图形':['图形'],
    '芯片':['芯片'],
}
LABELS={
    '大模型基模架构与模型研究':('大模型','基模'),
    '大模型预训练':('大模型','预训练'),
    '大模型后训练与强化学习':('大模型','后训练'),
    '大模型训练系统与算力':('大模型','AI Infra'),
    '大模型推理优化与部署':('大模型','推理'),
    '大模型数据工程与合成':('大模型','数据'),
    '大模型评测与安全':('大模型','评测'),
    '大模型多模态与生成':('大模型','多模态'),
    '大模型Agent算法':('大模型','Agent算法'),
    '大模型应用算法':('大模型','应用算法'),
    '大模型应用开发':('大模型','应用开发'),
    '大模型综合算法':('大模型','综合算法'),
    '前端开发':('开发','前端'), '后端与分布式服务':('开发','后端'),
    '客户端与移动开发':('开发','客户端'), '全栈与应用开发':('开发','全栈'),
    '软件开发':('开发','软件'), '嵌入式与机器人软件':('开发','嵌入式'),
    '推荐搜索与广告算法':('算法','推荐搜索'), '具身智能与机器人算法':('算法','具身智能'),
    '计算机视觉与图像算法':('算法','视觉'), '语音与音频算法':('算法','语音'),
    '自然语言处理算法':('算法','NLP'), '机器学习与通用算法':('算法','机器学习'),
    '决策优化与数据挖掘':('算法','决策优化'),
    '数据工程与数据库':('数据','数据工程'), '数据科学与计算分析':('数据','数据科学'),
    '系统与计算基础设施':('基础设施','系统'), '网络与IT基础设施':('基础设施','网络'),
    '计算机安全':('安全','安全'), '软件测试与质量工程':('测试','测试'),
    '图形图像与游戏技术':('图形','图形'), '芯片与数字系统':('芯片','芯片'),
}

def category_fields(job):
    category=job.get('category') or ''
    group,label=LABELS.get(category,('其他',category))
    if group=='大模型':
        return {'category_group':group,'category_label':label,'category_path':[group,label],'category_tree_version':VERSION}
    title=str(job.get('title') or '')
    work=str(job.get('responsibilities') or '')
    numbered=re.search(r'(?:^|\n)\s*1[、.．]',work)
    if numbered:work=work[numbered.start():]
    explicit=re.search(r'AI[\s_-]*Infra|AI基础设施|大模型.{0,8}(?:infra|基础设施|计算基础|算力)|强化学习.{0,8}(?:infra|训练框架)',title,re.I)
    infrastructure=category in {'系统与计算基础设施','软件开发','芯片与数字系统'}
    infra_role=re.search(r'Infra|基础架构|机器学习系统|算力|网络|异构计算|计算引擎|GPU|高性能|算子|系统|服务器|Model Serving|芯片',title,re.I)
    model_system=infrastructure and infra_role and re.search(r'大模型|LLM|AIGC|AI训练|AI推理|训练框架|推理引擎|推理系统',title+'\n'+work,re.I)
    if infrastructure and re.search(r'推理',title):model_system=True
    if re.search(r'^移动研发|^平台研发.*App Infra',title) and not explicit:model_system=False
    if explicit or model_system:
        group='大模型'
        label='推理' if re.search(r'推理|inference',title,re.I) else 'AI Infra'
    elif re.search(r'大模型|语言模型|Agent|智能体|AIGC',title,re.I) and group=='开发':
        group='大模型'
        label=('推理' if re.search(r'推理|部署优化|蒸馏',title) else '数据' if '数据智多星' in title else '多模态' if re.search(r'视觉|生成|数字人',title) else '应用算法' if '算法' in title else '应用开发')
    return {'category_group':group,'category_label':label,'category_path':[group,label] if group!=label else [group],'category_tree_version':VERSION}

def tree_counts(jobs):
    counts={group:{label:0 for label in labels} for group,labels in TREE.items()}
    for job in jobs:
        f=category_fields(job)
        if f['category_group'] in counts:counts[f['category_group']][f['category_label']]+=1
    return [{'name':group,'count':sum(children.values()),'children':[{'name':label,'count':count} for label,count in children.items() if count]} for group,children in counts.items() if sum(children.values())]
