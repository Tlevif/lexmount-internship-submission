# 本地只读演示

Python 3.11+。解压到新目录，执行：

```powershell
python -m pip install -r requirements.txt
$env:DEMO_READ_ONLY="1"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

浏览 http://127.0.0.1:8000/ 。首次启动从JSONL初始化数据库。若本机另有服务占用8000端口，可改为8001。云采集需要另行安装并登录Lexmount CLI；只读查询无需云凭据。数据采集日期以作品说明为准，初始化显示的最近确认时间是装载时间。
