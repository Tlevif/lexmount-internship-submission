# 本地只读演示

Python 3.11+。执行：

```powershell
python -m pip install -r requirements.txt
$env:DEMO_READ_ONLY="1"
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

浏览 http://127.0.0.1:8000/ 。首次启动装载当前技术岗位。只读演示无需云凭据；重新采集需安装并登录Lexmount CLI、核验详情和分类。
