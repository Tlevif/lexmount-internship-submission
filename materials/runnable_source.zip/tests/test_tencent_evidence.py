import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_tencent_batch_matches_verified_pagination():
    batch = json.loads((ROOT / "evidence/collector/batch_alpha.json").read_text(encoding="utf-8"))
    capture = json.loads((ROOT / "evidence/collector/tencent_pagination_capture.json").read_text(encoding="utf-8"))

    assert batch["company"] == "腾讯"
    assert batch["collection"]["session_closed"] is True
    assert batch["collection"]["pages_read"] == 63
    assert batch["collection"]["reported_total"] == 617
    assert batch["collection"]["target_city_internship_cards"] == 504
    assert len(batch["jobs"]) == 409
    assert len(batch["review_candidates"]) == 21
    assert sum(batch["collection"]["page_counts"]["日常实习"]) == 71
    assert sum(batch["collection"]["page_counts"]["应届实习"]) == 189
    assert sum(batch["collection"]["page_counts"]["青云计划-实习生"]) == 357

    all_rows = batch["jobs"] + batch["review_candidates"]
    source_ids = [row["source_job_id"] for row in all_rows]
    assert len(source_ids) == len(set(source_ids))
    assert all(row["cities"] for row in all_rows)
    assert all(row["raw_payload"].get("review_reason") for row in batch["review_candidates"])
    assert all(row["source_url"].startswith("https://join.qq.com/post.html?") for row in all_rows)
    assert all(row["detail_url"].startswith("https://join.qq.com/post_detail.html?postid=") for row in all_rows)
    assert any(row["source_job_id"] == "1233768079818094592" for row in batch["jobs"])

    assert capture["pages_read_all_streams"] == 63
    assert capture["reported_total_all_streams"] == 617
    assert capture["streams"]["日常实习"]["duplicate_page_cards"] == 10
    assert capture["streams"]["日常实习"]["unique_stable_ids"] == 61
    for stream in capture["streams"].values():
        assert len(stream["page_counts"]) == stream["pages_read"]
