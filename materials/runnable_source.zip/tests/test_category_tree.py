import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.category_tree import category_fields,tree_counts,TREE
from app import main
from app.db import upsert_jobs

@pytest.mark.parametrize('title,category,work,expected',[
 ('模型架构研究','大模型基模架构与模型研究','研究MoE架构',('大模型','基模')),
 ('预训练研发','大模型预训练','训练模型',('大模型','预训练')),
 ('AI Infra研发实习生','系统与计算基础设施','研发GPU集群',('大模型','AI Infra')),
 ('AI-Infra推理方向','系统与计算基础设施','优化推理引擎',('大模型','推理')),
 ('AI Infra研发实习生 - 存储','系统与计算基础设施','优化分布式存储',('大模型','AI Infra')),
 ('普通后端开发','后端与分布式服务','团队研究大模型。\n1、开发支付后端和数据库',('开发','后端')),
 ('IT基础设施实习','系统与计算基础设施','办公设备维护',('基础设施','系统')),
 ('大模型应用后端开发','后端与分布式服务','实现模型API',('大模型','应用开发')),
 ('前端开发','前端开发','React开发',('开发','前端')),
 ('数据开发','数据工程与数据库','SQL数据管道',('数据','数据工程')),
])
def test_short_hierarchical_labels(title,category,work,expected):
    f=category_fields(dict(title=title,category=category,responsibilities=work))
    assert (f['category_group'],f['category_label'])==expected
    assert f['category_label'] in TREE[f['category_group']]
    assert '与' not in f['category_label']

def test_two_level_api_filter_and_export(tmp_path,monkeypatch):
    monkeypatch.setenv('INTERNSHIP_DB',str(tmp_path/'jobs.sqlite3'))
    def job(i,title,work):
        return dict(company_name='测试企业',title=title,responsibilities=work,requirements='熟悉Python、计算机基础和软件开发',source_job_id=str(i),source_url='https://example.test/jobs',detail_url=f'https://example.test/jobs/{i}',collection_method='webfetch',cities=['北京'])
    with TestClient(main.app) as c:
        upsert_jobs([job(1,'AI Infra研发实习生','开发GPU分布式训练框架'),job(2,'大模型预训练算法实习生','研发大模型预训练算法'),job(3,'后端开发实习生','开发Java后端系统')])
        r=c.get('/api/jobs',params={'direction':'大模型'}).json();assert r['total']==2
        r=c.get('/api/jobs',params={'direction':'大模型','specialization':'AI Infra'}).json();assert r['total']==1 and r['items'][0]['source_job_id']=='1'
        assert c.get('/api/jobs',params={'direction':'开发','specialization':'AI Infra'}).json()['total']==0
        meta=c.get('/api/stats').json();assert sum(g['count'] for g in meta['category_tree'])==3
        csv=c.get('/api/jobs/export.csv',params={'direction':'大模型','specialization':'AI Infra'}).text
        assert 'AI Infra研发实习生' in csv and '后端开发实习生' not in csv

def test_complete_snapshot_tree():
    root=Path(__file__).resolve().parents[1]
    rows=[json.loads(x) for x in (root/'data/jobs.jsonl').read_text('utf8').split('\n') if x]
    tree=tree_counts(rows)
    assert len(rows)==3095==sum(g['count'] for g in tree)
    assert len(tree)==9 and len(next(g for g in tree if g['name']=='大模型')['children'])==12
    for row in rows:
        f=category_fields(row)
        assert f['category_group'] in TREE and f['category_label'] in TREE[f['category_group']]
        assert all(row.get(k)==f[k] for k in f)
        if __import__('re').search(r'AI[\s_-]*Infra',row['title'],__import__('re').I):assert f['category_group']=='大模型'
