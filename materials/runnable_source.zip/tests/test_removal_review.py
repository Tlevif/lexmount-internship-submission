"""Verify the correction against actual archived records and active stores."""
import json, sqlite3
from pathlib import Path
import pytest
from app.core import normalize_job, fingerprint

ROOT=Path(__file__).resolve().parents[1]

@pytest.fixture(scope='module')
def records():
    return [json.loads(x) for x in (ROOT/'data/jobs.jsonl').read_text('utf8').split('\n') if x]

def test_review_partitions_all_removed_records(records):
    audit=json.loads((ROOT/'evidence/removal_review20261028/classification_audit.json').read_text('utf8'))
    summary=json.loads((ROOT/'evidence/removal_review20261028/SUMMARY.json').read_text('utf8'))
    assert len(audit)==2295==len({x['index'] for x in audit})
    assert sum(x['status']=='restored' for x in audit)==summary['restored_jobs']==190
    assert summary['remain_removed_jobs']==2105
    assert len(records)==summary['active_jobs']==3095
    assert all(normalize_job(x)['category']==x['category'] for x in records)

@pytest.mark.parametrize('title,category',[
    ('软硬件协同实习生-服务器','系统与计算基础设施'),
    ('java工程师实习生（J104974）','后端与分布式服务'),
    ('C++搜索/推荐实习生-【搜索】','后端与分布式服务'),
    ('量子电路优化研究','系统与计算基础设施'),
    ('WXG 高性能大规模向量检索系统','数据工程与数据库'),
    ('AI解决方案实习生-飞书','大模型应用开发'),
    ('内控数据实习生-内控','数据工程与数据库'),
    ('硬件技术工程师（电池云端大数据算法、车辆仿真软件方向）','系统与计算基础设施'),
])
def test_technical_false_negatives_restored(records,title,category):
    matches=[x for x in records if x['title']==title]
    assert matches and any(x['category']==category for x in matches)
    assert all(x['responsibilities'] and x['requirements'] for x in matches)

def test_business_and_incomplete_records_stay_out(records):
    titles={x['title'] for x in records}
    assert not titles.intersection({'AI Agent 策略实习生','AI时尚实习生 - 广告业务','Agent Harness 团队','人因与用户体验工程师'})
    deleted=json.loads((ROOT/'evidence/removal_review20261028/deleted_incomplete_details.json').read_text('utf8'))
    assert len(deleted)==13
    active={(x['company_name'],x.get('source_job_id'),x['detail_url']) for x in records}
    assert not active.intersection((x['company'],x.get('source_job_id'),x['detail_url']) for x in deleted)
    assert not (ROOT/'data/archive/20261027-before-rebuild/unverified_details.jsonl').exists()

def test_jsonl_and_sqlite_have_same_reviewed_jobs(records):
    with sqlite3.connect(ROOT/'data/jobs.sqlite3') as con:
        rows=con.execute('SELECT fingerprint,category FROM jobs').fetchall()
    assert dict(rows)=={fingerprint(x):x['category'] for x in records}
