import pytest

from collector.core import CollectionError, _check_byte_page, _feishu_category, _filtered_cities, _new_card_ids, _page_url, is_catalog_eligible_job, collect_company, iter_company_pages


def test_verified_internship_url_and_pagination():
    url = _page_url("https://jobs.bytedance.com/campus/position", 2, 10, "7194661644654577981")
    assert "project=7194661644654577981" in url
    assert "current=2" in url
    assert "limit=10" in url


def test_catalog_gate_accepts_technical_titles_and_rejects_business_titles():
    assert is_catalog_eligible_job("前端开发实习生", "研发 - 前端")
    assert is_catalog_eligible_job("算法实习生", "研发 - 算法")
    assert not is_catalog_eligible_job("达人营销策略实习生", "运营")
    assert is_catalog_eligible_job("RL Infra实习生", "工程")
    for title in ("数据分析实习生", "Agent自动评测实习生", "Agent评测与工程实习生", "计算语言学实习生（ASR方向）", "推荐策略实习生", "基础架构实习生"):
        assert is_catalog_eligible_job(title, "运营")
    for title in ("Agent产品运营实习生", "达人营销策略实习生", "电商资源管理实习生"):
        assert not is_catalog_eligible_job(title, "运营")
    assert _filtered_cities("杭州、上海、成都") == ["上海", "杭州"]


def test_feishu_category_is_read_from_internship_card_meta():
    assert _feishu_category("北京校招实习技术 - 算法职位 ID：A203248") == "技术 - 算法"
    assert _feishu_category("深圳校招实习技术 - 开发2027校园招聘职位 ID：A123") == "技术 - 开发"
    assert _feishu_category("北京校招实习市场与销售 - 公共关系职位 ID：A249785") == "市场与销售 - 公共关系"


def test_mokahr_card_parses_uuid_city_date_description_without_city_inference():
    from collector.core import _mokahr_card_job, _split_mokahr_description

    config = {
        "company_name": "银河通用机器人",
        "company_website": "https://www.galbot.com/",
        "career_url": "https://app.mokahr.com/campus-recruitment/yinhetongyong/165930?locale=zh-CN#/jobs?project=100130135",
    }
    card = {
        "title": "机器人规控算法实习生",
        "href": "https://app.mokahr.com/campus-recruitment/yinhetongyong/165930?locale=zh-CN#/job/3c7b0b80-260a-4089-b453-c9eb12f08b6b",
        "meta": "机器人规控算法实习生\n发布于 2026-05-09\n硬件中心 | 实习 | 算法类 | 广东·深圳市 北京市",
        "description": "职位描述：参与机器人规划控制算法研发。\n\n职位要求：熟悉 C++ 和机器人控制。",
    }
    item = _mokahr_card_job(config, card, config["career_url"], 9, "test-session")
    assert item["source_job_id"] == "3c7b0b80-260a-4089-b453-c9eb12f08b6b"
    assert item["cities"] == ["北京", "深圳"]
    assert item["published_at"] == "2026-05-09"
    assert item["recruitment_type"] == "实习"
    assert item["responsibilities"] == "参与机器人规划控制算法研发。"
    assert item["requirements"] == "熟悉 C++ 和机器人控制。"
    assert _split_mokahr_description("职位描述：仅有职责内容") == ("仅有职责内容", None)


def test_mokahr_city_filter_does_not_infer_office_city_from_title_or_body():
    from collector.core import _mokahr_card_job

    config = {"company_name": "测试", "career_url": "https://app.mokahr.com/campus-recruitment/example/1?locale=zh-CN#/jobs?project=1"}
    card = {
        "title": "深圳算法实习生",
        "href": "https://app.mokahr.com/campus-recruitment/example/1?locale=zh-CN#/job/3c7b0b80-260a-4089-b453-c9eb12f08b6b",
        "meta": "发布于 2026-05-09 | 实习 | 算法类 | 江苏·苏州市",
        "description": "负责机器人算法。要求可在深圳实习。",
    }
    assert _mokahr_card_job(config, card, config["career_url"], 1, "test-session")["cities"] == []


def test_mokahr_adapter_uses_browser_page_and_filters_to_supported_cities(monkeypatch):
    from collector import core

    config = {"company_name": "测试", "career_url": "https://app.mokahr.com/campus-recruitment/example/1?locale=zh-CN#/jobs?project=1",
              "adapter": "mokahr_campus", "verified_for_collection": True, "browser_session_id": "existing"}
    cards = [
        {"title": "算法实习生", "href": f"https://app.mokahr.com/campus-recruitment/example/1#/job/00000000-0000-0000-0000-{i:012d}",
         "meta": f"发布于 2026-05-09 | 实习 | 算法类 | {'北京市' if i == 1 else '江苏·苏州市'}",
         "description": "岗位职责：算法研发。任职要求：熟悉 Python。"}
        for i in (1, 2)
    ]
    calls = []
    monkeypatch.setattr(core, "_run", lambda _binary, *args, **_kwargs: calls.append(args) or {"data": [{"type": "page", "id": "target", "url": config["career_url"]}]})
    monkeypatch.setattr(core, "_browser_eval", lambda *_args: {"url": config["career_url"], "title": "测试 - 校园招聘", "total": 2, "cards": cards})
    jobs = core.collect_company(config)
    assert len(jobs) == 1
    assert jobs[0]["cities"] == ["北京"]
    assert not any(args[:2] == ("session", "close") for args in calls)


def test_unverified_site_cannot_collect():
    with pytest.raises(CollectionError):
        collect_company({"career_url": "https://jobs.bytedance.com/campus/position", "adapter": "bytedance_campus"})


def test_feishu_page_iterator_tracks_all_pages_and_classifies_business_roles(monkeypatch):
    from collector import core

    def card(index, title, category):
        return {"title": title, "href": f"https://example.jobs.feishu.cn/campus/position/{index}/detail",
                "city": "北京", "meta": f"北京校招实习技术 - {category}", "category": category,
                "description": "岗位职责"}

    pages = {
        1: {"url": "https://example.jobs.feishu.cn/campus/position/list?current=1&limit=20", "total": 21,
            "cards": [card(i, "算法实习生" if i == 1 else "品牌实习生" if i == 2 else "普通实习生",
                           "算法" if i == 1 else "市场" if i == 2 else "其他")
                      for i in range(1, 21)]},
        2: {"url": "https://example.jobs.feishu.cn/campus/position/list?current=2&limit=20", "total": 21,
            "cards": [card(21, "后端开发实习生", "开发")]},
    }
    active_page = {"page": 1}
    closed = []

    def fake_run(_binary, *args, **_kwargs):
        if args[:2] == ("session", "create"):
            return {"data": {"session_id": "test-session"}}
        if args[:2] == ("action", "open-url"):
            page_url = args[args.index("--url") + 1]
            from urllib.parse import parse_qs, urlparse
            active_page["page"] = int(parse_qs(urlparse(page_url).query)["current"][0])
            return {"data": {}}
        if args[:2] == ("session", "targets"):
            page_url = args[args.index("--url") + 1] if "--url" in args else "https://example.jobs.feishu.cn/campus/position/list"
            return {"data": [{"type": "page", "id": "target", "url": page_url}]}
        return {"data": {}}

    monkeypatch.setattr(core, "_run", fake_run)
    monkeypatch.setattr(core, "_browser_eval", lambda *_args: pages[active_page["page"]])
    monkeypatch.setattr(core, "_close_browser_session", lambda session: closed.append(session))

    batches = list(iter_company_pages({
        "company_name": "测试公司", "career_url": "https://example.jobs.feishu.cn/campus/position/list",
        "adapter": "feishu_jobs", "verified_for_collection": True, "page_size": 20, "max_pages": 2,
    }))

    assert [b["page"] for b in batches] == [1, 2]
    assert [b["raw_count"] for b in batches] == [20, 1]
    assert sum(len(b["jobs"]) for b in batches) == 2
    assert sum(len(b["review_candidates"]) for b in batches) == 19
    assert batches[0]["review_candidates"][0]["raw_payload"]["review_reason"]
    assert closed == ["test-session"]


def test_feishu_page_iterator_rejects_duplicate_ids(monkeypatch):
    from collector import core

    active_page = {"page": 1}
    closed = []
    duplicate = {"title": "算法实习生", "href": "https://example.jobs.feishu.cn/campus/position/1/detail",
                 "city": "北京", "meta": "北京校招实习技术 - 算法职位 ID：A1", "category": "技术 - 算法",
                 "description": "算法研发"}

    def fake_run(_binary, *args, **_kwargs):
        if args[:2] == ("session", "create"):
            return {"data": {"session_id": "test-session"}}
        if args[:2] == ("action", "open-url"):
            from urllib.parse import parse_qs, urlparse
            active_page["page"] = int(parse_qs(urlparse(args[args.index("--url") + 1]).query)["current"][0])
            return {"data": {}}
        if args[:2] == ("session", "targets"):
            return {"data": [{"type": "page", "id": "target", "url": "https://example.jobs.feishu.cn/campus/position/list"}]}
        return {"data": {}}

    monkeypatch.setattr(core, "_run", fake_run)
    monkeypatch.setattr(core, "_browser_eval", lambda *_args: {
        "url": f"https://example.jobs.feishu.cn/campus/position/list?current={active_page['page']}&limit=1",
        "total": 2, "cards": [duplicate]})
    monkeypatch.setattr(core, "_close_browser_session", lambda session: closed.append(session))

    with pytest.raises(CollectionError, match="duplicate stable position IDs"):
        list(iter_company_pages({
            "company_name": "测试公司", "career_url": "https://example.jobs.feishu.cn/campus/position/list",
            "adapter": "feishu_jobs", "verified_for_collection": True, "page_size": 1, "max_pages": 2,
        }))
    assert closed == ["test-session"]


def test_pagination_does_not_stop_on_nontechnical_page():
    seen = set()
    page_one = [{"href": "https://jobs.bytedance.com/campus/position/1/detail", "title": "营销实习生", "category": "运营"}]
    page_two = [{"href": "https://jobs.bytedance.com/campus/position/2/detail", "title": "算法实习生", "category": "研发"}]
    assert len(_new_card_ids(page_one, seen)) == 1
    assert len(_new_card_ids(page_two, seen)) == 1
    assert len(_new_card_ids(page_two, seen)) == 0


def test_feishu_raw_evidence_has_stable_detail_urls():
    import json
    from pathlib import Path

    path = Path(__file__).resolve().parents[1] / "evidence" / "collector" / "baichuan_raw_page1.json"
    cards = json.loads(path.read_text(encoding="utf-8"))["page"]["cards"]
    assert len(cards) == 6
    ids = _new_card_ids(cards, set())
    assert len(ids) == 6
    assert all("/646926/position/" in card["href"] and card["href"].endswith("/detail") for card, _ in ids)


def test_page_integrity_rejects_missing_cards():
    result = {"url": _page_url("https://jobs.bytedance.com/campus/position", 2, 10, "123"), "total": 25, "cards": [{"href": "https://jobs.bytedance.com/campus/position/11/detail"}]}
    with pytest.raises(CollectionError, match="card count"):
        _check_byte_page(result, 2, 10, "123", set())


def test_iter_pages_follows_reported_total_and_closes(monkeypatch):
    import collector.core as core
    from urllib.parse import parse_qs, urlparse

    state = {"url": "", "closed": False, "visited": []}

    def fake_run(_binary, *args, **_kwargs):
        if args[:2] == ("session", "create"):
            return {"data": {"session_id": "test-session"}}
        if args[:2] == ("action", "open-url"):
            state["url"] = args[args.index("--url") + 1]
            state["visited"].append(int(parse_qs(urlparse(state["url"]).query)["current"][0]))
            return {"data": {}}
        if args[:2] == ("session", "targets"):
            return {"data": [{"type": "page", "url": state["url"], "id": "test-target"}]}
        if args[:2] == ("session", "close"):
            state["closed"] = True
        if args[:2] == ("session", "get"):
            return {"data": {"status": "closed" if state["closed"] else "active"}}
        return {"data": {}}

    def fake_eval(_session, _target, _expression):
        page = int(parse_qs(urlparse(state["url"]).query)["current"][0])
        ids = range((page - 1) * 10 + 1, min(page * 10, 11) + 1)
        return {"url": state["url"], "total": 11, "cards": [{"title": "普通实习生" if i == 1 else "算法实习生", "href": f"https://jobs.bytedance.com/campus/position/{i}/detail", "city": "北京", "meta": "北京实习", "category": "其他" if i == 1 else "研发", "description": ""} for i in ids]}

    monkeypatch.setattr(core, "_run", fake_run)
    monkeypatch.setattr(core, "_browser_eval", fake_eval)
    config = {"company_name": "字节跳动", "career_url": "https://jobs.bytedance.com/campus/position", "adapter": "bytedance_campus", "project_id": "123", "page_size": 10, "verified_for_collection": True}
    batches = list(iter_company_pages(config))
    assert state["visited"] == [1, 2]
    assert [batch["raw_count"] for batch in batches] == [10, 1]
    assert sum(len(batch["jobs"]) for batch in batches) == 10
    assert sum(len(batch["review_candidates"]) for batch in batches) == 1
    assert state["closed"]
