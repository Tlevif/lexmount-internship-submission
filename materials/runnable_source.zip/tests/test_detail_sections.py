from collector.detail_sections import extract_sections

def test_tencent_keeps_preferred_qualifications_but_excludes_department_footer():
    text='后台开发\n岗位描述\n负责开发与维护核心服务。\n岗位要求\n熟悉Python与网络编程。\n加分项或注意事项\n分布式系统经验优先。\n参加面试的城市\n远程面试\n招聘部门和工作地\nIEG'
    x=extract_sections(text)
    assert x['responsibilities']=='负责开发与维护核心服务。'
    assert '分布式系统经验优先' in x['requirements']
    assert '远程面试' not in x['requirements']

def test_english_sections_and_related_job_boundary():
    x=extract_sections('About the Job\n参与智能体风险评测研究。\nQualifications\n在读硕士，熟悉Python。\nHiring Business\nAlibaba')
    assert x=={'responsibilities':'参与智能体风险评测研究。','requirements':'在读硕士，熟悉Python。'}
    x=extract_sections('职位描述\n仅提供旧链接，请移步。\n投递\n相关职位\n职位要求\n相邻岗位的要求内容。')
    assert x=={'responsibilities':'仅提供旧链接，请移步。'}

def test_research_project_sections_are_job_content():
    x=extract_sections('课题描述\n课题背景：\n参与长期视频理解模型研究。\n具体工作：\n构建时序评测数据集。\n课题要求\n计算机专业在读博士。\n参加面试的城市\n远程面试')
    assert '具体工作' in x['responsibilities']
    assert x['requirements']=='计算机专业在读博士。'

def test_requirement_with_mislabelled_nested_heading_keeps_qualification_text():
    x=extract_sections('课题描述\n研究企业知识挖掘与智能体应用。\n课题要求\n岗位职责：\n计算机相关专业，博士优先。\n参加面试的城市\n远程')
    assert x['responsibilities']=='研究企业知识挖掘与智能体应用。'
    assert '博士优先' in x['requirements']
