import json
import sys
import time
import types

import pytest
from fastapi.testclient import TestClient

from app import companies as company_store
from app import main
from app.core import normalize_job
from app.tasks import requeue_running_discovery_tasks


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("INTERNSHIP_DB", str(tmp_path / "jobs.sqlite3"))
    with TestClient(main.app) as c:
        yield c


def listing(**changes):
    row = {
        "company_name": "示例科技（仅测试）", "company_website": "https://example.test",
        "career_url": "https://example.test/careers", "title": "基础架构实习生",
        "detail_url": "https://example.test/jobs/12?utm_source=demo",
        "source_url": "https://example.test/careers", "collection_method": "webfetch",
        "cities": ["北京市", "上海"], "recruitment_type": "实习",
        "responsibilities": "参与分布式系统开发", "requirements": "熟悉 Python",
        "published_at": None, "source_job_id": "12",
    }
    row.update(changes)
    return row


def test_normalization_and_identity():
    job = normalize_job(listing())
    assert job["cities"] == ["北京", "上海"]
    assert job["category"] == "系统与计算基础设施"
    assert job["published_at"] is None
    assert job["fingerprint"] == normalize_job(listing(title="新版标题"))["fingerprint"]


def test_demo_snapshot_preserves_unicode_line_separators(tmp_path, monkeypatch):
    monkeypatch.setenv("INTERNSHIP_DB", str(tmp_path / "demo.sqlite3"))
    monkeypatch.setenv("DEMO_READ_ONLY", "1")
    monkeypatch.setattr(main, "ROOT", tmp_path)
    (tmp_path / "data").mkdir()
    job = listing(responsibilities="研发\u2028系统\u2029测试")
    (tmp_path / "data" / "jobs.jsonl").write_text(
        json.dumps(job, ensure_ascii=False) + "\n", encoding="utf-8")
    with TestClient(main.app) as c:
        result = c.get("/api/jobs").json()
        assert result["total"] == 1
        assert result["items"][0]["responsibilities"] == job["responsibilities"]
        assert c.post("/api/jobs/import", json={"jobs": [job]}).status_code == 405
    with TestClient(main.app) as c:
        assert c.get("/api/jobs").json()["total"] == 1


def test_import_search_detail_and_upsert(client):
    assert client.get("/").status_code == 200
    assert client.get("/static/app.js").status_code == 200
    first = client.post("/api/jobs/import", json={"jobs": [listing()]})
    assert first.status_code == 200
    assert first.json() == {"collected": 1, "inserted": 1, "updated": 0}
    again = client.post("/api/jobs/import", json={"jobs": [listing(title="基础架构研发实习生")]})
    assert again.json()["updated"] == 1
    result = client.get("/api/jobs", params={"city": "北京", "category": "系统与计算基础设施", "company": "示例科技（仅测试）", "q": "研发"}).json()
    assert result["total"] == 1
    item = result["items"][0]
    assert item["published_at"] is None
    assert item["first_seen_at"]
    assert client.get(f"/api/jobs/{item['id']}").json()["title"] == "基础架构研发实习生"
    assert client.get("/api/jobs", params={"city": "深圳"}).json()["total"] == 0
    assert client.get("/api/stats").json()["jobs"] == 1
    client.post("/api/jobs/import", json={"jobs": [listing(source_job_id="law", title="法务实习生", responsibilities="审查法律合同", requirements="法学专业")]})
    assert client.get("/api/jobs").json()["total"] == 1
    assert client.get("/api/stats").json()["jobs"] == 1


def test_collection_retry_failure_record_and_verified_gate(client, tmp_path, monkeypatch):
    configs = tmp_path / "configs"
    configs.mkdir()
    (configs / "verified.json").write_text(json.dumps({"name": "测试站", "verified_for_collection": True}), encoding="utf-8")
    (configs / "unverified.json").write_text(json.dumps({"name": "未验证站", "verified_for_collection": False}), encoding="utf-8")
    monkeypatch.setattr(main, "CONFIG_DIR", configs)
    calls = []
    def fake_collect(config):
        calls.append(config["name"])
        raise RuntimeError("测试网络故障")
    monkeypatch.setitem(sys.modules, "collector", types.SimpleNamespace(collect_company=fake_collect))
    assert client.post("/api/collect", json={"companies": ["未验证站"]}).status_code == 400
    started = client.post("/api/collect", json={"companies": ["测试站"]})
    assert started.status_code == 200
    task_id = started.json()["id"]
    for _ in range(40):
        result = client.get(f"/api/tasks/{task_id}").json()
        if result["finished_at"]:
            break
        time.sleep(.1)
    assert result["status"] == "completed_with_errors"
    assert result["errors"][0]["attempts"] == 2
    assert calls == ["测试站", "测试站"]
    assert client.get("/api/jobs").json()["total"] == 0


def test_company_directory_upsert_is_atomic_and_idempotent(client, tmp_path, monkeypatch):
    directory = tmp_path / "data" / "companies.json"
    directory.parent.mkdir()
    directory.write_text(json.dumps([{
        "name": "已有品牌", "website": "https://brand.example", "career_url": "https://jobs.example/openings/",
        "source": "官网", "verification_status": "job_verified",
    }], ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(company_store, "COMPANY_FILE", directory)
    monkeypatch.setattr(main, "ROOT", tmp_path)
    new_company = {"name": "新公司", "website": "https://new.example", "career_url": "https://new.example/careers",
                   "source": "公开目录 https://directory.example/list", "verification_status": "pending"}
    first = client.post("/api/companies/upsert", json={"companies": [new_company]})
    assert first.status_code == 200
    assert first.json()["inserted"] == 1
    second = client.post("/api/companies/upsert", json={"companies": [new_company]})
    assert second.json()["unchanged"] == 1
    alias_update = client.post("/api/companies/upsert", json={"companies": [{
        "name": "已有品牌科技有限公司", "career_url": "https://jobs.example/openings", "source": "行业名录",
        "verification_status": "pending",
    }]})
    assert alias_update.json()["updated"] == 1
    rows = json.loads(directory.read_text(encoding="utf-8"))
    assert len(rows) == 2
    existing = rows[0]
    assert existing["name"] == "已有品牌"
    assert "已有品牌科技有限公司" in existing["aliases"]
    assert existing["verification_status"] == "job_verified"
    assert existing["source"] == "官网; 行业名录"
    api_rows = client.get("/api/companies").json()
    new_row = next(row for row in api_rows if row["name"] == "新公司")
    assert new_row["source"] == new_company["source"]
    assert client.get("/api/stats").json()["companies"] == 2


def test_discovery_task_queue_events_and_resume(client):
    created = client.post("/api/discovery/tasks", json={"config": {"target_cities": ["北京"]}})
    assert created.status_code == 200
    task_id = created.json()["id"]
    assert created.json()["status"] == "queued"
    listed = client.get("/api/tasks", params={"task_type": "discovery"}).json()
    assert listed[0]["config"] == {"target_cities": ["北京"]}
    assert client.post(f"/api/tasks/{task_id}/claim").status_code == 200
    event = client.post(f"/api/tasks/{task_id}/events", json={"events": [
        {"agent": "candidate_discovery", "stage": "search", "message": "从公开目录发现候选企业"}
    ]})
    assert event.json()["events_added"] == 1
    assert client.post(f"/api/tasks/{task_id}/pause").json()["paused"] is True
    assert client.post(f"/api/tasks/{task_id}/resume").json()["paused"] is False
    finished = client.post(f"/api/tasks/{task_id}/finish", json={"status": "completed", "summary": {"verified": 3}})
    assert finished.json()["status"] == "completed"
    record = client.get(f"/api/tasks/{task_id}").json()
    assert record["task_type"] == "discovery"
    assert record["events"][-1]["summary"] == {"verified": 3}
    assert any(event.get("agent") == "candidate_discovery" for event in record["events"])


def test_running_discovery_task_returns_to_queue_after_restart(client):
    task_id = client.post("/api/discovery/tasks", json={"config": {"candidate_limit": 20}}).json()["id"]
    assert client.post(f"/api/tasks/{task_id}/claim").status_code == 200
    main.startup()
    record = client.get(f"/api/tasks/{task_id}").json()
    assert record["status"] == "running"
    assert requeue_running_discovery_tasks() == 1
    record = client.get(f"/api/tasks/{task_id}").json()
    assert record["status"] == "queued"
    assert record["events"][-1]["stage"] == "requeued"


def test_export_uses_the_same_job_filters(client):
    client.post("/api/jobs/import", json={"jobs": [listing(), listing(
        company_name="第二家测试公司", title="数据算法实习生", source_job_id="13",
        detail_url="https://example.test/jobs/13", source_url="https://example.test/careers",
        cities=["北京"], responsibilities="参与数据建模与算法开发") ]})
    response = client.get("/api/jobs/export.csv", params={"city": "北京", "q": "算法"})
    assert response.status_code == 200
    assert "text/csv" in response.headers["content-type"]
    assert "数据算法实习生" in response.text
    assert "基础架构实习生" not in response.text


def test_recruitment_verified_company_counts_and_status_does_not_downgrade(client, tmp_path, monkeypatch):
    directory = tmp_path / "data" / "companies.json"
    directory.parent.mkdir()
    directory.write_text(json.dumps([{
        "name": "招聘入口已核验", "website": "https://verified.example",
        "career_url": "https://verified.example/careers", "source": "官网证据",
        "verification_status": "recruitment_verified",
    }], ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(company_store, "COMPANY_FILE", directory)
    monkeypatch.setattr(main, "ROOT", tmp_path)
    response = client.post("/api/companies/upsert", json={"companies": [{
        "name": "招聘入口已核验", "source": "待验证来源", "verification_status": "pending"
    }]})
    assert response.status_code == 200
    rows = json.loads(directory.read_text(encoding="utf-8"))
    assert rows[0]["verification_status"] == "recruitment_verified"
    assert client.get("/api/stats").json()["verified_companies"] == 1


def test_company_identity_matches_official_domain_but_keeps_ats_tenants_separate(client, tmp_path, monkeypatch):
    directory = tmp_path / "companies.json"
    directory.write_text(json.dumps([{
        "name": "旧品牌名", "website": "https://www.same.example/", "career_url": "https://app.mokahr.com/campus-recruitment/tenant-a/123",
        "aliases": ["Same Inc."], "source": "官网", "verification_status": "job_verified",
    }], ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr(company_store, "COMPANY_FILE", directory)
    first = client.post("/api/companies/upsert", json={"companies": [{
        "name": "新品牌名", "website": "https://same.example/about", "career_url": "https://other.example/careers",
        "source": "官网", "verification_status": "pending",
    }]})
    assert first.json()["updated"] == 1
    second = client.post("/api/companies/upsert", json={"companies": [{
        "name": "其他企业", "website": "https://third.example", "career_url": "https://app.mokahr.com/campus-recruitment/tenant-b/456",
        "source": "官网", "verification_status": "pending",
    }]})
    assert second.json()["inserted"] == 1
    assert len(json.loads(directory.read_text(encoding="utf-8"))) == 2
