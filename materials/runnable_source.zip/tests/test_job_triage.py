"""Content-based CS scope; business department names must not decide categories."""
import pytest
from app.classification import classify_content
from app.job_triage import triage_job

@pytest.mark.parametrize('title,duties,requirements,category',[
 ('后端开发实习生 - 营销平台','开发高并发后端服务和接口','熟悉Java、Redis和分布式系统','后端与分布式服务'),
 ('技术美术实习生','编写Shader并优化渲染管线','掌握HLSL、C++及计算机图形学','图形图像与游戏技术'),
 ('数据分析实习生','使用SQL处理数据，开展A/B实验与统计建模','熟练掌握Python和SQL','数据科学与计算分析'),
 ('前端开发实习生','开发页面组件与交互','熟悉React与JavaScript','前端开发'),
 ('基础架构实习生','研发分布式计算系统','熟悉Linux、C++和操作系统','系统与计算基础设施'),
 ('业务安全蓝军实习生','开展逆向研究及漏洞攻防','熟悉Python、Linux和网络安全','计算机安全'),
 ('算法实习生','开发机器学习模型与训练框架','熟悉PyTorch和Python','人工智能与算法'),
 ('策略运营实习生 - TikTok','开发内部网页工具和数据处理系统，编写Python脚本','具备Coding能力，掌握Python并能独立完成工具开发','全栈与应用开发'),
])
def test_keeps_technical_work(title,duties,requirements,category):
 d=classify_content(dict(title=title,responsibilities=duties,requirements=requirements,raw_category='营销'))
 assert d['keep'] and d['category']==category,d
 assert d['evidence']

@pytest.mark.parametrize('title,duties,requirements',[
 ('营销实习生 - AI平台','策划品牌活动与营销方案','熟悉Excel和办公软件'),
 ('法务实习生','审查合同与法律文书','法学专业'),
 ('业务分析实习生','撰写行业研究报告与商业建议','熟悉Excel和PowerPoint'),
 ('游戏UI设计实习生','制作游戏界面视觉稿','熟悉Figma和Photoshop'),
 ('客户服务实习生','接听客户咨询并记录反馈','沟通能力强'),
 ('AI数据产品运营实习生','参与人工标注和项目进度协调','熟悉AI工具，了解Python者优先'),
 ('语言学实习生','负责语料标注验收及资源协调','语言学专业，有编程基础者优先'),
 ('增长营销实习生','用数据驱动增长策略','熟悉办公软件'),
 ('项目经理实习生','跟踪进度，使用AI助手整理会议纪要','熟悉Agent，编写Python脚本者加分'),
])
def test_excludes_nontechnical_work(title,duties,requirements):
 assert triage_job(dict(title=title,responsibilities=duties,requirements=requirements,raw_category='研发'))[0]!='include'

def test_old_category_does_not_affect_result():
 j=dict(title='算法实习生',responsibilities='开发机器学习模型',requirements='掌握Python和PyTorch')
 assert classify_content(dict(j,raw_category='营销'))==classify_content(dict(j,raw_category='研发'))

def test_ascii_skill_boundaries_in_chinese_text():
 infra=classify_content(dict(title='RL Infra实习生',responsibilities='训练下一代语言模型',requirements='良好的计算机背景和扎实编程能力，熟悉Megatron、Verl、SGLang'))
 assert infra['keep'] and infra['category']=='系统与计算基础设施'

 d=classify_content(dict(title='前端开发实习生',responsibilities='开发Web前端',requirements='熟练JavaScript和React'))
 assert 'JavaScript/TypeScript' in d['skills'] and 'Java' not in d['skills']

def test_team_intro_does_not_convert_marketing_to_engineering():
 d=classify_content(dict(title='商家运营实习生',responsibilities='团队介绍：开发AI工具和Python系统。\n1、处理商家咨询和活动。',requirements='熟悉办公软件'))
 assert not d['keep']

def test_missing_title_is_review():
 assert triage_job({'title':'','raw_category':'研发'})[0]=='review'
