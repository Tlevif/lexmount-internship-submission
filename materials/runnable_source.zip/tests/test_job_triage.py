"""Curated cases based on observed ByteDance postings, without external I/O."""
import pytest

from app.job_triage import triage_job


@pytest.mark.parametrize("title,category,duties", [
    ("通用Agent数据策略实习生 - AI数据与安全", "运营", "1、参与开发数据合成Pipeline和自动化评测能力的工程开发，支持模型迭代。"),
    ("Agent自动评测实习生 - AI数据与安全", "运营", "1、采集工具调用日志并保存结果；设计自动评分方法，形成可复现评测报告。"),
    ("通用Agent评测运营实习生 - AI数据与安全", "运营", "1、独立搭建评测工程环境，完成工具接入、任务运行和结果采集。"),
    ("数据分析实习生 - 抖音电商", "产品 - 数据分析", "1、构建指标体系和数仓报表，设计 A/B 实验并做归因分析。"),
    ("千川营销数科实习生 - 抖音电商", "产品 - 数据分析", "1、协助数据清洗，维护数据字典，并进行数据查询与提取。"),
    ("数据产品（投放与智能归因方向）实习生 - 抖音", "产品", "1、构建 Agent 的 Benchmark 评测集，并提出 Prompt 调优方案。"),
    ("AI产品实习生（企业级智能体） - 数据平台", "产品 - 产品经理", "1、设计智能体产品架构，包括 Skills、SubAgent 和记忆系统。"),
    ("VLM产品策略与评测产品实习生 - 火山方舟", "产品 - 产品经理", "1、参与视觉理解模型的评测集建设与评分标准设计。"),
    ("AI产品实习生（合规方向） - 集团信息系统", "产品", "1、使用 AI Coding、SQL 和自动化脚本搭建 Agent 工作流。"),
])
def test_includes_evidence_backed_roles(title, category, duties):
    decision, reason = triage_job({"title": title, "raw_category": category, "responsibilities": duties})
    assert decision == "include", reason


@pytest.mark.parametrize("title,category,duties,expected", [
    ("AI搜评测实习生 - TikTok", "运营", "1、按照 SOP 执行搜索结果人工打分，按时完成量化产出。", "review"),
    ("AI内容研究与评测实习生 - TikTok", "运营", "1、协助短剧剧本创作，整理专家对剧情的评测结果。", "include"),
    ("AI数据产品运营实习生 - TikTok", "运营", "1、参与模型数据标注和质量管控，协调项目进度。", "include"),
    ("产品实习生 - 抖音电商", "产品", "1、跟进业务需求，协调产品上线。", "include"),
    ("游戏UI设计实习生 - 游戏", "设计 - UI", "1、制作游戏界面视觉稿。", "include"),
    ("达人营销策略实习生 - AI数据与安全", "运营", "1、策划达人活动并开展商家营销。", "include"),
    ("HR招聘实习生 - 产品研发", "职能 / 支持 - 人力", "1、协助研发团队招聘。", "include"),
    ("AI短剧制片实习生 - 番茄小说", "运营", "1、制作短剧并管理演员。", "include"),
    ("商家运营实习生 - AI数据与安全", "运营", "团队介绍：开发 AI 工具。\n1、处理商家咨询与活动。", "include"),
])
def test_review_and_exclude_boundary_roles(title, category, duties, expected):
    decision, reason = triage_job({"title": title, "raw_category": category, "responsibilities": duties})
    assert decision == expected, reason


def test_missing_title_is_review():
    assert triage_job({"title": "", "raw_category": "研发"})[0] == "review"
