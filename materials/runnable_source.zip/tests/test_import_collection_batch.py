import json

from app.db import connect
from scripts.import_collection_batch import integrate, read_batch


def _row(title, job_id):
    return {
        "company_name": "测试企业",
        "title": title,
        "detail_url": f"https://jobs.example.test/job/{job_id}",
        "source_url": "https://jobs.example.test/internships",
        "source_job_id": job_id,
        "cities": ["北京"],
        "recruitment_type": "实习",
        "collection_method": "browser",
    }


def test_integrate_batch_appends_outputs_updates_database_and_progress(tmp_path, monkeypatch):
    monkeypatch.setenv("INTERNSHIP_DB", str(tmp_path / "jobs.sqlite3"))
    main_path = tmp_path / "jobs.jsonl"
    review_path = tmp_path / "review.jsonl"
    progress_path = tmp_path / "progress.json"
    batch = {
        "company": "测试企业",
        "source_url": "https://jobs.example.test/internships",
        "collection": {
            "pages_read": 2,
            "reported_total": 17,
            "page_counts": [10, 7],
            "target_city_internship_cards": 2,
            "excluded_count": 15,
        },
        "jobs": [_row("算法实习生", "a1")],
        "review_candidates": [_row("AI 产品实习生", "b2")],
    }

    result = integrate(batch, main_path, review_path, progress_path)

    assert result["main_appended"] == 1
    assert result["review_appended"] == 1
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    assert progress["sources"]["测试企业"]["page_counts"] == [10, 7]
    with connect() as con:
        statuses = dict(con.execute("SELECT title, status FROM jobs"))
    assert statuses == {"算法实习生": "active", "AI 产品实习生": "uncertain"}

    repeated = integrate(batch, main_path, review_path, progress_path)
    assert repeated["main_appended"] == 0
    assert repeated["review_appended"] == 0


def test_read_batch_checks_company_and_duplicate_identities(tmp_path):
    batch = {
        "company": "测试企业",
        "source_url": "https://jobs.example.test/internships",
        "collection": {},
        "jobs": [_row("算法实习生", "a1"), _row("另一算法实习生", "a1")],
    }
    path = tmp_path / "batch.json"
    path.write_text(json.dumps(batch), encoding="utf-8")

    try:
        read_batch(path)
    except ValueError as exc:
        assert "duplicate job identity" in str(exc)
    else:
        raise AssertionError("duplicate job identity should be rejected")


def test_integrate_batch_preserves_multiple_list_pagination(tmp_path, monkeypatch):
    monkeypatch.setenv("INTERNSHIP_DB", str(tmp_path / "jobs.sqlite3"))
    batch = {
        "company": "测试企业",
        "source_url": "https://jobs.example.test/internships",
        "collection": {
            "pages_read": 3,
            "reported_total": 14,
            "page_counts": {"日常实习": [10, 1], "专项实习": [3]},
            "target_city_internship_cards": 2,
            "excluded_count": 12,
        },
        "jobs": [_row("算法实习生", "c3")],
    }
    main_path = tmp_path / "jobs.jsonl"
    review_path = tmp_path / "review.jsonl"
    progress_path = tmp_path / "progress.json"

    result = integrate(batch, main_path, review_path, progress_path)

    assert result["main_appended"] == 1
    progress = json.loads(progress_path.read_text(encoding="utf-8"))
    source = progress["sources"]["测试企业"]
    assert source["pages_read"] == 3
    assert source["page_counts"] == [10, 1, 3]
    assert source["page_counts_by_list"] == {"日常实习": [10, 1], "专项实习": [3]}
    assert source["last_raw_count"] == 3
