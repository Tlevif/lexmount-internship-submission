import pytest
from app.classification import classify_content

@pytest.mark.parametrize('title,work,category',[
 ('大模型架构研究实习生','研究大模型架构、MoE和长上下文注意力机制','大模型基模架构与模型研究'),
 ('大模型预训练实习生','研究预训练和scaling law，完成模型训练实验','大模型预训练'),
 ('多模态大模型后训练算法实习生','开发多模态模型，研究SFT、GRPO和强化学习','大模型后训练与强化学习'),
 ('大模型训练框架实习生','开发Megatron分布式训练框架和通信优化','大模型训练系统与算力'),
 ('AI Infra推理方向实习生','开发vLLM模型推理引擎，优化延迟和吞吐','大模型推理优化与部署'),
 ('预训练数据算法实习生','构建大模型训练语料，开发清洗和合成数据管道','大模型数据工程与合成'),
 ('大模型评测算法实习生','开发模型评测框架，构建benchmark和评测集','大模型评测与安全'),
 ('大模型应用算法实习生','研究多模态模型的RAG检索增强和领域微调算法','大模型应用算法'),
 ('Agent算法实习生','研究智能体规划、工具学习与多智能体协作算法','大模型Agent算法'),
 ('Agent开发实习生','开发LangGraph智能体工作流与模型API集成','大模型应用开发'),
 ('多模态算法实习生','研究视频生成和扩散模型，完成模型训练','大模型多模态与生成'),
 ('推荐算法实习生','开发推荐召回与排序模型','推荐搜索与广告算法'),
 ('计算机视觉算法实习生','团队介绍：探索大模型。\n1、开发目标检测算法和图像分割模型','计算机视觉与图像算法'),
 ('前端开发实习生 - 大模型平台','开发React页面组件，接入大模型服务API','前端开发'),
 ('后端开发实习生 - 安全团队','开发后端系统与数据库，维护权限安全机制','后端与分布式服务'),
])
def test_role_deliverable(title,work,category):
    result=classify_content({'title':title,'responsibilities':work,'requirements':'熟悉Python、PyTorch、计算机基础；前端要求React。'})
    assert result['keep'] and result['category']==category,result

def test_llm_bonus_is_not_a_core_task():
    result=classify_content({'title':'推荐算法实习生','responsibilities':'开发召回和排序算法，优化CTR模型','requirements':'熟悉Python和机器学习；加分项：有LLM、SFT经验'})
    assert result['category']=='推荐搜索与广告算法'
