import json

from app.tasks import create_discovery_task, list_tasks
from discovery import worker


def test_worker_records_search_handoff_and_upserts_pending_candidate(tmp_path, monkeypatch):
    db_path = tmp_path / "jobs.sqlite3"
    monkeypatch.setenv("INTERNSHIP_DB", str(db_path))
    directory = tmp_path / "data" / "companies.json"
    directory.parent.mkdir()
    directory.write_text(json.dumps([{"name": "已有公司", "source": "seed", "verification_status": "job_verified"}], ensure_ascii=False), encoding="utf-8")
    monkeypatch.setattr("app.companies.COMPANY_FILE", directory)
    monkeypatch.setattr(worker, "upsert_companies", lambda rows: __import__("app.companies", fromlist=["upsert_companies"]).upsert_companies(rows, path=directory))
    monkeypatch.setattr(worker, "RUN_DIR", tmp_path / "runs")
    monkeypatch.setattr(worker, "run_search", lambda config: {
        "queries_executed": 1,
        "results_observed": 2,
        "candidates": [{
            "name": "新候选科技", "source_url": "https://new.example/careers",
            "career_url": "https://new.example/careers", "source": "web_search:ats",
            "industry_group": "AI",
        }],
    })
    task = create_discovery_task({"target_cities": ["北京"], "search_budget": 1, "candidate_limit": 5})
    persisted_task = next(item for item in list_tasks("discovery") if item["id"] == task["id"])
    result = worker.run_task(persisted_task)
    rows = json.loads(directory.read_text(encoding="utf-8"))
    candidate = next(row for row in rows if row["name"] == "新候选科技")
    assert result["status"] == "completed", result
    assert result["summary"]["inserted"] == 1
    assert candidate["verification_status"] == "pending_verification"
    assert candidate["career_url"] == "https://new.example/careers"
    assert (tmp_path / "runs" / f"{task['id']}.json").exists()
    record = next(item for item in list_tasks("discovery") if item["id"] == task["id"])
    assert any(event.get("agent") == "candidate_discovery" for event in record["events"])
