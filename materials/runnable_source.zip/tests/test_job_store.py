import json

from scripts.job_store import append_unique, existing_fingerprints, mark_page, read_progress, save_progress


def job(company: str, source_id: str) -> dict:
    return {"company_name": company, "title": "算法实习生", "source_job_id": source_id,
            "detail_url": f"https://example.test/position/{source_id}", "cities": ["北京"],
            "recruitment_type": "实习"}


def test_generic_append_is_idempotent_and_adds_other_company(tmp_path):
    path = tmp_path / "jobs.jsonl"
    seen = existing_fingerprints(path)
    assert append_unique(path, [job("甲", "1"), job("甲", "1")], seen) == 1
    assert append_unique(path, [job("甲", "1"), job("乙", "1")], seen) == 1
    reloaded = existing_fingerprints(path)
    assert len(reloaded) == 2
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").split("\n") if line.strip()]
    assert [row["company_name"] for row in rows] == ["甲", "乙"]


def test_jsonl_reader_keeps_unicode_line_separator_inside_record(tmp_path):
    path = tmp_path / "jobs.jsonl"
    seen = existing_fingerprints(path)
    row = job("甲", "u2028")
    row["responsibilities"] = "第一行\u2028第二行\u2029第三行"
    assert append_unique(path, [row], seen) == 1
    assert len(existing_fingerprints(path)) == 1
    text = path.read_text(encoding="utf-8")
    assert len(text.split("\n")) == 2
    assert len(text.splitlines()) > 2


def test_progress_is_company_scoped(tmp_path):
    path = tmp_path / "collection_progress.json"
    progress = read_progress(path)
    mark_page(progress, "甲", 4, 40, 10, 3, 2)
    mark_page(progress, "乙", 1, 5, 5, 2, 1)
    save_progress(path, progress)
    assert read_progress(path)["sources"]["甲"]["last_completed_page"] == 4
    assert read_progress(path)["sources"]["乙"]["last_completed_page"] == 1
