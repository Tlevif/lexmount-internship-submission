from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
capture = json.loads((EVID / "aispeech_internship_capture.json").read_text(encoding="utf-8-sig"))
active = [tab["text"] for tab in capture["active_tabs"] if tab["active"]]
if active != ["实习生岗位"]:
    raise ValueError(f"expected the official internship tab to be active, got {active}")
if "暂无筛选结果" not in capture["summary"]:
    raise ValueError("the current internship list did not explicitly report no results")
if len(capture["rows"]) != 1:
    raise ValueError("the internship results table contains data rows")
if not any(item["checked"] and item["label"] == "全部" for item in capture["city_filters"]):
    raise ValueError("the city filter is not in the all-cities state")
if not any(item["checked"] and item["label"] == "全部" for item in capture["job_type_filters"]):
    raise ValueError("the job type filter is not in the all-types state")

batch = {
    "company": "思必驰",
    "source_url": "https://aispeech.com/about/joinus",
    "source_chain": ["https://aispeech.com/about/joinus"],
    "collection": {
        "method": "使用 Lexmount Cloud Browser 打开思必驰官网招聘页，切换到官网内的“实习生岗位”列表，在全部城市、全部职位类型和全部发布时间条件下检查结果表、城市筛选与官方简历投递说明。",
        "pages_read": 1,
        "reported_total": 0,
        "page_counts": [0],
        "target_city_internship_cards": 0,
        "candidate_details_read": 0,
        "main_count": 0,
        "review_count": 0,
        "excluded_count": 0,
        "session_closed": True,
        "issues": [
            "官网招聘页提供校园招聘、社会招聘、实习生岗位三个入口；实习生岗位当前结果表显示“暂无筛选结果”。城市与职位类型均处于“全部”状态，没有岗位分页或可核验的职位详情。",
            "实习岗位申请方式为邮件发送简历至 hr@aispeech.com；招聘页未发现跳转到官方 ATS 的职位链接。",
            "实习筛选城市选项为上海、北京、苏州、深圳；广州、杭州没有出现在当前城市选项中。",
        ],
    },
    "jobs": [],
    "review_candidates": [],
}
(EVID / "aispeech_batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

summary = {
    "official_site": "https://aispeech.com/",
    "official_recruitment_page": capture["url"],
    "active_recruitment_tab": active[0],
    "internship_result_message": "暂无筛选结果",
    "city_filters": [item["label"] for item in capture["city_filters"]],
    "job_type_filters": [item["label"] for item in capture["job_type_filters"]],
    "filter_state": {"city": "全部", "job_type": "全部", "published_time": "全部"},
    "reported_total": 0,
    "pages_read": 1,
    "page_counts": [0],
    "candidate_details_read": 0,
    "decisions": {"main": 0, "review": 0, "excluded": 0},
    "apply_method": "简历邮件投递至 hr@aispeech.com，邮件标题为岗位、目标工作城市和姓名。",
    "official_ats_link_found": False,
    "browser_session_closed": True,
}
(EVID / "aispeech_classification_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Wrote zero-result internship batch: pages=1 positions=0 main=0 review=0")
