param([string]$SessionId='session_7ee14698-fa71-43a3-967b-2881a6e3e23c',[int]$PageCount=4,[string]$OutputFile='evidence/collector/huya_mokahr_list_pages_raw.json')
$ErrorActionPreference='Stop'
$cli='C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$pages=[System.Collections.Generic.List[object]]::new()
for($p=1;$p -le $PageCount;$p++){
 $r=& $cli action eval --session-id $SessionId --expression 'JSON.stringify({url:location.href,page:Number(document.querySelector(".pagination-item.active-2punE9UQ7w")?.innerText||document.querySelector(".pagination-item[class*=active]")?.innerText),cards:[...document.querySelectorAll("a")].filter(a=>a.querySelector(".title-20V7ljm-Id")).map(a=>({title:a.querySelector(".title-20V7ljm-Id")?.innerText.trim(),detail_url:a.href,labels:[...a.querySelectorAll(".status-item-1_w5ygMyMO")].map(x=>x.innerText.trim()),city:a.querySelector(".locations-32aEgVWFz_")?.innerText.trim(),published_at:(a.querySelector(".opened-at-20H_gh2Tqd")?.innerText.match(/\d{4}-\d{2}-\d{2}/)||[])[0]||null}))})'|ConvertFrom-Json
 if(!$r.ok){throw "Read failed page $p"}; $data=$r.data|ConvertFrom-Json
 if($data.page -ne $p){throw "Expected page $p but got $($data.page)"}
 $pages.Add($data); $pages|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $OutputFile -Encoding utf8
 Write-Output "Captured page ${p}: $($data.cards.Count) cards"
 if($p -lt $PageCount){$selector=".theme-pagination .pagination-item:nth-child($($p+2))"; $ck=& $cli action click --session-id $SessionId --selector $selector|ConvertFrom-Json; if(!$ck.ok){throw "Pagination click failed from $p"}; Start-Sleep -Seconds 1}
}
$count=($pages|%{$_.cards.Count}|Measure-Object -Sum).Sum
Write-Output "Captured $($pages.Count) pages / $count cards"


