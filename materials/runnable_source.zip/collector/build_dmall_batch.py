from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
cards_data = json.loads((EVID / "dmall_list_pages_raw.json").read_text(encoding="utf-8-sig"))
keyword = json.loads((EVID / "dmall_intern_keyword_filter_capture.json").read_text(encoding="utf-8-sig"))
city_results = json.loads((EVID / "dmall_city_filter_results.json").read_text(encoding="utf-8-sig"))
filter_capture = json.loads((EVID / "dmall_filter_options_capture.json").read_text(encoding="utf-8-sig"))
details = json.loads((EVID / "dmall_relevant_details_raw.json").read_text(encoding="utf-8-sig"))
cards = cards_data["cards"]
if len(cards) != 8 or len({c["detail_url"] for c in cards}) != 8:
    raise ValueError("expected 8 unique current openings")
if any("全职" not in c["visible_text"] for c in cards):
    raise ValueError("a listed position is not clearly labeled full-time")
if keyword["cards"] != 0 or "keywords=%E5%AE%9E%E4%B9%A0" not in keyword["url"]:
    raise ValueError("internship keyword query did not return zero")
if len(details) != 2 or any("全职" not in d["detail_text"] for d in details):
    raise ValueError("review detail evidence incomplete or conflicts with full-time status")
expected_city_counts = {"北京": 2, "上海": 1, "深圳": 1}
if {x["city"]: x["count"] for x in city_results} != expected_city_counts:
    raise ValueError("unexpected target city filter counts")
batch = {
  "company": "多点数智",
  "source_url": "https://duodian.jobs.feishu.cn/dmall",
  "collection": {
    "method": "Lexmount Cloud Browser 打开多点数智官网“了解职位”明确链接的飞书招聘系统；读取所有当前职位卡、城市筛选选项和分页状态，以“实习”关键词搜索，并打开北京网络运维和AI相关岗位详情核验用工性质。",
    "pages_read": 1,
    "reported_total": 8,
    "page_counts": [8],
    "target_city_internship_cards": 0,
    "excluded_count": 8,
    "candidate_details_read": 2,
    "session_closed": True,
    "issues": [
      "多点数智官网清单页 https://digital-website-v2.dmall.com/topic/career 的“了解职位”链接指向该飞书 ATS。",
      "当前 ATS 显示“开启新的工作（8）”，8条职位均为全职；只显示第1页，无后续分页。关键词“实习”搜索返回0条。",
      "城市筛选当前有北京、上海、深圳、武汉、成都、帕赛市；广州和杭州没有城市筛选项。北京筛选2条、上海1条、深圳1条，职位卡均显示全职。",
      "核验AI Harness Engineer详情（成都，要求5年以上软件开发经验）及网络运维工程师详情（北京，要求3年以上网络运维经验），均为全职。",
      "ATS未列出实习岗位，因此主结果与待判断岗位均为0；当前8条全职职位不符合实习岗位目标。"
    ]
  },
  "jobs": [],
  "review_candidates": []
}
(EVID / "dmall_batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
city_counts = {x["city"]: x["count"] for x in city_results}
summary = {
  "official_career_url": "https://digital-website-v2.dmall.com/topic/career",
  "official_linked_ats": "https://duodian.jobs.feishu.cn/dmall",
  "current_opening_count": 8,
  "pages_read": 1,
  "page_counts": [8],
  "pagination": {"current_page": 1, "visible_page_items": ["1"], "has_next_page": False},
  "filter_options": filter_capture.get("city_options", []),
  "target_cities_without_filter_option": [city for city in ("广州", "杭州") if city not in filter_capture.get("city_options", [])],
  "target_city_filter_counts": city_counts,
  "internship_keyword_query": {"url": keyword["url"], "count": 0},
  "decisions": {"accepted": 0, "review": 0, "excluded_non_internship": 8},
  "checked_details": details,
  "listing_cards": [
    {**card, "decision": "excluded_non_internship", "reason": "官方职位卡标注全职；不属于目标实习岗位。"}
    for card in cards
  ]
}
(EVID / "dmall_classification_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Wrote zero-result batch: pages=1 positions=8 main=0 review=0; details checked=2")



