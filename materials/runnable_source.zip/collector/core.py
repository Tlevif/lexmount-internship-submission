"""Lexmount CLI integration. Only collect pages explicitly configured by discovery."""

from __future__ import annotations

import json
import math
import os
import re
import subprocess
import time
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs, urlunparse

from bs4 import BeautifulSoup
from app.core import classify_business_role


BROWSER = Path(os.getenv("LEXMOUNT_BROWSER_CLI", r"C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"))
WEBFETCH = Path(os.getenv("LEXMOUNT_WEBFETCH_CLI", r"C:\Users\Lenovo\.agents\skills\lexmount-webfetch\bin\webfetch-cli.exe"))
TARGET_CITIES = ("北京", "上海", "广州", "深圳", "杭州")
TECH_CATEGORY_HINTS = ("研发", "算法", "技术", "软件工程", "数据工程", "安全工程", "工程")
TECH_TITLE_HINTS = ("算法", "机器学习", "深度学习", "大模型", "开发", "编译器", "计算机视觉", "自然语言处理", "数据工程", "数据科学", "数据分析", "架构工程", "基础架构", "推荐策略", "网络安全", "人工智能", "AI全栈", "Agent自动评测", "Agent评测与工程", "计算语言学")


class CollectionError(RuntimeError):
    pass


def _run(binary: Path, *args: str, retries: int = 1) -> dict:
    if not binary.is_file():
        raise CollectionError(f"Lexmount CLI unavailable: {binary}")
    for attempt in range(retries + 1):
        proc = subprocess.run([str(binary), *map(str, args)], capture_output=True, text=True, encoding="utf-8", timeout=90)
        try:
            payload = json.loads(proc.stdout)
        except json.JSONDecodeError as exc:
            raise CollectionError(f"Invalid Lexmount response: {proc.stderr[:200]}") from exc
        if proc.returncode == 0 and payload.get("ok") is not False and not payload.get("error"):
            return payload
        if attempt < retries:
            time.sleep(1 + attempt)
    raise CollectionError(f"Lexmount command failed: {payload.get('error') or proc.stderr[:200]}")


def _filtered_cities(raw: str) -> list[str]:
    return [city for city in TARGET_CITIES if city in raw]


def _feishu_category(meta: str) -> str:
    """Read the job-family text between internship type and the card's position ID."""
    prefix = meta.split("职位 ID", 1)[0]
    marker = prefix.rfind("实习")
    if marker < 0:
        return ""
    return re.sub(r"\d{4}校园招聘.*$", "", prefix[marker + len("实习"):]).strip()


def is_catalog_eligible_job(title: str, category: str, responsibilities: str | None = None) -> bool:
    """Accept technical roles and business roles with a clear work-family label."""
    if classify_business_role({"title": title, "raw_category": category, "responsibilities": responsibilities}):
        return True
    return any(x in category for x in TECH_CATEGORY_HINTS) or any(x in title for x in TECH_TITLE_HINTS)


def _new_card_ids(cards: list[dict], seen: set[str]) -> list[tuple[dict, str]]:
    """Track pagination independently of relevance so nontechnical pages do not end a run."""
    fresh = []
    for card in cards:
        match = re.search(r"/position/(\d+)/detail", card.get("href", ""))
        if match and match.group(1) not in seen:
            seen.add(match.group(1))
            fresh.append((card, match.group(1)))
    return fresh


def _verified_source(config: dict) -> str:
    url = config.get("career_url") or config.get("url")
    if not url or urlparse(url).scheme not in {"http", "https"}:
        raise CollectionError("Config lacks absolute career_url")
    if not config.get("verified_for_collection"):
        raise CollectionError("Site is not marked verified_for_collection")
    return url


def collect_company(config: dict) -> list[dict]:
    """Collect a bounded set of current internship postings from a verified source."""
    _verified_source(config)
    adapter = config.get("adapter") or config.get("collection_method")
    if adapter == "bytedance_campus":
        return _bytedance_campus(config)
    if adapter == "feishu_jobs":
        return _feishu_jobs(config)
    if adapter == "mokahr_campus":
        return _mokahr_campus(config)
    if adapter in {"webfetch_css", "webfetch"}:
        return _webfetch_css(config)
    raise CollectionError(f"Unsupported adapter: {adapter}")


def _browser_eval(session: str, target: str, expression: str):
    reply = _run(BROWSER, "action", "eval", "--session-id", session, "--target-id", target, "--expression", expression)
    value = reply["data"]
    return json.loads(value) if isinstance(value, str) else value


def _page_url(base: str, page: int, limit: int, project: str) -> str:
    parsed = urlparse(base)
    query = parse_qs(parsed.query)
    query.update({"project": [project], "current": [str(page)], "limit": [str(limit)]})
    return urlunparse(parsed._replace(query=urlencode(query, doseq=True)))


BYTE_CARDS_JS = r'''JSON.stringify({
  url: location.href,
  total: Number((document.body.innerText.match(/开启新的工作（(\d+)）/)||[])[1]||0),
  cards: [...document.querySelectorAll('a[href*="/campus/position/"]')].map(a => {
    const box=a.querySelector('.positionItem')||a;
    const info=box.querySelector('.positionItem-subTitle');
    return {
      title:box.querySelector('.positionItem-title-text')?.textContent?.trim()||'',
      href:a.href,
      city:info?.querySelector('span')?.textContent?.trim()||'',
      meta:info?.innerText||'',
      category:info?.querySelector('[class*="infoText-category"]')?.textContent?.trim()||'',
      description:box.querySelector('.positionItem-jobDesc')?.textContent?.trim()||''
    };
  })
})'''


FEISHU_CARDS_JS = r'''JSON.stringify({
  url: location.href,
  total: Number((document.body.innerText.match(/开启新的工作（(\d+)）/)||[])[1]||0),
  cards: [...document.querySelectorAll('a[href*="/position/"]')].filter(a=>a.querySelector('.positionItem-title-text')).map(a => {
    const box=a.querySelector('.positionItem')||a;
    const info=box.querySelector('.positionItem-subTitle');
    const fields=[...(info?.querySelectorAll('[class*="infoText"]')||[])].map(e=>e.textContent.trim());
    return {
      title:box.querySelector('.positionItem-title-text')?.textContent?.trim()||'',
      href:a.href,
      city:info?.querySelector('span')?.textContent?.trim()||'',
      meta:info?.innerText||'',
      category:(()=>{const meta=info?.innerText||'';const prefix=meta.split('职位 ID')[0];const marker=prefix.lastIndexOf('实习');return marker<0?'':prefix.slice(marker+2).replace(/\d{4}校园招聘.*$/,'').trim()})()||fields.at(-1)||'',
      description:box.querySelector('.positionItem-jobDesc')?.textContent?.trim()||''
    };
  })
})'''


MOKAHR_CARDS_JS = r'''JSON.stringify({
  url: location.href,
  title: document.title,
  total: Number((document.body.innerText.match(/(\d+)\s*结果/)||[])[1]||0),
  cards: [...document.querySelectorAll('a[href*="#/job/"]')]
    .map(a => {
      const description = a.querySelector('[class*="job-description"]');
      const title = a.querySelector('[class*="title-"]');
      const fullDescription = a.querySelector('[class*="expand-area"]') || description || a.querySelector('[class*="short-description"]');
      const descriptionText = fullDescription?.innerText?.trim() || '';
      const info = a.querySelector('[class*="info-"]');
      const metaText = info?.innerText?.trim() || '';
      return {
        title: title?.innerText?.trim() || '',
        href: a.href,
        meta: metaText,
        description: descriptionText,
        published_at: a.querySelector('[class*="published-at"]')?.innerText?.trim() || ''
      };
    })
    .filter(card => card.description)
})'''


def _split_mokahr_description(description: str) -> tuple[str | None, str | None]:
    """Split the visible Moka description at explicit responsibility/requirement headings."""
    text = re.sub(r"\n{3,}", "\n\n", (description or "").strip())
    req = re.search(r"(?:任职要求|职位要求|岗位要求|任职资格|岗位要求|职位资格)\s*[:：]?", text)
    if not req:
        responsibility = re.sub(r"^(?:岗位职责|工作职责|职位描述|工作内容|主要职责)\s*[:：]?\s*", "", text)
        return (responsibility or None, None)
    responsibility = text[:req.start()].strip()
    responsibility = re.sub(r"^(?:岗位职责|工作职责|职位描述|工作内容|主要职责)\s*[:：]?\s*", "", responsibility)
    requirements = text[req.end():].strip()
    return (responsibility or None, requirements or None)


def _mokahr_card_job(config: dict, card: dict, page_url: str, total: int, session: str) -> dict:
    match = re.search(r"#/job/([0-9a-f-]{36})(?:$|[?#])", card.get("href", ""), re.I)
    if not match:
        raise CollectionError(f"Moka card lacks stable UUID: {card.get('href', '')}")
    meta = card.get("meta", "")
    # City values come only from the rendered card metadata, never from title/body inference.
    cities = [city for city in TARGET_CITIES if re.search(re.escape(city) + r"(?:市)?", meta)]
    responsibility, requirements = _split_mokahr_description(card.get("description", ""))
    published = re.search(r"发布于\s*(\d{4}-\d{2}-\d{2})", card.get("published_at", "") or meta)
    labels = [x.strip() for x in re.split(r"[|\n]", meta) if x.strip()]
    raw_category = next((x for x in labels if x.endswith("类")), None)
    return {
        "company_name": config.get("company_name") or config.get("name"),
        "company_website": config.get("company_website") or config.get("website"),
        "career_url": config["career_url"],
        "title": card.get("title", "").strip(),
        "detail_url": card["href"],
        "source_url": page_url,
        "source_job_id": match.group(1),
        "cities": cities,
        "recruitment_type": "实习" if "实习" in meta else None,
        "raw_category": raw_category,
        "responsibilities": responsibility,
        "requirements": requirements,
        "published_at": published.group(1) if published else None,
        "collection_method": "browser",
        "raw_payload": {
            "site_meta": meta,
            "site_total": total,
            "browser_session_id": session,
            "responsibility_source": "rendered card description",
            "requirements_source": "rendered card description" if requirements else None,
        },
    }


def _mokahr_campus(config: dict) -> list[dict]:
    """Collect a single rendered Moka campus job-list page through Cloud Browser."""
    url = _verified_source(config)
    parsed = urlparse(url)
    if parsed.hostname != "app.mokahr.com" or "/campus-recruitment/" not in parsed.path:
        raise CollectionError("mokahr_campus requires a verified app.mokahr.com campus recruitment URL")
    if "#/jobs" not in url or not parse_qs(url.split("#", 1)[1].partition("?")[2]).get("project"):
        raise CollectionError("mokahr_campus requires an explicit jobs project URL")
    expected_project = parse_qs(url.split("#", 1)[1].partition("?")[2])["project"][0]
    session = config.get("browser_session_id")
    created_session = not session
    jobs: list[dict] = []
    try:
        if created_session:
            session = _run(BROWSER, "session", "create")["data"]["session_id"]
            _run(BROWSER, "action", "open-url", "--session-id", session, "--url", url)
        targets = _run(BROWSER, "session", "targets", "--session-id", session)["data"]
        matches = [t for t in targets if t.get("type") == "page" and t.get("url", "").startswith(parsed.scheme + "://" + parsed.netloc + parsed.path)]
        if len(matches) != 1:
            raise CollectionError(f"Expected one Moka recruitment page, found {len(matches)}")
        target = matches[0]["id"]
        _run(BROWSER, "action", "wait-selector", "--session-id", session, "--target-id", target,
             "--selector", 'a[href*="#/job/"] [class*="job-description"]', "--timeout-ms", "15000", retries=2)
        result = _browser_eval(session, target, MOKAHR_CARDS_JS)
        if "app.mokahr.com" not in result.get("url", "") or "#/jobs" not in result.get("url", ""):
            raise CollectionError("rendered page is not the configured Moka job list")
        rendered_project = parse_qs(result["url"].split("#", 1)[1].partition("?")[2]).get("project", [None])[0]
        if rendered_project != expected_project:
            raise CollectionError("rendered Moka project does not match configured job list")
        total, cards = result.get("total"), result.get("cards")
        if not isinstance(total, int) or total <= 0 or not isinstance(cards, list) or len(cards) != total:
            raise CollectionError(f"Moka rendered card count {len(cards) if isinstance(cards, list) else 'invalid'} differs from reported total {total}")
        seen: set[str] = set()
        for card in cards:
            item = _mokahr_card_job(config, card, result["url"], total, session)
            if item["source_job_id"] in seen:
                raise CollectionError(f"Moka list contains duplicate stable UUID {item['source_job_id']}")
            seen.add(item["source_job_id"])
            if not item["title"] or item["recruitment_type"] != "实习":
                continue
            if item["cities"]:
                jobs.append(item)
        return jobs
    except Exception as exc:
        if isinstance(exc, CollectionError):
            raise
        raise CollectionError(f"Moka page collection failed: {exc}") from exc
    finally:
        if created_session and session:
            _close_browser_session(session)


def _byte_job(config: dict, card: dict, source_id: str, page_url: str, page: int, total: int, session: str) -> dict:
    return {
        "company_name": config.get("name") or config.get("company_name") or "字节跳动",
        "company_website": "https://www.bytedance.com/",
        "career_url": config["career_url"],
        "title": card["title"],
        "detail_url": card["href"],
        "source_url": page_url,
        "source_job_id": source_id,
        "cities": _filtered_cities(card["city"]),
        "recruitment_type": "实习",
        "raw_category": card["category"],
        "responsibilities": card["description"],
        "requirements": None,
        "published_at": None,
        "collection_method": "browser",
        "raw_payload": {"site_meta": card["meta"], "site_total": total, "page": page, "browser_session_id": session},
    }


def _check_byte_page(result: dict, page: int, limit: int, project: str, seen: set[str]) -> tuple[int, list[tuple[dict, str]]]:
    query = parse_qs(urlparse(result.get("url", "")).query)
    if query.get("project") != [project] or query.get("current") != [str(page)] or query.get("limit") != [str(limit)]:
        raise CollectionError("rendered URL does not match requested project/page/limit")
    total = result.get("total")
    if not isinstance(total, int) or total <= 0:
        raise CollectionError("missing or invalid site total")
    cards = result.get("cards")
    if not isinstance(cards, list) or not cards:
        raise CollectionError("empty rendered job page")
    if page > math.ceil(total / limit):
        raise CollectionError(f"requested page exceeds site total: {total}")
    expected = min(limit, total - (page - 1) * limit)
    if len(cards) != expected:
        raise CollectionError(f"page card count {len(cards)} differs from expected {expected} (site total {total})")
    fresh = _new_card_ids(cards, seen)
    if len(fresh) != len(cards):
        raise CollectionError(f"missing or repeated stable job IDs: {len(fresh)}/{len(cards)}")
    return total, fresh


def _close_browser_session(session: str) -> None:
    for attempt in range(12):
        try:
            if attempt in (0, 5):
                _run(BROWSER, "session", "close", "--session-id", session, retries=0)
            state = _run(BROWSER, "session", "get", "--session-id", session, retries=0)
            if state.get("data", {}).get("status") == "closed":
                return
        except Exception:
            pass
        time.sleep(1)
    raise CollectionError(f"Cloud Browser session could not be verified closed: {session}")


def iter_company_pages(config: dict, start_page: int = 1, end_page: int | None = None):
    """Yield each page in a verified source range; exhaust or close the generator.

    With end_page=None, the observed site total determines the final page. Callers
    that stop early must call generator.close() (or use contextlib.closing).
    """
    url = _verified_source(config)
    if not isinstance(start_page, int) or start_page < 1 or (end_page is not None and (not isinstance(end_page, int) or end_page < start_page)):
        raise CollectionError("invalid inclusive page range")
    if config.get("adapter") == "feishu_jobs":
        yield from _iter_feishu_pages(config, url, start_page, end_page)
        return
    if config.get("adapter") != "bytedance_campus" or urlparse(url).netloc != "jobs.bytedance.com":
        raise CollectionError("iter_company_pages requires a supported verified source")
    project = str(config.get("project_id", "7194661644654577981"))
    limit = int(config.get("page_size", 10))
    if limit != 10:
        raise CollectionError("Only the verified page_size=10 is supported")
    session = None
    seen: set[str] = set()
    max_seen_total = 0
    try:
        session = _run(BROWSER, "session", "create")["data"]["session_id"]
        first_url = _page_url(url, start_page, limit, project)
        _run(BROWSER, "action", "open-url", "--session-id", session, "--url", first_url)
        targets = _run(BROWSER, "session", "targets", "--session-id", session)["data"]
        matches = [t for t in targets if t.get("type") == "page" and t.get("url", "").startswith("https://jobs.bytedance.com/campus/position")]
        if len(matches) != 1:
            raise CollectionError(f"Expected one ByteDance jobs page, found {len(matches)}")
        target = matches[0]["id"]
        page = start_page
        while True:
            try:
                page_url = _page_url(url, page, limit, project)
                if page > start_page:
                    _run(BROWSER, "action", "open-url", "--session-id", session, "--target-id", target, "--url", page_url)
                _run(BROWSER, "action", "wait-selector", "--session-id", session, "--target-id", target, "--selector", 'a[href*="/campus/position/"]', "--timeout-ms", "15000", retries=2)
                result = _browser_eval(session, target, BYTE_CARDS_JS)
                total, fresh = _check_byte_page(result, page, limit, project, seen)
                max_seen_total = max(max_seen_total, total)
                if end_page is not None and page == start_page and end_page > math.ceil(total / limit):
                    raise CollectionError(f"end_page {end_page} exceeds site pages {math.ceil(total / limit)}")
                jobs, review = [], []
                for card, source_id in fresh:
                    if "实习" not in card["meta"] or not card["title"] or not _filtered_cities(card["city"]):
                        continue
                    item = _byte_job(config, card, source_id, page_url, page, total, session)
                    (jobs if is_catalog_eligible_job(card["title"], card["category"], item.get("responsibilities")) else review).append(item)
                yield {"page": page, "page_url": page_url, "reported_total": total, "raw_count": len(result["cards"]), "eligible_count": len(jobs) + len(review), "jobs": jobs, "review_candidates": review, "excluded_count": len(result["cards"]) - len(jobs) - len(review), "session_id": session}
                if page >= (end_page if end_page is not None else math.ceil(max_seen_total / limit)):
                    break
                page += 1
            except Exception as exc:
                raise CollectionError(f"ByteDance page {page} failed: {exc}") from exc
    finally:
        if session:
            _close_browser_session(session)


def _iter_feishu_pages(config: dict, url: str, start_page: int, end_page: int | None):
    """Yield verified Feishu ATS pages with the same main/review split as ByteDance."""
    if not urlparse(url).hostname.endswith(".jobs.feishu.cn"):
        raise CollectionError("feishu_jobs requires a jobs.feishu.cn host")
    limit = min(max(int(config.get("page_size", 10)), 1), 20)
    max_pages = min(max(int(config.get("max_pages", 1)), 1), 20)
    if start_page > max_pages or (end_page is not None and end_page > max_pages):
        raise CollectionError(f"requested page range exceeds configured max_pages={max_pages}")
    session = None
    seen: set[str] = set()
    max_seen_total = 0
    observed_totals: set[int] = set()
    parsed = urlparse(url)
    base_page_url = urlunparse(parsed._replace(query=""))
    try:
        session = _run(BROWSER, "session", "create")["data"]["session_id"]
        for page in range(start_page, (end_page if end_page is not None else max_pages) + 1):
            try:
                query = parse_qs(parsed.query)
                query.update({"current": [str(page)], "limit": [str(limit)]})
                page_url = urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
                _run(BROWSER, "action", "open-url", "--session-id", session, "--url", page_url)
                targets = _run(BROWSER, "session", "targets", "--session-id", session)["data"]
                matches = [t for t in targets if t.get("type") == "page" and t.get("url", "").startswith(base_page_url)]
                if len(matches) != 1:
                    raise CollectionError(f"Expected one Feishu jobs page, found {len(matches)}")
                target = matches[0]["id"]
                _run(BROWSER, "action", "wait-selector", "--session-id", session, "--target-id", target,
                     "--selector", 'a[href*="/position/"] .positionItem-title-text', "--timeout-ms", "15000", retries=1)
                result = _browser_eval(session, target, FEISHU_CARDS_JS)
                total = result.get("total")
                cards = result.get("cards", [])
                if not isinstance(total, int) or total < 0:
                    raise CollectionError("Feishu page did not expose a valid reported total")
                rendered_query = parse_qs(urlparse(result.get("url", "")).query)
                if rendered_query and (rendered_query.get("current") != [str(page)] or rendered_query.get("limit") != [str(limit)]):
                    raise CollectionError("rendered Feishu URL does not match requested page and limit")
                observed_totals.add(total)
                if len(observed_totals) > 1:
                    raise CollectionError(f"Feishu reported total changed during crawl: {sorted(observed_totals)}")
                fresh = _new_card_ids(cards, seen)
                if len(fresh) != len(cards):
                    raise CollectionError(f"Feishu page {page} contains missing or duplicate stable position IDs")
                max_seen_total = max(max_seen_total, total)
                if end_page is not None and page == start_page and end_page > math.ceil(total / limit):
                    raise CollectionError(f"end_page {end_page} exceeds site pages {math.ceil(total / limit)}")
                jobs, review = [], []
                for card, source_id in fresh:
                    if "实习" not in card.get("meta", "") or not card.get("title"):
                        continue
                    cities = _filtered_cities(card.get("city", ""))
                    if not cities:
                        continue
                    item = {
                        "company_name": config.get("company_name") or config.get("name"),
                        "company_website": config.get("company_website") or config.get("source_career_url"),
                        "career_url": url,
                        "title": card["title"],
                        "detail_url": card["href"],
                        "source_url": page_url,
                        "source_job_id": source_id,
                        "cities": cities,
                        "recruitment_type": "实习",
                        "raw_category": card.get("category"),
                        "responsibilities": card.get("description"),
                        "requirements": None,
                        "published_at": None,
                        "collection_method": "browser",
                        "raw_payload": {"site_meta": card.get("meta"), "site_total": total, "page": page, "browser_session_id": session},
                    }
                    if is_catalog_eligible_job(item["title"], item["raw_category"] or "", item.get("responsibilities")):
                        jobs.append(item)
                    else:
                        item["raw_payload"]["review_reason"] = (
                            f"目标城市实习岗位；标题“{item['title']}”及官网职能“{item['raw_category'] or '未分类'}” "
                            "未命中技术岗位规则，需人工确认职责是否属于 AI、计算机或泛计算机方向。"
                        )
                        review.append(item)
                yield {"page": page, "page_url": page_url, "reported_total": total, "raw_count": len(cards),
                       "eligible_count": len(jobs) + len(review), "jobs": jobs, "review_candidates": review,
                       "excluded_count": len(cards) - len(jobs) - len(review),
                       "card_ids": [source_id for _, source_id in fresh], "session_id": session}
                expected_pages = math.ceil(max_seen_total / limit) if max_seen_total else 0
                if page >= (end_page if end_page is not None else expected_pages):
                    break
            except Exception as exc:
                raise CollectionError(f"Feishu page {page} failed: {exc}") from exc
    finally:
        if session:
            _close_browser_session(session)


def _bytedance_campus(config: dict) -> list[dict]:
    max_pages = int(config.get("max_pages", 1))
    if max_pages < 1:
        raise CollectionError("max_pages must be positive")
    pages = iter_company_pages(config, 1, max_pages)
    try:
        return [job for batch in pages for job in batch["jobs"]]
    finally:
        pages.close()


def _feishu_jobs(config: dict) -> list[dict]:
    """Collect a bounded, verified Feishu ATS internship list via Cloud Browser."""
    url = _verified_source(config)
    if not urlparse(url).hostname.endswith(".jobs.feishu.cn"):
        raise CollectionError("feishu_jobs requires a jobs.feishu.cn host")
    max_pages = min(max(int(config.get("max_pages", 1)), 1), 5)
    limit = min(max(int(config.get("page_size", 10)), 1), 20)
    session = None
    jobs: list[dict] = []
    try:
        session = _run(BROWSER, "session", "create")["data"]["session_id"]
        seen: set[str] = set()
        parsed = urlparse(url)
        for page in range(1, max_pages + 1):
            query = parse_qs(parsed.query)
            query.update({"current": [str(page)], "limit": [str(limit)]})
            page_url = urlunparse(parsed._replace(query=urlencode(query, doseq=True)))
            _run(BROWSER, "action", "open-url", "--session-id", session, "--url", page_url)
            targets = _run(BROWSER, "session", "targets", "--session-id", session)["data"]
            matches = [t for t in targets if t.get("type") == "page" and t.get("url", "").startswith(urlunparse(parsed._replace(query="")))]
            if len(matches) != 1:
                raise CollectionError(f"Expected one Feishu jobs page, found {len(matches)}")
            target = matches[0]["id"]
            _run(BROWSER, "action", "wait-selector", "--session-id", session, "--target-id", target, "--selector", 'a[href*="/position/"] .positionItem-title-text', "--timeout-ms", "15000", retries=1)
            result = _browser_eval(session, target, FEISHU_CARDS_JS)
            cards = result.get("cards", [])
            if not cards:
                if page == 1:
                    raise CollectionError("No rendered Feishu job cards")
                break
            fresh = _new_card_ids(cards, seen)
            for card, source_id in fresh:
                if "实习" not in card["meta"] or not card["title"]:
                    continue
                if not is_catalog_eligible_job(card["title"], card["category"], card.get("description")):
                    continue
                cities = _filtered_cities(card["city"])
                if not cities:
                    continue
                jobs.append({
                    "company_name": config.get("company_name") or config.get("name"),
                    "company_website": config.get("company_website") or config.get("source_career_url"),
                    "career_url": url,
                    "title": card["title"],
                    "detail_url": card["href"],
                    "source_url": page_url,
                    "source_job_id": source_id,
                    "cities": cities,
                    "recruitment_type": "实习",
                    "raw_category": card["category"],
                    "responsibilities": card["description"],
                    "requirements": None,
                    "published_at": None,
                    "collection_method": "browser",
                    "raw_payload": {"site_meta": card["meta"], "site_total": result.get("total"), "page": page, "browser_session_id": session},
                })
            if not fresh or (result.get("total", 0) > 0 and page * limit >= result["total"]):
                break
        return jobs
    finally:
        if session:
            closed = False
            for attempt in range(12):
                try:
                    if attempt in (0, 5):
                        _run(BROWSER, "session", "close", "--session-id", session, retries=0)
                    state = _run(BROWSER, "session", "get", "--session-id", session, retries=0)
                    if state.get("data", {}).get("status") == "closed":
                        closed = True
                        break
                except Exception:
                    pass
                time.sleep(1)
            if not closed:
                raise CollectionError(f"Cloud Browser session could not be closed: {session}")


def _webfetch_css(config: dict) -> list[dict]:
    """Extract simple public HTML; reject pages that contain no actual job nodes."""
    url = _verified_source(config)
    selectors = config.get("selectors") or {}
    if not all(selectors.get(k) for k in ("card", "title", "link")):
        raise CollectionError("webfetch_css requires card/title/link selectors")
    reply = _run(WEBFETCH, "dump-dom", "--url", url, "--format", "json")
    data = reply.get("data", reply)
    soup = BeautifulSoup(data.get("html") or "", "html.parser")
    jobs: list[dict] = []
    for card in soup.select(selectors["card"]):
        title_node = card.select_one(selectors["title"])
        link_node = card.select_one(selectors["link"])
        if not title_node or not link_node:
            continue
        title = title_node.get_text(" ", strip=True)
        type_node = card.select_one(selectors.get("type", "")) if selectors.get("type") else None
        recruitment_type = type_node.get_text(" ", strip=True) if type_node else ""
        if "实习" not in title and "实习" not in recruitment_type:
            continue
        city_node = card.select_one(selectors.get("city", "")) if selectors.get("city") else None
        cities = _filtered_cities(city_node.get_text(" ", strip=True) if city_node else card.get_text(" ", strip=True))
        if not cities:
            continue
        from urllib.parse import urljoin
        detail = urljoin(url, link_node.get("href", ""))
        jobs.append({"company_name": config.get("name") or config.get("company_name"), "company_website": config.get("website"), "career_url": url, "title": title, "detail_url": detail, "source_url": url, "source_job_id": None, "cities": cities, "recruitment_type": "实习", "raw_category": None, "responsibilities": None, "requirements": None, "published_at": None, "collection_method": "webfetch", "raw_payload": {"dom_id": data.get("dom_id"), "request_id": data.get("request_id")}})
    return jobs
