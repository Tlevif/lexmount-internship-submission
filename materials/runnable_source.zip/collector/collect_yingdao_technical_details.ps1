param([string]$SessionId = "session_fcba870f-3fb3-4e29-89f1-e7dba2cb2105")

$ErrorActionPreference = "Stop"
$Browser = "C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"
$Root = Split-Path $PSScriptRoot -Parent
$Evidence = Join-Path $Root "evidence\collector"

function Invoke-Browser([string[]]$Arguments) {
    $output = & $Browser @Arguments
    if ($LASTEXITCODE -ne 0) { throw "browser-cli failed: $($output -join "`n")" }
    return (($output -join "`n") | ConvertFrom-Json)
}

$candidatePattern = '^(RPA工程师|python技术支持|RPA实施工程师|测试工程师|运维工程师|JAVA 工程师|在线工程师)$'
$targetCities = '杭州|上海|北京|深圳|广州'
$candidates = foreach ($path in Get-ChildItem (Join-Path $Evidence "yingdao_page_*.json")) {
    $page = Get-Content -LiteralPath $path.FullName -Raw | ConvertFrom-Json
    foreach ($card in $page.cards) {
        $lines = @($card.card_text -split "`n" | Where-Object { $_.Trim() })
        $title = $lines[0]
        $metadata = $lines[1]
        if ($title -match $candidatePattern -and $metadata -match $targetCities) {
            [pscustomobject]@{ title = $title; metadata = $metadata; detail_url = $card.detail_url; page = $page.page; card_text = $card.card_text }
        }
    }
}

$details = foreach ($candidate in $candidates) {
    Invoke-Browser @("action", "open-url", "--session-id", $SessionId, "--url", $candidate.detail_url) | Out-Null
    Invoke-Browser @("action", "wait-text", "--session-id", $SessionId, "--text", $candidate.title, "--timeout-ms", "15000") | Out-Null
    $result = Invoke-Browser @("action", "eval", "--session-id", $SessionId, "--expression", 'JSON.stringify({url:location.href,title:document.title,text:document.body.innerText})')
    $data = $result.data | ConvertFrom-Json
    [pscustomobject]@{ title = $candidate.title; metadata = $candidate.metadata; page = $candidate.page; detail_url = $candidate.detail_url; card_text = $candidate.card_text; detail_text = $data.text; captured_url = $data.url }
    Write-Host ("Read detail: {0} ({1})" -f $candidate.title, $candidate.metadata)
}

$details | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $Evidence "yingdao_technical_details.json") -Encoding utf8
