param([string]$SessionId = "session_ab6f8e30-93b9-4068-bb44-2b1c73d2f7dc")

$ErrorActionPreference = "Stop"
$Browser = "C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"
$Evidence = Join-Path (Split-Path $PSScriptRoot -Parent) "evidence\collector"
$Expression = 'JSON.stringify({url:location.href,title:document.title,active_tabs:[...document.querySelectorAll(".contactus-hire-tab-item")].map(x=>({text:x.innerText.trim(),active:x.classList.contains("is-active")})),summary:document.body.innerText.slice(document.body.innerText.indexOf("校园招聘"),document.body.innerText.indexOf("苏州总部")),city_filters:[...document.querySelectorAll("input[type=checkbox]")].slice(0,5).map(i=>({value:i.value,checked:i.checked,label:i.parentElement?.parentElement?.innerText.trim()})),job_type_filters:[...document.querySelectorAll("input[type=checkbox]")].slice(5,14).map(i=>({value:i.value,checked:i.checked,label:i.parentElement?.parentElement?.innerText.trim()})),rows:[...document.querySelectorAll("tr")].map(r=>r.innerText.trim()),anchors:[...document.querySelectorAll("a")].map(a=>({text:a.innerText.trim(),href:a.href})).filter(x=>x.text||x.href)})'

$output = & $Browser action eval --session-id $SessionId --expression $Expression
if ($LASTEXITCODE -ne 0) { throw "browser-cli capture failed: $($output -join "`n")" }
$data = (($output -join "`n") | ConvertFrom-Json).data | ConvertFrom-Json
$data | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $Evidence "aispeech_internship_capture.json") -Encoding utf8
Write-Host ("Captured {0} result rows from active tab {1}" -f ($data.rows.Count - 1), (($data.active_tabs | Where-Object active).text))
