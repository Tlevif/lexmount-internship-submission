"""Capture a verified Moka list page and write a reviewable evidence batch."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from collector import core
from app.core import classify, classify_business_role


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session-id", required=True, help="Existing Cloud Browser session on the Moka list page")
    parser.add_argument("--target-id", required=True, help="Page target from `browser-cli session targets`")
    parser.add_argument("--career-url", required=True)
    parser.add_argument("--company", required=True)
    parser.add_argument("--website", required=True)
    parser.add_argument("--output", default="evidence/collector/galbot_moka_batch.json")
    parser.add_argument("--raw-output", default="evidence/collector/galbot_moka_raw_page.json")
    parser.add_argument("--run-output", default="evidence/collector/galbot_moka_run.json")
    args = parser.parse_args()

    config = {
        "company_name": args.company,
        "company_website": args.website,
        "career_url": args.career_url,
        "adapter": "mokahr_campus",
        "verified_for_collection": True,
        "browser_session_id": args.session_id,
    }
    raw_path, output_path, run_path = Path(args.raw_output), Path(args.output), Path(args.run_output)
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    try:
        raw_page = core._browser_eval(args.session_id, args.target_id, core.MOKAHR_CARDS_JS)
        raw_path.write_text(json.dumps(raw_page, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        target_city_jobs = core.collect_company(config)
        jobs = []
        scope_exclusions = []
        for job in target_city_jobs:
            category, evidence = classify(job)
            if category != "待审核" and classify_business_role(job) is None:
                job["raw_payload"]["technical_scope_category"] = category
                job["raw_payload"]["technical_scope_evidence"] = evidence
                jobs.append(job)
            else:
                scope_exclusions.append({
                    "source_job_id": job["source_job_id"],
                    "title": job["title"],
                    "category": category,
                    "evidence": evidence,
                    "reason": "不属于已确认的技术岗位范围",
                })
        excluded = []
        for card in raw_page.get("cards", []):
            parsed = core._mokahr_card_job(config, card, raw_page["url"], raw_page["total"], args.session_id)
            if not parsed["cities"]:
                excluded.append({
                    "source_job_id": parsed["source_job_id"],
                    "title": parsed["title"],
                    "reported_location_text": re.sub(r"\s+", " ", parsed["raw_payload"]["site_meta"]).strip(),
                    "reason": "目标城市未出现在卡片岗位地点元信息中",
                })
        metadata = {
            "company": args.company,
            "company_website": args.website,
            "career_url": args.career_url,
            "list_page_url": raw_page.get("url"),
            "page_title": raw_page.get("title"),
            "browser": "Lexmount Cloud Browser",
            "adapter": "mokahr_campus",
            "browser_session_id": args.session_id,
            "page_target_id": args.target_id,
            "captured_at_utc": datetime.now(timezone.utc).isoformat(),
            "reported_total": raw_page.get("total"),
            "raw_card_count": len(raw_page.get("cards", [])),
            "target_city_internship_cards": len(target_city_jobs),
            "collected_technical_job_count": len(jobs),
            "excluded_count": len(excluded) + len(scope_exclusions),
            "excluded_cards": excluded,
            "technical_scope_exclusions": scope_exclusions,
            "raw_page_evidence": str(raw_path).replace("\\", "/"),
            "job_detail_urls": [job["detail_url"] for job in jobs],
            "pages_read": 1,
            "page_counts": [len(raw_page.get("cards", []))],
        }
        batch = {
            "company": args.company,
            "source_url": args.career_url,
            "collection": metadata,
            "jobs": jobs,
            "review_candidates": [],
        }
        output_path.write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    finally:
        core._close_browser_session(args.session_id)
    state = core._run(core.BROWSER, "session", "get", "--session-id", args.session_id, retries=0)
    closed = state.get("data", {}).get("status") == "closed"
    metadata["browser_session_status"] = "closed" if closed else state.get("data", {}).get("status", "unknown")
    metadata["browser_session_closed_at_verification_utc"] = datetime.now(timezone.utc).isoformat()
    output_path.write_text(json.dumps({
        "company": args.company,
        "source_url": args.career_url,
        "collection": metadata,
        "jobs": jobs,
        "review_candidates": [],
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    run_path.parent.mkdir(parents=True, exist_ok=True)
    run_path.write_text(json.dumps({"ok": closed, "started_at_utc": started, "finished_at_utc": datetime.now(timezone.utc).isoformat(), "metadata": metadata}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if not closed:
        raise RuntimeError(f"Cloud Browser session did not close: {args.session_id}")
    print(json.dumps({"ok": True, "metadata": metadata}, ensure_ascii=False))


if __name__ == "__main__":
    main()
