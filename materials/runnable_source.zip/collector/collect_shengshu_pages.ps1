$ErrorActionPreference = 'Stop'
$browser = 'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$session = 'session_a0ff1b27-5869-4562-8d17-5993e3ea8f4c'
$outDir = 'evidence/collector'
$expr = 'JSON.stringify({url:location.href,text:document.body.innerText,title:document.title,cards:[...document.querySelectorAll("a[href*=detail]")].map(a=>({id:a.href.split("/").slice(-2,-1)[0],title:a.innerText.split("\n")[0],text:a.innerText,url:a.href})),activePage:document.querySelector(".atsx-pagination-item-active")?.innerText,pages:[...document.querySelectorAll(".atsx-pagination-item")].map(e=>e.innerText)})'
for ($page = 1; $page -le 10; $page++) {
  if ($page -gt 1) {
    $click = & $browser action click --session-id $session --selector ".atsx-pagination-item-$page" | ConvertFrom-Json
    if (-not $click.ok) { throw "Could not click page $page" }
    Start-Sleep -Milliseconds 800
  }
  $raw = & $browser action eval --session-id $session --expression $expr | ConvertFrom-Json
  if (-not $raw.ok) { throw "Could not read page $page" }
  $data = $raw.data | ConvertFrom-Json
  if ([int]$data.activePage -ne $page) { throw "Expected page $page, got $($data.activePage)" }
  if ($data.cards.Count -ne 10) { throw "Expected 10 cards on page $page, got $($data.cards.Count)" }
  $data | ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 "$outDir/shengshu_social_page_$('{0:d2}' -f $page).json"
  Write-Output "page=$page cards=$($data.cards.Count)"
}
