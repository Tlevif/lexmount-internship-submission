param(
    [string]$SessionId = "session_4f0c77ea-6627-4d12-a454-d9dd21840896"
)

$ErrorActionPreference = "Stop"
$Browser = "C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"
$Evidence = Join-Path (Split-Path $PSScriptRoot -Parent) "evidence\collector"
$Expression = 'JSON.stringify({url:location.href,count:(document.body.innerText.match(/\d+ 结果/)||[])[0]||null,cards:[...document.querySelectorAll("a[href*=\"#/job/\"]")].filter(a=>a.parentElement?.className.includes("list-")).map(a=>({detail_url:new URL(a.getAttribute("href"),location.href).href,title:a.innerText.trim().split("\n").filter(Boolean)[0],city:(a.innerText.match(/上海市|苏州市|北京市|杭州市|广州市|深圳市/)||[])[0]||null,card_text:a.innerText.trim()})),pagination:[...document.querySelectorAll("button")].filter(b=>/^\d+$/.test(b.innerText.trim())).map(b=>b.innerText.trim())})'

function Invoke-Browser([string[]]$Arguments) {
    $output = & $Browser @Arguments
    if ($LASTEXITCODE -ne 0) { throw "browser-cli failed: $($output -join "`n")" }
    return (($output -join "`n") | ConvertFrom-Json)
}

function Save-ListingPage([string]$ListName, [int]$PageNumber) {
    $result = Invoke-Browser @("action", "eval", "--session-id", $SessionId, "--expression", $Expression)
    $data = $result.data | ConvertFrom-Json
    if (-not $data.cards) { throw "No cards captured for $ListName page $PageNumber" }
    $data | Add-Member -NotePropertyName list_name -NotePropertyValue $ListName
    $data | Add-Member -NotePropertyName page -NotePropertyValue $PageNumber
    $path = Join-Path $Evidence ("hypergryph_" + $ListName + "_page_" + $PageNumber + ".json")
    $data | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $path -Encoding utf8
    Write-Output ("Saved {0} page {1}: {2} cards" -f $ListName, $PageNumber, $data.cards.Count)
}

Invoke-Browser @("action", "open-url", "--session-id", $SessionId, "--url", "https://app.mokahr.com/su/nTLy8") | Out-Null
Save-ListingPage "campus_intern" 1
Invoke-Browser @("action", "click", "--session-id", $SessionId, "--selector", 'button.sd-Pagination-item-4J_pS[data-page="2"]') | Out-Null
Save-ListingPage "campus_intern" 2

Invoke-Browser @("action", "open-url", "--session-id", $SessionId, "--url", "https://app.mokahr.com/su/b8lZs") | Out-Null
Save-ListingPage "daily_intern" 1
