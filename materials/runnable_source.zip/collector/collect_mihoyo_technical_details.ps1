param(
 [string]$SessionId='session_6637b6c4-b0d6-4f0c-9868-1226290b4091',
 [string]$ListTarget='50D9174A3CC1A8A89263FBA6A1EDE37D',
 [string]$OutputFile='evidence/collector/mihoyo_technical_details_raw.json',
 [int]$PageCount=6
)
$ErrorActionPreference='Stop'
$cli='C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$records=[System.Collections.Generic.List[object]]::new()
if(Test-Path $OutputFile){ $old=Get-Content $OutputFile -Raw | ConvertFrom-Json; foreach($x in $old){$records.Add($x)} }
for($page=1;$page -le $PageCount;$page++){
 $read=& $cli action eval --session-id $SessionId --target-id $ListTarget --expression 'JSON.stringify({page:Number(document.querySelector(".ant-pagination-item-active").title),cards:[...document.querySelectorAll(".jobItem___B0Ggv")].map(e=>({title:e.querySelector(".jobName___fD59h")?.innerText.trim()||"",meta:[...e.querySelectorAll(".subTitle___w1te5 .contentText___NpIRf")].map(x=>x.innerText.trim())}))})' | ConvertFrom-Json
 if(-not $read.ok){throw "Failed list eval on $page"}
 $pg=$read.data | ConvertFrom-Json
 if($pg.page -ne $page){throw "Page mismatch $page vs $($pg.page)"}
 for($i=0;$i -lt $pg.cards.Count;$i++){
  $card=$pg.cards[$i]
  $sel=".jobItem___B0Ggv:nth-child($($i+1))"
  $before=& $cli session targets --session-id $SessionId | ConvertFrom-Json
  $beforeIds=@($before.data | ForEach-Object {$_.id})
  $click=& $cli action click --session-id $SessionId --target-id $ListTarget --selector $sel | ConvertFrom-Json
  if(-not $click.ok){throw "Click failed p$page item $($i+1) $($card.title)"}
  $detail=$null
  for($attempt=0;$attempt -lt 12 -and -not $detail;$attempt++){
   Start-Sleep -Milliseconds 800
   $targets=& $cli session targets --session-id $SessionId | ConvertFrom-Json
   $detail=$targets.data | Where-Object { $_.url -match '/campus/position/\d+$' -and $_.title -eq $card.title -and $_.id -notin $beforeIds } | Select-Object -First 1
  }
  if(-not $detail){throw "Could not find opened detail p$page item $($i+1) $($card.title)"}
  $readDetail=& $cli action eval --session-id $SessionId --target-id $detail.id --expression 'JSON.stringify({url:location.href,title:document.title,text:document.body.innerText})' | ConvertFrom-Json
  if(-not $readDetail.ok){throw "Detail eval failed: $($card.title)"}
  $body=$readDetail.data | ConvertFrom-Json
  if($body.title -ne $card.title){throw "Detail title mismatch: $($card.title) vs $($body.title)"}
  $id=([regex]::Match($body.url,'/position/(\d+)$')).Groups[1].Value
  $rec=[pscustomobject]@{listing_page=$page;listing_position=($i+1);title=$card.title;listing_meta=$card.meta;source_job_id=$id;detail_url=$body.url;detail_text=$body.text}
  $records.Add($rec)
  $records | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $OutputFile -Encoding utf8
  Write-Output ("Captured {0}/{1}: {2} [{3}]" -f $records.Count,52,$card.title,$id)
 }
 if($page -lt $PageCount){
  $next=& $cli action click --session-id $SessionId --target-id $ListTarget --selector '.ant-pagination-next button' | ConvertFrom-Json
  if(-not $next.ok){throw "Failed pagination from $page"}
  Start-Sleep -Milliseconds 600
 }
}
Write-Output ("Done: {0} details in {1}" -f $records.Count,$OutputFile)

