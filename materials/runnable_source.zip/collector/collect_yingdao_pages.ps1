param([string]$SessionId = "session_fcba870f-3fb3-4e29-89f1-e7dba2cb2105")

$ErrorActionPreference = "Stop"
$Browser = "C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"
$Evidence = Join-Path (Split-Path $PSScriptRoot -Parent) "evidence\collector"
$Expression = 'JSON.stringify({url:location.href,count:(document.body.innerText.match(/开启新的工作（(\d+)）/)||[])[1]||null,cards:[...document.querySelectorAll("a[href*=\"/detail\"]")].map(a=>({detail_url:a.href,title:a.innerText.trim().split("\n")[0],card_text:a.innerText.trim()})),pagination:[...document.querySelectorAll("li.atsx-pagination-item")].map(li=>({page:li.title,active:li.className.includes("active")}))})'

function Invoke-Browser([string[]]$Arguments) {
    $output = & $Browser @Arguments
    if ($LASTEXITCODE -ne 0) { throw "browser-cli failed: $($output -join "`n")" }
    return (($output -join "`n") | ConvertFrom-Json)
}

Invoke-Browser @("action", "open-url", "--session-id", $SessionId, "--url", "https://join.yingdao.com/index/position/list") | Out-Null
for ($pageNumber = 1; $pageNumber -le 6; $pageNumber++) {
    if ($pageNumber -gt 1) {
        Invoke-Browser @("action", "click", "--session-id", $SessionId, "--selector", "li.atsx-pagination-item[title=`"$pageNumber`"]") | Out-Null
        Start-Sleep -Seconds 2
    }
    $result = Invoke-Browser @("action", "eval", "--session-id", $SessionId, "--expression", $Expression)
    $data = $result.data | ConvertFrom-Json
    if ($data.cards.Count -eq 0) { throw "No cards captured on page $pageNumber" }
    $data | Add-Member -NotePropertyName page -NotePropertyValue $pageNumber
    $path = Join-Path $Evidence ("yingdao_page_" + $pageNumber + ".json")
    $data | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $path -Encoding utf8
    Write-Host ("Saved page {0}: {1} cards, visible total {2}" -f $pageNumber, $data.cards.Count, $data.count)
}
