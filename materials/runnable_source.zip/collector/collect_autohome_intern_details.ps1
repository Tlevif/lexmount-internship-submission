param(
    [Parameter(Mandatory = $true)][string]$SessionId,
    [Parameter(Mandatory = $true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
$cli = 'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$rows = [System.Collections.Generic.List[object]]::new()
$countResult = & $cli action eval --session-id $SessionId --expression 'String(document.querySelectorAll(".position_card_li").length)' | ConvertFrom-Json
$count = [int]$countResult.data

for ($i = 1; $i -le $count; $i++) {
    $check = & $cli action eval --session-id $SessionId --expression "JSON.stringify({text:document.querySelector('.position_card_li:nth-child($i) .detail').innerText, visible:getComputedStyle(document.querySelector('.position_card_li:nth-child($i) .detail')).display})" | ConvertFrom-Json
    $state = $check.data | ConvertFrom-Json
    if ([string]::IsNullOrWhiteSpace($state.text)) {
        $selector = ".position_card_li:nth-child($i) .openbtn"
        $click = & $cli action click --session-id $SessionId --selector $selector | ConvertFrom-Json
        if (-not $click.ok) { throw "Could not expand card $i" }
        Start-Sleep -Milliseconds 900
    }
    $read = & $cli action eval --session-id $SessionId --expression "JSON.stringify((()=>{let c=document.querySelector('.position_card_li:nth-child($i)');return {pid:c.getAttribute('pid'),title:c.querySelector('.pname').innerText.trim(),city:c.querySelector('.pother').innerText.trim(),detail:c.querySelector('.detail').innerText.trim(),html:c.querySelector('.detail').innerHTML}})())" | ConvertFrom-Json
    if (-not $read.ok) { throw "Could not read card $i" }
    $row = $read.data | ConvertFrom-Json
    if ([string]::IsNullOrWhiteSpace($row.detail)) { throw "Card $i detail did not load" }
    $rows.Add($row)
}

$rows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputFile -Encoding utf8
Write-Output ("Captured {0} internship details to {1}" -f $rows.Count, $OutputFile)
