"""Recover saved official text, then fill missing fields from official details."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from urllib.parse import urlsplit, urlencode
from urllib.request import Request, urlopen
import hashlib, json, subprocess, re
from collector.detail_sections import extract_sections

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/rebuild20261027'
WEB=Path(r'C:\Users\Lenovo\.agents\skills\lexmount-webfetch\bin\webfetch-cli.exe')
def stamp():return datetime.now(timezone.utc).isoformat()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def missing(v):return not v or len(v.strip())<2 or '请您详见岗位意向' in v
def rows():return [json.loads(s) for s in (ROOT/'data/archive/20261027-before-rebuild/jobs.jsonl').read_text('utf-8').split('\n') if s.strip()]
def capture(j,kind):
    identity=f"{j['company_name']}|{j['source_job_id']}"
    p=OUT/kind/(hashlib.sha256(identity.encode()).hexdigest()[:24]+'.json')
    if p.exists():return json.loads(p.read_text('utf-8')),p
    u=j['detail_url'];r={'company_name':j['company_name'],'source_job_id':str(j['source_job_id']),'detail_url':u,'checked_at_utc':stamp(),'method':kind}
    try:
        if kind=='official_api':
            api='https://'+urlsplit(u).netloc+'/api/v1/job/posts/'+str(j['source_job_id'])
            d=json.load(urlopen(Request(api,headers={'User-Agent':'Mozilla/5.0','Referer':u}),timeout=25));v=d.get('data',{}).get('job_post_detail') or {}
            r.update(api_url=api,code=d.get('code'),title=v.get('title'),responsibilities=v.get('description'),requirements=v.get('requirement'))
        else:
            pr=subprocess.run([str(WEB),'extract','--url',u,'--format','json','--timeout-ms','30000'],capture_output=True,text=True,encoding='utf-8',timeout=45)
            d=json.loads(pr.stdout or pr.stderr);r['response']=d;r.update(extract_sections(d.get('main_text','')))
    except Exception as e:r['error']=str(e)
    dump(p,r);return r,p

def apply(j,values,path,when,method):
    fields=[]
    for k in ['responsibilities','requirements']:
        v=values.get(k)
        if missing(j.get(k)) and v and not missing(v):j[k]=v.strip();fields.append(k)
    if fields:
        history=j.setdefault('raw_payload',{}).setdefault('detail_sources',[])
        history.append({'fields':fields,'evidence_file':path,'checked_at_utc':when,'method':method,'source_url':j['detail_url']})
    return fields

def local_recovery(js):
    changed=0
    for j in js:
        raw=j.get('raw_payload') or {}; texts=[]
        for k in ['detail_page_text','official_detail_text','description','detail_text']:
            if isinstance(raw.get(k),str) and len(raw[k])>30:texts.append(raw[k])
        texts.append(j.get('responsibilities') or '')
        for t in texts:
            changed+=bool(apply(j,extract_sections(t),'data/archive/20261027-before-rebuild/jobs.jsonl',None,'saved_official_text'))
        if j['company_name']=='蚂蚁集团':
            p=ROOT/'evidence/collector'/f"antgroup_detail_{j['source_job_id']}.json"
            if p.exists():
                d=json.loads(p.read_text('utf-8-sig'));t=d.get('text') or d.get('page_text') or ''
                if t:changed+=bool(apply(j,extract_sections(t),p.relative_to(ROOT).as_posix(),d.get('captured_at_local'),'saved_Lexmount_Cloud_Browser'))
    return changed

def baidu(js):
    p=OUT/'baidu_list.json'
    if p.exists():d=json.loads(p.read_text('utf-8'))
    else:
        u='https://talent.baidu.com/httservice/getPostListNew';body=urlencode({'recruitType':'INTERN','curPage':1,'pageSize':1000}).encode()
        d={'source_url':u,'checked_at_utc':stamp(),'response':json.load(urlopen(Request(u,data=body,headers={'Content-Type':'application/x-www-form-urlencoded;charset=utf-8'}),timeout=30))};dump(p,d)
    matched=0
    items=d['response'].get('data',{}).get('list',[])
    for j in js:
        if j['company_name']!='百度':continue
        matches=[x for x in items if str(j['source_job_id']) in x['name']]
        if len(matches)==1:
            x=matches[0];apply(j,{'responsibilities':x.get('workContent'),'requirements':x.get('serviceCondition')},p.relative_to(ROOT).as_posix(),d['checked_at_utc'],'official_public_API')
            j['detail_url']='https://talent.baidu.com/jobs/detail/INTERN/'+x['postId'];matched+=1
    print('Baidu items/matched',len(items),matched,flush=True)

def run_group(jobs,kind,workers):
    result=[]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(capture,j,kind):j for j in jobs}
        for i,f in enumerate(as_completed(futures),1):
            r,p=f.result();result.append((futures[f],r,p))
            if i%50==0 or i==len(jobs):
                dump(OUT/(kind+'_progress.json'),{'done':i,'total':len(jobs),'updated_at_utc':stamp()});print(kind,i,'/',len(jobs),flush=True)
    return result

def main():
    js=rows();OUT.mkdir(parents=True,exist_ok=True)
    print('Local recovered',local_recovery(js),flush=True);baidu(js)
    api=[];web=[]
    for j in js:
        if not any(missing(j.get(k)) for k in ['responsibilities','requirements']):continue
        host=urlsplit(j['detail_url']).netloc
        if host=='jobs.bytedance.com' or host.endswith('.jobs.feishu.cn'):api.append(j)
        elif j['company_name'] in {'腾讯','阿里巴巴','小红书'}:web.append(j)
    print('Tasks',len(api),'API',len(web),'WebFetch',flush=True)
    with ThreadPoolExecutor(max_workers=2) as pool:
        a=pool.submit(run_group,api,'official_api',8);b=pool.submit(run_group,web,'Lexmount_WebFetch',5)
        for records in [a.result(),b.result()]:
            for j,r,p in records:
                # Stable job IDs and official detail URLs identify each capture.
                apply(j,r,p.relative_to(ROOT).as_posix(),r['checked_at_utc'],r['method'])
    (OUT/'working_jobs.jsonl').write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in js),encoding='utf-8')
    todo=[{'company_name':j['company_name'],'source_job_id':j['source_job_id'],'title':j['title'],'detail_url':j['detail_url'],'missing':[k for k in ['responsibilities','requirements'] if missing(j.get(k))]} for j in js if any(missing(j.get(k)) for k in ['responsibilities','requirements'])]
    dump(OUT/'remaining_missing.json',todo);print('Remaining',len(todo),flush=True)
if __name__=='__main__':main()
