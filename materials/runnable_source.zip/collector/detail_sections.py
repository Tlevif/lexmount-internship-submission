"""Extract explicitly labelled job sections without borrowing neighbouring jobs."""
import re

DUTIES={'岗位描述','工作职责','职位描述','岗位职责','职位职责','工作内容','About the Job','Job Description','职责描述','岗位内容','课题描述','主要职责','工作描述','岗位工作内容'}
REQUIREMENTS={'岗位要求','岗位需求','任职要求','任职资格','职位要求','职位资格','Qualifications','Job Requirements','Requirements','任职条件','课题要求','工作要求','招聘要求'}
DUTIES.update({'职责','你会参与的工作','你将亲手打造','你将参与的工作包括','实习期间可以参与以下内容','你将负责以下一个或多个方向的工作','你会参与','工作范围','做什么（说点实际的！）'})
REQUIREMENTS.update({'要求','我们希望你具备','我们希望你','你需要具备的能力','能力要求','核心能力要求','必须要会的是','希望你','基本要求','我们看重的能力','岗位通用要求','岗位细分要求'})
END={'参加面试的城市','招聘部门和工作地','课题部门和工作地','Hiring Business','相关职位','推荐职位','投递','申请职位','立即投递','职位信息','工作地点','Follow us','联系我们','联系我们​','相似职位','猜你喜欢','招聘流程','职位申请','更多职位','意向单','社区精选','你将获得'}

def clean_heading(line):
    line=re.sub(r'^[#*【\[\s]+|[:：*】\]\s]+$','',line)
    return re.sub(r'^[一二三四五六七八九十]+[、.．]\s*','',line)

def extract_sections(text):
    text=re.sub(r'【('+ '|'.join(re.escape(x) for x in DUTIES|REQUIREMENTS|END) +r')】', r'\n\1\n',text)
    result={};active=None;parts=[]
    def flush():
        nonlocal active,parts
        value='\n'.join(parts).strip()
        if active and len(value)>=8 and active not in result:result[active]=value
        active=None;parts=[]
    for line in text.split('\n'):
        key=clean_heading(line)
        if active=='requirements' and key in DUTIES:
            # Some official Tencent pages put “岗位职责” inside 课题要求.
            parts.append(line.rstrip())
        elif key in DUTIES|REQUIREMENTS:
            if (active=='responsibilities' and key in DUTIES) or (active=='requirements' and key in REQUIREMENTS):
                parts.append(line.rstrip())
                continue
            flush();active='responsibilities' if key in DUTIES else 'requirements'
        elif key in END or key.startswith(('允许3个月内','Copyright','© ')):
            had_section=active is not None or bool(result)
            flush()
            if had_section:break
        elif active:parts.append(line.rstrip())
    flush()
    return result
