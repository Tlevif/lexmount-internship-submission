param(
    [Parameter(Mandatory = $true)][string]$SessionId,
    [Parameter(Mandatory = $true)][int]$PageCount,
    [Parameter(Mandatory = $true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
$cli = 'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$pages = [System.Collections.Generic.List[object]]::new()

for ($expectedPage = 1; $expectedPage -le $PageCount; $expectedPage++) {
    $eval = & $cli action eval --session-id $SessionId --expression 'JSON.stringify({page:Number(document.querySelector(".ant-pagination-item-active").title),totalText:document.body.innerText.match(/职位列表\(\d+\)/)?.[0]||"",cards:[...document.querySelectorAll(".jobItem___B0Ggv")].map(e=>({title:e.querySelector(".jobName___fD59h")?.innerText.trim()||"",tags:[...e.querySelectorAll(".ant-tag")].map(x=>x.innerText.trim()),meta:[...e.querySelectorAll(".subTitle___w1te5 .contentText___NpIRf")].map(x=>x.innerText.trim()),text:e.innerText.trim()}))})' | ConvertFrom-Json
    if (-not $eval.ok) { throw "Could not read page $expectedPage" }
    $data = $eval.data | ConvertFrom-Json
    if ($data.page -ne $expectedPage) { throw "Expected page $expectedPage, got $($data.page)" }
    $pages.Add($data)
    if ($expectedPage -lt $PageCount) {
        $next = & $cli action click --session-id $SessionId --selector '.ant-pagination-next button' | ConvertFrom-Json
        if (-not $next.ok) { throw "Could not advance from page $expectedPage" }
        Start-Sleep -Milliseconds 500
    }
}

$pages | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $OutputFile -Encoding utf8
$total = ($pages | ForEach-Object { $_.cards.Count } | Measure-Object -Sum).Sum
Write-Output ("Captured {0} pages and {1} cards to {2}" -f $pages.Count, $total, $OutputFile)
