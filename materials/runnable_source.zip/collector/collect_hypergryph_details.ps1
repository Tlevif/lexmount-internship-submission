param(
    [string]$SessionId = "session_4f0c77ea-6627-4d12-a454-d9dd21840896"
)

$ErrorActionPreference = "Stop"
$Browser = "C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe"
$Root = Split-Path $PSScriptRoot -Parent
$Evidence = Join-Path $Root "evidence\collector"
$CandidatePattern = '游戏客户端（实习）|游戏测试开发（实习）|游戏服务端（实习）|技术策划（实习）|游戏测试（实习）|UE客户端实习生|游戏测试实习生|数据产品实习生（森空岛）|产品实习生（社媒工具方向）'

function Invoke-Browser([string[]]$Arguments) {
    $output = & $Browser @Arguments
    if ($LASTEXITCODE -ne 0) { throw "browser-cli failed: $($output -join "`n")" }
    return (($output -join "`n") | ConvertFrom-Json)
}

$cards = foreach ($path in Get-ChildItem (Join-Path $Evidence "hypergryph_*_page_*.json")) {
    $page = Get-Content -LiteralPath $path.FullName -Raw | ConvertFrom-Json
    foreach ($card in $page.cards) {
        $card | Add-Member -NotePropertyName page -NotePropertyValue $page.page -Force
        $card | Add-Member -NotePropertyName list_name -NotePropertyValue $page.list_name -Force
        $card
    }
}
$candidates = foreach ($card in $cards) {
    $lines = @($card.card_text -split "`n" | Where-Object { $_.Trim() })
    $title = if ($lines[0] -eq "急") { $lines[1] } else { $lines[0] }
    if ($title -match $CandidatePattern) {
        [pscustomobject]@{ title = $title; detail_url = $card.detail_url; city = $card.city; listing_page = $card.page; list_name = $card.list_name }
    }
}

$details = foreach ($candidate in $candidates) {
    Invoke-Browser @("action", "open-url", "--session-id", $SessionId, "--url", $candidate.detail_url) | Out-Null
    $result = Invoke-Browser @("action", "eval", "--session-id", $SessionId, "--expression", 'JSON.stringify({url:location.href,title:document.title,text:document.body.innerText})')
    $data = $result.data | ConvertFrom-Json
    [pscustomobject]@{ title = $candidate.title; city = $candidate.city; list_name = $candidate.list_name; listing_page = $candidate.listing_page; detail_url = $candidate.detail_url; detail_text = $data.text; detail_page_title = $data.title; captured_url = $data.url }
    Write-Host ("Read detail: {0}" -f $candidate.title)
}

$details | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $Evidence "hypergryph_candidate_details.json") -Encoding utf8
