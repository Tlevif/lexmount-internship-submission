"""Re-read official pages for the frozen review cohort with Lexmount."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib, json, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
TARGETS=ROOT/'tmp/enrichment/targets.json'
OUT=ROOT/'evidence/enrichment/20261027'
CLI=Path(r'C:\Users\Lenovo\.agents\skills\lexmount-webfetch\bin\webfetch-cli.exe')

def stamp():return datetime.now(timezone.utc).isoformat()
def filename(url):return hashlib.sha256(url.encode()).hexdigest()[:24]+'.json'
def read_targets():return json.loads(TARGETS.read_text('utf-8'))
def fetch(url):
    dest=OUT/'webfetch'/filename(url)
    if dest.exists():return json.loads(dest.read_text('utf-8'))
    try:
        proc=subprocess.run([str(CLI),'extract','--url',url,'--format','json','--timeout-ms','30000'],capture_output=True,text=True,encoding='utf-8',timeout=45)
        data=json.loads(proc.stdout)
        result={'requested_url':url,'checked_at_utc':stamp(),'tool':'Lexmount WebFetch','response':data,'exit_code':proc.returncode}
    except Exception as e:result={'requested_url':url,'checked_at_utc':stamp(),'error':str(e)}
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    return result

def main():
    targets=read_targets();urls=list(dict.fromkeys(j['detail_url'] for j in targets))
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'target_cohort.json').write_text(json.dumps([{k:j.get(k) for k in ['company_name','title','source_job_id','detail_url','responsibilities','requirements']} for j in targets],ensure_ascii=False,indent=2),encoding='utf-8')
    done=0;good=0
    with ThreadPoolExecutor(max_workers=5) as pool:
        fs={pool.submit(fetch,url):url for url in urls}
        for f in as_completed(fs):
            r=f.result();done+=1;good+=bool(r.get('response',{}).get('main_text'))
            if done%10==0 or done==len(urls):
                progress={'completed_urls':done,'total_urls':len(urls),'with_text':good,'updated_at_utc':stamp()}
                (OUT/'fetch_progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2),encoding='utf-8')
                print(json.dumps(progress,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
