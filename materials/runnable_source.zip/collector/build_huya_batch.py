from __future__ import annotations
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
pages = json.loads((EVID / "huya_mokahr_list_pages_raw.json").read_text(encoding="utf-8-sig"))
details = json.loads((EVID / "huya_relevant_details_raw.json").read_text(encoding="utf-8-sig"))
cards = [dict(card, listing_page=page["page"]) for page in pages for card in page["cards"]]
if len(pages) != 4 or [len(p["cards"]) for p in pages] != [15, 15, 15, 4]:
    raise ValueError("expected four complete Moka list pages with 15,15,15,4 cards")
if len(cards) != 49 or len({c["detail_url"] for c in cards}) != 49:
    raise ValueError("expected 49 unique Moka job cards")
if any("2027届校园招聘" not in card["labels"] for card in cards):
    raise ValueError("found a non-2027 campus entry")
if any("实习" in " ".join(card["labels"]) for card in cards):
    raise ValueError("internship label found; zero-result batch would be invalid")
if len(details) != 10 or any("2027届校园招聘" not in d["detail_text"] for d in details):
    raise ValueError("candidate detail check incomplete or contradicts campus-only classification")
SOURCE = "https://app.mokahr.com/campus_apply/huya/4112#/jobs?department=&zhineng=&page=1&_k=0qyx5o"
batch = {
  "company": "虎牙",
  "source_url": SOURCE,
  "collection": {
    "method": "依据虎牙官网校园招聘入口明确链接的 Moka 招聘系统，使用 Lexmount Cloud Browser 读取当前职位列表全部分页，并打开AI、算法、开发及深圳地点相关的候选职位详情核实招聘届别与地点。",
    "pages_read": 4,
    "reported_total": 49,
    "page_counts": [len(p["cards"]) for p in pages],
    "target_city_internship_cards": 0,
    "excluded_count": 49,
    "candidate_details_read": len(details),
    "session_closed": True,
    "issues": [
      "虎牙官方校园招聘页显示当前开放项目为2027届校园招聘，毕业时间为2026年9月至2027年8月；该页另有实习生招聘入口但文案为“敬请期待”。",
      "官网明确链接的 Moka 当前职位列表共4页，逐页读取分别为15、15、15、4条，共49条。列表未显示单独的实习筛选和结果总数；所有49条卡片均标注“2027届校园招聘”，未发现实习岗位。",
      "49条中27条为技术类；6条职位卡包含目标城市深圳，其中大模型算法、多模态视频生成等技术岗位详情均注明2027届校招对象，并非实习。",
      "抽查10条AI、算法、开发及目标城市相关详情，均标注面向2026年9月至2027年8月毕业生的2027届校招；没有岗位达到目标城市实习条件。",
      "列表地点为佛山市42条、含深圳市6条、武汉市与佛山市1条；深圳以外地点不在目标城市范围。"
    ]
  },
  "jobs": [],
  "review_candidates": []
}
(EVID / "huya_batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
category_counts = Counter(label for card in cards for label in card["labels"][1:])
city_counts = Counter(city.strip() for card in cards for city in card["city"].split())
summary = {
  "official_site": "https://hr.huya.com/",
  "official_campus_page": "https://hr.huya.com/campusRecruit/index?showMark=true",
  "official_ats_url": SOURCE,
  "internship_notice": "实习生招聘：敬请期待",
  "pages_read": len(pages),
  "page_counts": [len(p["cards"]) for p in pages],
  "computed_list_count": len(cards),
  "visible_total_count": None,
  "category_counts": dict(category_counts),
  "city_assignment_counts": dict(city_counts),
  "decisions": {"accepted": 0, "review": 0, "excluded_non_internship": len(cards)},
  "candidate_detail_count": len(details),
  "candidate_detail_titles": [d["title"] for d in details],
  "all_listings_2027_campus_only": True,
  "browser_session_closed": True,
  "listing_cards": [
    {**card, "decision": "excluded_non_internship", "reason": "官方列表标签为2027届校园招聘；不属于实习岗位。"}
    for card in cards
  ]
}
(EVID / "huya_classification_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Wrote zero-result batch: pages={len(pages)} positions={len(cards)} main=0 review=0; details checked={len(details)}")

