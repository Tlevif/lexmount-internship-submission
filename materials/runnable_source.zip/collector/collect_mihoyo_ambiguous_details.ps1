$ErrorActionPreference='Stop'
$SessionId='session_6637b6c4-b0d6-4f0c-9868-1226290b4091'; $ListTarget='50D9174A3CC1A8A89263FBA6A1EDE37D'; $OutputFile='evidence/collector/mihoyo_ambiguous_details_raw.json'; $cli='C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$wanted=@('AI 产品实习生（发行方向）','游戏测试工程师实习生','AI 创新产品实习生','技术美术实习生（多方向）','技术策划实习生','数据分析实习生 - 崩坏：星穹铁道+崩坏：因缘精灵（南大线下专场）','测试开发工程师实习生','数据产品经理实习生','投放数据分析实习生','游戏支付数据分析实习生','游戏增长策略分析实习生','增长洞察数据分析实习生','数据分析实习生 - 崩坏：星穹铁道+崩坏：因缘精灵','音频算法工程师实习生（生成向）','国际化发行数据分析实习生')
$records=[System.Collections.Generic.List[object]]::new()
for($page=1;$page -le 15;$page++){
 $rr=& $cli action eval --session-id $SessionId --target-id $ListTarget --expression 'JSON.stringify({page:Number(document.querySelector(".ant-pagination-item-active").title),cards:[...document.querySelectorAll(".jobItem___B0Ggv")].map(e=>({title:e.querySelector(".jobName___fD59h")?.innerText.trim()||"",meta:[...e.querySelectorAll(".subTitle___w1te5 .contentText___NpIRf")].map(x=>x.innerText.trim())}))})'|ConvertFrom-Json
 if(!$rr.ok){throw "List read failed $page"}; $pg=$rr.data|ConvertFrom-Json
 if($pg.page -ne $page){throw "Page mismatch $page/$($pg.page)"}
 for($i=0;$i -lt $pg.cards.Count;$i++){
  $card=$pg.cards[$i]; if($wanted -notcontains $card.title){continue}
  $already=$false; if(Test-Path $OutputFile){$exists=Get-Content $OutputFile -Raw|ConvertFrom-Json; $already=!!(@($exists|Where-Object title -eq $card.title).Count)}; if($already){continue}
  $before=& $cli session targets --session-id $SessionId|ConvertFrom-Json; $beforeIds=@($before.data|% id)
  $ck=& $cli action click --session-id $SessionId --target-id $ListTarget --selector ".jobItem___B0Ggv:nth-child($($i+1))"|ConvertFrom-Json; if(!$ck.ok){throw "Click failed $($card.title)"}
  $det=$null; for($a=0;$a -lt 12 -and !$det;$a++){Start-Sleep -Milliseconds 800; $ts=& $cli session targets --session-id $SessionId|ConvertFrom-Json; $det=$ts.data|?{$_.url -match '/campus/position/\d+$' -and $_.title -eq $card.title -and $_.id -notin $beforeIds}|select -First 1}
  if(!$det){throw "Detail target missing $($card.title)"}
  $dr=& $cli action eval --session-id $SessionId --target-id $det.id --expression 'JSON.stringify({url:location.href,title:document.title,text:document.body.innerText})'|ConvertFrom-Json; if(!$dr.ok){throw "Eval failed $($card.title)"}; $b=$dr.data|ConvertFrom-Json
  $id=([regex]::Match($b.url,'/position/(\d+)$')).Groups[1].Value
  $records.Add([pscustomobject]@{listing_page=$page;listing_position=$i+1;title=$card.title;listing_meta=$card.meta;source_job_id=$id;detail_url=$b.url;detail_text=$b.text})
  $all=@(); if(Test-Path $OutputFile){$all=@(Get-Content $OutputFile -Raw|ConvertFrom-Json)}; $all+=@($records[$records.Count-1]); $all|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $OutputFile -Encoding utf8
  Write-Output "Captured $($card.title)"
 }
 if($page -lt 15){$nx=& $cli action click --session-id $SessionId --target-id $ListTarget --selector '.ant-pagination-next button'|ConvertFrom-Json;if(!$nx.ok){throw "Next failed from page $page"};Start-Sleep -Milliseconds 600}
}
Write-Output 'Completed candidate detail review.'

