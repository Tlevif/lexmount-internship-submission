from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
LIST_FILES = [
    EVID / "hypergryph_campus_intern_page_1.json",
    EVID / "hypergryph_campus_intern_page_2.json",
    EVID / "hypergryph_daily_intern_page_1.json",
]
DETAILS_FILE = EVID / "hypergryph_candidate_details.json"
SOURCE_URLS = {
    "campus_intern": "https://app.mokahr.com/campus-recruitment/hypergryph/26326#/jobs?page=1&anchorName=jobsList&project%5B0%5D=100120340",
    "daily_intern": "https://app.mokahr.com/apply/hypergryph/26325/#/jobs?keyword=&page=1&anchorName=jobsList&commitment%5B0%5D=%E5%AE%9E%E4%B9%A0",
}
CAREER_URL = "https://career.hypergryph.com/"
METHOD = "依据鹰角官网校园招聘入口明确链接的 Moka 招聘系统，使用 Lexmount Cloud Browser 分别读取2028届校招实习与日常实习列表的全部分页，并打开技术相关及边界岗位详情核实城市、职责和要求。"
MAIN_TITLES = {
    "游戏客户端（实习）",
    "游戏测试开发（实习）",
    "游戏服务端（实习）",
    "游戏测试（实习）",
    "UE客户端实习生",
    "游戏测试实习生",
    "数据产品实习生（森空岛）",
    "技术策划（实习）",
}
REVIEW_TITLES = {"产品实习生（社媒工具方向）"}


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def title_from_card(card: dict) -> str:
    lines = [line.strip() for line in card["card_text"].splitlines() if line.strip()]
    return lines[1] if lines[0] == "急" else lines[0]


def section(text: str, start: str, ends: tuple[str, ...]) -> str | None:
    start_match = re.search(start, text)
    if not start_match:
        return None
    rest = text[start_match.end() :]
    end_positions = [m.start() for marker in ends if (m := re.search(marker, rest))]
    if end_positions:
        rest = rest[: min(end_positions)]
    value = "\n".join(line.strip() for line in rest.splitlines() if line.strip())
    return value or None


pages = [read_json(path) for path in LIST_FILES]
if [(p["list_name"], p["page"], len(p["cards"])) for p in pages] != [
    ("campus_intern", 1, 30),
    ("campus_intern", 2, 14),
    ("daily_intern", 1, 19),
]:
    raise ValueError("listing page capture counts do not match complete current lists")

cards: list[dict] = []
for page in pages:
    for card in page["cards"]:
        cards.append({**card, "listing_page": page["page"], "list_name": page["list_name"]})
if len(cards) != 63 or len({card["detail_url"] for card in cards}) != 63:
    raise ValueError("expected 63 unique internship cards across both official internship lists")

details = read_json(DETAILS_FILE)
detail_by_url = {d["detail_url"]: d for d in details}
if len(details) != 9 or len(detail_by_url) != 9:
    raise ValueError("expected nine unique candidate detail pages")

included: list[dict] = []
review: list[dict] = []
classified: list[dict] = []
for card in cards:
    title = title_from_card(card)
    if title in MAIN_TITLES:
        decision = "main"
        reason = "详情明确包含软件开发、测试开发、计算机测试、数据分析或技术策划职责和计算机技能要求。"
    elif title in REVIEW_TITLES:
        decision = "review"
        reason = "职位负责社媒工具产品方案并协同研发落地；详情将理工科和编码能力列为优先或加分项，主要职责仍是产品方案设计，需人工确认是否归入泛计算机岗位。"
    else:
        decision = "excluded"
        reason = "当前岗位为实习，但详情职责属于美术、音视频、发行运营、项目管理或游戏内容策划，未达到AI、计算机及泛计算机方向。"

    detail = detail_by_url.get(card["detail_url"])
    detail_text = detail["detail_text"] if detail else ""
    city = card.get("city")
    if city != "上海市":
        decision = "excluded"
        reason = f"职位地点为{city or '未标注城市'}，不在本次五城范围。"
    if decision in {"main", "review"} and not detail:
        raise ValueError(f"candidate detail was not captured: {title}")

    item = {
        "company_name": "鹰角网络",
        "company_website": CAREER_URL,
        "career_url": SOURCE_URLS[card["list_name"]],
        "title": title,
        "detail_url": card["detail_url"],
        "source_url": SOURCE_URLS[card["list_name"]],
        "source_job_id": card["detail_url"].rsplit("/", 1)[-1],
        "cities": ["上海"],
        "recruitment_type": "实习",
        "raw_category": (
            re.search(r"实习\s*[|｜]\s*上海市\s*[|｜]\s*([^\n]+)", detail_text).group(1).strip()
            if re.search(r"实习\s*[|｜]\s*上海市\s*[|｜]\s*([^\n]+)", detail_text)
            else None
        ),
        "responsibilities": section(detail_text, r"岗位职责\s*[:：]?", (r"任职要求", r"岗位要求", r"作品要求", r"投递要求", r"申请职位"))
        if detail_text
        else None,
        "requirements": section(detail_text, r"(?:任职要求|岗位要求)\s*[:：]?", (r"作品要求", r"投递要求", r"申请职位"))
        if detail_text
        else None,
        "published_at": re.search(r"发布于\s*(\d{4}-\d{2}-\d{2})", card["card_text"]).group(1)
        if re.search(r"发布于\s*(\d{4}-\d{2}-\d{2})", card["card_text"])
        else None,
        "collection_method": "browser",
        "raw_payload": {
            "list_name": card["list_name"],
            "list_page": card["listing_page"],
            "list_card": card["card_text"],
            "decision": decision,
            "decision_reason": reason,
            "detail_captured": bool(detail),
            "detail_text": detail_text or None,
        },
    }
    classified.append({"title": title, "detail_url": card["detail_url"], "city": city, "list_name": card["list_name"], "page": card["listing_page"], "decision": decision, "reason": reason})
    if decision == "main":
        included.append(item)
    elif decision == "review":
        review.append(item)

if {x["title"] for x in included} != MAIN_TITLES or {x["title"] for x in review} != REVIEW_TITLES:
    raise ValueError("final included/review title sets do not match the reviewed candidate set")

counts = {name: [len(p["cards"]) for p in pages if p["list_name"] == name] for name in SOURCE_URLS}
batch = {
    "company": "鹰角网络",
    "source_url": SOURCE_URLS["campus_intern"],
    "source_chain": [
        "https://career.hypergryph.com/",
        "https://app.mokahr.com/campus-recruitment/hypergryph/26326?locale=zh-CN#/jobs",
        SOURCE_URLS["campus_intern"],
        "https://app.mokahr.com/su/b8lZs",
        SOURCE_URLS["daily_intern"],
    ],
    "collection": {
        "method": METHOD,
        "pages_read": len(pages),
        "reported_total": len(cards),
        "page_counts": counts,
        "target_city_internship_cards": sum(1 for card in cards if card.get("city") == "上海市"),
        "candidate_details_read": len(details),
        "main_count": len(included),
        "review_count": len(review),
        "excluded_count": len(cards) - len(included) - len(review),
        "session_closed": True,
        "issues": [
            "鹰角官网校园招聘入口列出“2028届校招实习生投递”和“日常实习投递”两个独立 Moka 入口；本次分别读取了两个入口的全部实习列表。",
            "2028届校招实习列表44条，分页为30条、14条；日常实习列表19条、1页。两处列表共63条，地点均为上海市。",
            "从两张列表筛选8条技术方向岗位和1条边界产品岗位，逐条打开详情核实职责、要求与城市；社媒工具产品岗位保留待判断，其余非技术岗位排除。",
            "两处列表显示城市筛选均未包含目标五城以外岗位；清单中的职位详情城市为上海市。",
        ],
    },
    "jobs": included,
    "review_candidates": review,
}
(EVID / "hypergryph_batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

summary = {
    "official_site": CAREER_URL,
    "source_chain": batch["source_chain"],
    "entry_lists": {
        "campus_intern": {"url": SOURCE_URLS["campus_intern"], "pages_read": len(counts["campus_intern"]), "page_counts": counts["campus_intern"], "total": sum(counts["campus_intern"])},
        "daily_intern": {"url": SOURCE_URLS["daily_intern"], "pages_read": len(counts["daily_intern"]), "page_counts": counts["daily_intern"], "total": sum(counts["daily_intern"])},
    },
    "reported_total": len(cards),
    "candidate_details_read": len(details),
    "decisions": {"main": len(included), "review": len(review), "excluded": len(cards) - len(included) - len(review)},
    "city_counts": dict(Counter(card.get("city") or "未标注" for card in cards)),
    "browser_session_closed": True,
    "listing_cards": classified,
    "candidate_detail_titles": [d["title"] for d in details],
}
(EVID / "hypergryph_classification_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Wrote batch: pages={len(pages)} cards={len(cards)} main={len(included)} review={len(review)} excluded={len(cards)-len(included)-len(review)} details={len(details)}")
