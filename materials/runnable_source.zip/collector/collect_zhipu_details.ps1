param(
    [Parameter(Mandatory = $true)][string]$SessionId,
    [Parameter(Mandatory = $true)][string]$ListFile,
    [Parameter(Mandatory = $true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
$cli = 'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$outer = Get-Content -LiteralPath $ListFile -Raw -Encoding utf8 | ConvertFrom-Json
$cards = $outer.data | ConvertFrom-Json
$details = [System.Collections.Generic.List[object]]::new()

foreach ($card in $cards) {
    $nav = & $cli action open-url --session-id $SessionId --url $card.url | ConvertFrom-Json
    if (-not $nav.ok) { throw "Could not open $($card.url): $($nav | ConvertTo-Json -Compress)" }
    Start-Sleep -Milliseconds 900
    $eval = & $cli action eval --session-id $SessionId --expression 'JSON.stringify(document.body.innerText)' | ConvertFrom-Json
    if (-not $eval.ok) { throw "Could not read $($card.url): $($eval | ConvertTo-Json -Compress)" }
    $text = $eval.data | ConvertFrom-Json
    $details.Add([ordered]@{url = $card.url; text = $text})
}

$details | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputFile -Encoding utf8
Write-Output ("Captured {0} detail pages to {1}" -f $details.Count, $OutputFile)
