"""Apply source-backed detail captures to the frozen review cohort."""
from pathlib import Path
from datetime import datetime, timezone
import collections
import json
import shutil

from app.core import normalize_job
from collector.detail_sections import extract_sections
from collector.enrich_review_details import filename

ROOT = Path(__file__).resolve().parents[1]
EV = ROOT / 'evidence/enrichment/20261027'

def load(p):
    return json.loads(p.read_text('utf-8'))

def apply():
    targets = load(EV/'target_cohort.json')
    keys = {(j['company_name'], str(j['source_job_id'])) for j in targets}
    rows = [json.loads(s) for s in (ROOT/'data/jobs.jsonl').read_text('utf-8').split('\n') if s.strip()]
    before = {k: sum(not j.get(k) for j in rows if (j['company_name'],str(j.get('source_job_id'))) in keys) for k in ['responsibilities','requirements']}
    byte = load(EV/'byte_browser_details.json')
    byte_by = {str(x['id']):x for x in byte['records']}
    baidu = load(EV/'baidu_official_details.json')
    baidu_by = {str(x['source_job_id']):x for x in baidu['records']}
    other = load(EV/'remaining_browser_details.json')
    other_by = {(x['company_name'],str(x['source_job_id'])):x for x in other['records']}
    changed=[]; outcomes=[]
    for j in rows:
        key=(j['company_name'],str(j.get('source_job_id')))
        if key not in keys:
            continue
        new={}; evidence=None; stamp=None; note=None; status='retained_existing'
        co=key[0]; ident=key[1]; url=j['detail_url']
        if co in {'腾讯','阿里巴巴','小红书'}:
            evidence=EV/'webfetch'/filename(url); capture=load(evidence)
            new=extract_sections(capture['response']['main_text']);stamp=capture['checked_at_utc']
        elif co=='字节跳动':
            r=byte_by[ident]
            assert r.get('code')==0 and r['title']==j['title']
            new={'responsibilities':r['description'],'requirements':r['requirement']}
            evidence=EV/'byte_browser_details.json';stamp=byte['checked_at_utc']
        elif co=='百度':
            evidence=EV/'baidu_official_details.json';stamp=baidu['checked_at_utc']
            if ident in baidu_by:
                r=baidu_by[ident]; assert ident in r['job']['name']
                new={'responsibilities':r['job']['workContent'],'requirements':r['job']['serviceCondition']}
                j['detail_url']=r['detail_url']
            else:
                status='not_found';note='2026-10-27官网按原岗位编号未检索到该岗位；保留历史职责，任职要求尚未核验。'
        elif co=='蚂蚁集团':
            r=other_by[key];new=extract_sections(r['text']);evidence=EV/'remaining_browser_details.json';stamp=other['checked_at_utc']
            if ident=='260820011582505':
                # The official page reverses these two field labels. Keep that visible.
                new={'responsibilities':new['requirements'],'requirements':new['responsibilities']}
                note='官网“职位描述”写能力要求、“职位要求”写工作任务；本页按实际内容对调展示，原文保留于证据。'
        elif co=='面壁智能':
            assert '该职位已下线' in other_by[key]['text']
            evidence=EV/'remaining_browser_details.json';stamp=other['checked_at_utc'];status='offline'
            note='2026-10-27官网显示“该职位已下线”；保留历史职责，任职要求尚未核验。'
        elif co=='DeepSeek':
            r=load(EV/'deepseek_replacement.json')
            section=r['text'].split('深度学习研究员方向',1)[1].split('研发工程师方向',1)[0]
            duties,requirements=section.split('【主要职责】',1)[1].split('【任职要求】',1)
            new={'responsibilities':duties.strip(),'requirements':requirements.strip()}
            evidence=EV/'deepseek_replacement.json';stamp=r['checked_at_utc'];j['detail_url']=r['url']
            note='原岗位页指向新的“Agent Harness 团队”页面；本页摘录其中“深度学习研究员方向”，全职、实习均可。'
        fields=[];filled=[]
        for field,value in new.items():
            if value and len(value.strip())>=8:
                if not j.get(field):filled.append(field)
                j[field]=value.strip();fields.append(field)
        if fields:status='verified'
        if evidence:
            meta={'checked_at_utc':stamp,'status':status,'source_url':j['detail_url'],'evidence_file':evidence.relative_to(ROOT).as_posix(),'verified_fields':fields}
            if note:meta['note']=note
            j.setdefault('raw_payload',{})['detail_enrichment']=meta
        if filled:changed.append({'company_name':co,'source_job_id':ident,'filled_fields':filled})
        outcomes.append({'company_name':co,'source_job_id':ident,'status':status,'verified_fields':fields,'note':note})
    after={k:sum(not j.get(k) for j in rows if (j['company_name'],str(j.get('source_job_id'))) in keys) for k in before}
    backup=ROOT/'tmp/enrichment/jobs.before-details.jsonl'
    if not backup.exists():shutil.copy2(ROOT/'data/jobs.jsonl',backup)
    (ROOT/'data/jobs.jsonl').write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in rows),encoding='utf-8')
    categories=dict(collections.Counter(normalize_job(j)['category'] for j in rows))
    summary={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'target_cohort':len(keys),'before_missing':before,'after_missing':after,'jobs_filled':len(changed),'fields_filled':{k:before[k]-after[k] for k in before},'current_categories':categories,'changed':changed,'outcomes':outcomes}
    (EV/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['changed','outcomes']},ensure_ascii=False))

if __name__=='__main__':apply()
