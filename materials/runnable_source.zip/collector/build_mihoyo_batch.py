from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
LIST_FILE = EVID / "mihoyo_intern_list_pages_raw.json"
TECH_FILE = EVID / "mihoyo_technical_details_raw.json"
AMB_FILE = EVID / "mihoyo_ambiguous_details_raw.json"
OUT = EVID / "mihoyo_batch.json"
SUMMARY = EVID / "mihoyo_classification_summary.json"
COMPANY = "米哈游"
SOURCE = "https://jobs.mihoyo.com/#/campus/position?jobName=&projectIds%5B0%5D=4"
CAREER = "https://jobs.mihoyo.com/#/campus/position"

TECH_EXTRA = {
    "技术美术实习生（多方向）": "详情写明渲染、引擎工具、性能优化、PCG算法生成，并要求开发语言能力及开发工具经验。",
    "技术策划实习生": "详情职责包括编写可交互原型、开发策划工具/编辑器；要求 C#/C++/Python/Lua 编程与游戏引擎经验。",
    "游戏测试工程师实习生": "详情要求掌握至少一门编程语言、数据结构、算法、操作系统和网络，并承担接口、性能及自动化测试。",
    "测试开发工程师实习生": "岗位名称与官方质量管理分类显示测试开发；详情职责、工具和编程要求指向测试平台/自动化研发。",
    "音频算法工程师实习生（生成向）": "详情职责为音效生成、编辑、分离等 AI 算法；要求 Python、PyTorch/TensorFlow、音频信号处理和 Linux。",
}
REVIEW_REASONS = {
    "AI 产品实习生（发行方向）": "职责集中于AI发行产品需求、功能设计和效果迭代，理工科背景优先但岗位核心为产品工作；是否属于技术实习需人工判断。",
    "AI 创新产品实习生": "职责为探索AI应用场景并协作制定产品流程，要求有AI技术背景/作品；岗位核心偏产品应用，技术深度需人工判断。",
    "数据产品经理实习生": "官方归入产品策划类，岗位为数据产品经理；计算机/数据相关性可能来自产品协作，需结合具体技术工作判断。",
    "数据分析实习生 - 崩坏：星穹铁道+崩坏：因缘精灵（南大线下专场）": "运营类游戏数据分析岗位。详情涉及玩家与游戏数据分析；是否符合泛计算机技术实习范围需人工判断。",
    "数据分析实习生 - 崩坏：星穹铁道+崩坏：因缘精灵": "运营类游戏数据分析岗位。详情提及数据监控体系与SQL/Python作为加分能力，但主要职责为业务分析，需人工判断。",
    "投放数据分析实习生": "市场商务类业务分析岗位；详情涉及投放效果和数据分析。技术实现深度需人工判断。",
    "游戏支付数据分析实习生": "市场商务类业务分析岗位；详情涉及支付/经营分析。技术实现深度需人工判断。",
    "游戏增长策略分析实习生": "市场商务类增长分析岗位；详情涉及统计建模/数据分析工具。岗位更偏业务策略，技术方向相关性需人工判断。",
    "增长洞察数据分析实习生": "市场商务类增长数据分析岗位；详情要求SQL、Python及数据挖掘方法，但工作重点是业务洞察和增长策略，需人工判断。",
    "国际化发行数据分析实习生": "国际化类发行支持岗位；详情涉及SQL/Python、AI工具、数据流程，但职责同时包含业务信息整理和分析支持，需人工判断。",
}

def split_fields(text: str) -> tuple[str, str]:
    duties = next((x for x in ("工作职责", "岗位职责") if x in text), None)
    req = text.find("任职要求")
    if not duties or req < 0:
        raise ValueError("missing responsibility/requirement section")
    d0 = text.find(duties) + len(duties)
    responsibilities = text[d0:req].strip()
    r0 = req + len("任职要求")
    ends = [p for marker in ("加分项", "投递说明", "投递简历", "面向对象", "相关岗位") if (p := text.find(marker, r0)) >= 0]
    requirements = text[r0:min(ends) if ends else len(text)].strip()
    return responsibilities, requirements

pages = json.loads(LIST_FILE.read_text(encoding="utf-8-sig"))
tech = json.loads(TECH_FILE.read_text(encoding="utf-8-sig"))
amb = json.loads(AMB_FILE.read_text(encoding="utf-8-sig"))
all_cards = [dict(card, listing_page=p["page"], listing_position=i + 1) for p in pages for i, card in enumerate(p["cards"])]
by_title = {}
for row in all_cards:
    if row["title"] in by_title:
        raise ValueError(f"duplicate title: {row['title']}")
    by_title[row["title"]] = row

details = {row["title"]: row for row in tech + amb}
if len(details) != len(tech) + len(amb):
    raise ValueError("duplicate detail title across captured detail sets")
if len(tech) != 52 or len(amb) != 15 or len(all_cards) != 147:
    raise ValueError(f"expected list 147 / technical 52 / extra detail 15; got {len(all_cards)}/{len(tech)}/{len(amb)}")
main_titles = set(by_title)
main_titles = {title for title, card in by_title.items() if len(card.get("meta", [])) > 1 and card["meta"][1] == "程序&技术类"}
main_titles |= set(TECH_EXTRA)
review_titles = set(REVIEW_REASONS)
if main_titles & review_titles:
    raise ValueError("title assigned to both main and review")
for title in main_titles | review_titles:
    if title not in by_title or title not in details:
        raise ValueError(f"missing listing/detail for selected title {title}")
if len(main_titles) != 57 or len(review_titles) != 10:
    raise ValueError(f"unexpected selection counts {len(main_titles)} / {len(review_titles)}")

def make_row(title: str, decision: str) -> dict:
    card, detail = by_title[title], details[title]
    responsibilities, requirements = split_fields(detail["detail_text"])
    city_text = card["meta"][0]
    cities = [x.strip() for x in city_text.split("、") if x.strip()]
    if any(x not in {"北京", "上海"} for x in cities):
        raise ValueError(f"unexpected location for {title}: {cities}")
    evidence = (
        "；".join(filter(None, [TECH_EXTRA.get(title)]))
        if title in TECH_EXTRA
        else f"官网实习岗位分类为“{card['meta'][1]}”；详情职责和任职要求已核验。"
    )
    row = {
        "company_name": COMPANY,
        "company_website": "https://www.mihoyo.com/",
        "career_url": CAREER,
        "title": title,
        "detail_url": detail["detail_url"],
        "source_url": SOURCE,
        "source_job_id": detail["source_job_id"],
        "cities": cities,
        "recruitment_type": "实习",
        "raw_category": card["meta"][1],
        "category": "技术类" if decision == "accepted" else "待判断",
        "category_evidence": evidence if decision == "accepted" else REVIEW_REASONS[title],
        "responsibilities": responsibilities,
        "requirements": requirements,
        "published_at": None,
        "collection_method": "browser",
        "raw_payload": {
            "listing_page": card["listing_page"],
            "listing_position": card["listing_position"],
            "reported_list_total": 147,
            "internship_filter": "实习生专项",
            "official_detail_url": detail["detail_url"],
            "detail_evidence_file": "evidence/collector/mihoyo_technical_details_raw.json" if title in tech_titles else "evidence/collector/mihoyo_ambiguous_details_raw.json",
            "review_reason": REVIEW_REASONS.get(title),
        },
    }
    return row

tech_titles = {row["title"] for row in tech}
main = [make_row(title, "accepted") for title in sorted(main_titles, key=lambda t: (by_title[t]["listing_page"], by_title[t]["listing_position"]))]
review = [make_row(title, "review") for title in sorted(review_titles, key=lambda t: (by_title[t]["listing_page"], by_title[t]["listing_position"]))]
batch = {
    "company": COMPANY,
    "source_url": SOURCE,
    "collection": {
        "method": "Lexmount Cloud Browser 打开米哈游官网校园招聘系统，使用“实习生专项”筛选并逐页读取职位卡；再筛选“程序&技术类”逐页打开52条详情，并打开15条跨分类的AI产品、数据分析、技术美术、技术策划、测试和音频算法岗位详情核验职责、要求与城市。",
        "pages_read": len(pages),
        "reported_total": 147,
        "page_counts": [len(p["cards"]) for p in pages],
        "target_city_internship_cards": 147,
        "technical_category_filter_results": 52,
        "technical_category_pages_read": 6,
        "unique_details_read": len(details),
        "main_count": len(main),
        "review_count": len(review),
        "excluded_count": len(all_cards) - len(main) - len(review),
        "session_closed": False,
        "issues": [
            "官网招聘系统为 jobs.mihoyo.com 自有校园招聘站；官网列出实习生专项并提供岗位详情页，无第三方 ATS 跳转。",
            "实习生专项共147条，15页，每页10条，末页7条；列表全量岗位城市为上海、上海/北京或北京。",
            "程序&技术类筛选共52条、6页；对这52条及15条跨分类技术或边界岗位逐条读取详情，核对城市、岗位职责与任职要求。",
            "其余80条依官网类别和详情定位排除；10条产品/数据分析岗位技术相关性待人工判断并单独列入review_candidates。",
            "详情页未显示发布日期，published_at按原站字段未知记录为null。",
        ],
    },
    "jobs": main,
    "review_candidates": review,
}
OUT.write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
summary = []
for card in all_cards:
    title = card["title"]
    status = "accepted" if title in main_titles else "review" if title in review_titles else "excluded"
    reason = (
        "官方程序&技术类，详情确认技术研发职能。"
        if status == "accepted" and card["meta"][1] == "程序&技术类"
        else TECH_EXTRA.get(title, "")
        if status == "accepted"
        else REVIEW_REASONS.get(title, "")
        if status == "review"
        else f"官方类别“{card['meta'][1]}”；标题与列表职责方向属于非技术岗位（未列入AI/计算机研发范围）。"
    )
    summary.append({"title": title, "listing_page": card["listing_page"], "listing_position": card["listing_position"], "city": card["meta"][0], "official_category": card["meta"][1], "decision": status, "reason": reason})
cats={}
for row in all_cards:
    cats[row["meta"][1]]=cats.get(row["meta"][1],0)+1
city_counts={}
for row in all_cards:
    for city in row["meta"][0].split("、"):
        city_counts[city]=city_counts.get(city,0)+1
summary_doc = {
    "source_url": SOURCE,
    "reported_total": len(all_cards),
    "pages": len(pages),
    "page_counts": [len(p["cards"]) for p in pages],
    "category_counts": cats,
    "city_assignment_counts": city_counts,
    "decision_counts": {"accepted": len(main), "review": len(review), "excluded": len(all_cards)-len(main)-len(review)},
    "jobs": summary,
}
SUMMARY.write_text(json.dumps(summary_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Wrote {OUT.name}: accepted={len(main)} review={len(review)} excluded={len(all_cards)-len(main)-len(review)}; pages={len(pages)} details={len(details)}")

