$ErrorActionPreference='Stop'
$cli='C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'; $session='session_b01dcb54-7d96-4dea-a908-cf79c59a55e2'
$cities=@([pscustomobject]@{name='北京';item=1},[pscustomobject]@{name='上海';item=3},[pscustomobject]@{name='深圳';item=4})
$results=[System.Collections.Generic.List[object]]::new()
foreach($city in $cities){
 $nav=& $cli action open-url --session-id $session --url 'https://duodian.jobs.feishu.cn/dmall'|ConvertFrom-Json; if(!$nav.ok){throw 'Base navigation failed'}; Start-Sleep -Milliseconds 500
 $sel=".atsx-tree-treenode-switcher-close:nth-child($($city.item)) .atsx-tree-title"
 $ck=& $cli action click --session-id $session --selector $sel|ConvertFrom-Json; if(!$ck.ok){throw "City click failed $($city.name)"}
 Start-Sleep -Milliseconds 500
 $rr=& $cli action eval --session-id $session --expression 'JSON.stringify({url:location.href,cards:[...document.querySelectorAll(".positionItem")].map(x=>({title:x.querySelector(".positionItem-title-text")?.innerText.trim(),url:x.closest("a")?.href,first_line:x.innerText.split("\\n")[0],employment_line:x.innerText.split("\\n")[1]}))})'|ConvertFrom-Json; if(!$rr.ok){throw "City read failed $($city.name)"}; $d=$rr.data|ConvertFrom-Json
 $results.Add([pscustomobject]@{city=$city.name;url=$d.url;count=$d.cards.Count;cards=$d.cards})
}
$results|ConvertTo-Json -Depth 8|Set-Content evidence/collector/dmall_city_filter_results.json -Encoding utf8

