$ErrorActionPreference = 'Stop'
$browser = 'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$session = 'session_a0ff1b27-5869-4562-8d17-5993e3ea8f4c'
$ids = @('7696810175290722579','7694882372702406950','7694530904375003433','7694512278909815081','7687430606934870323','7686424818195384582','7681258986549184795','7680777984093309230','7680777482055928090','7673925527993157898','7673810434042677514','7670063623927515455','7668707263888247078','7659972138090760491','7657876546401847588','7652758550867314950','7647489944366172422')
$expr = 'JSON.stringify({url:location.href,title:document.title,text:document.body.innerText})'
foreach ($id in $ids) {
  $url = "https://shengshu.jobs.feishu.cn/index/position/$id/detail"
  $nav = & $browser action open-url --session-id $session --url $url --timeout-ms 60000 | ConvertFrom-Json
  if (-not $nav.ok) { throw "Could not open $id" }
  Start-Sleep -Milliseconds 800
  $raw = & $browser action eval --session-id $session --expression $expr | ConvertFrom-Json
  if (-not $raw.ok) { throw "Could not inspect $id" }
  $data = $raw.data | ConvertFrom-Json
  if ($data.url -notmatch $id) { throw "Unexpected detail URL for $id" }
  $data | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 "evidence/collector/shengshu_detail_$id.json"
  Write-Output "$id $($data.text.Length)"
}
