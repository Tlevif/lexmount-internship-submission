"""Build the evidence-backed Shengshu internship batch from Browser captures."""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
E = ROOT / "evidence/collector"
ENTRY = "https://shengshu.jobs.feishu.cn/"
SOCIAL = "https://shengshu.jobs.feishu.cn/index/position/list"
CAMPUS = "https://shengshu.jobs.feishu.cn/692892/position/list"
METHOD = (
    "Lexmount WebFetch读取清单官网招聘入口及职位页；Lexmount Cloud Browser核对社招、校招官方门户，"
    "遍历社招职位列表10页（100岗），逐一核对目标城市实习卡片，打开AI/计算机相关及边界岗位详情，"
    "并逐项操作北京、上海、深圳城市筛选。"
)

MAIN = {
    "7694530904375003433": ("游戏引擎开发实习生", "计算机/软件工程", "详情要求研究引擎运行机制、逆向与运行时插件/API开发、自动化场景生成和性能优化。"),
    "7681258986549184795": ("视频生成算法实习生 (后训练数据)", "AI模型评测与数据", "岗位负责视频生成后训练数据、benchmark与评测体系建设；要求熟悉diffusion/flow matching/DiT并具备工程实现能力。"),
    "7673925527993157898": ("Agent算法实习生", "AI/算法研发", "负责多模态视频创作Agent架构和决策模型迭代；要求理解VLM、Video Diffusion/DiT并掌握Python、PyTorch。"),
    "7673810434042677514": ("视频生成算法实习生 (蒸馏)", "AI/算法研发", "负责视频生成模型压缩与蒸馏，详情明确为模型算法研发。"),
    "7670063623927515455": ("流式视频Agent实习生", "AI/算法研发", "负责视频生成Agent设计、VLM训练评测、工具调用与低延迟系统优化；要求计算机/人工智能相关基础和Python。"),
    "7659972138090760491": ("大模型Infra实习生", "AI基础设施", "负责多模态及视频生成大模型基础设施建设，属于AI模型训练与推理工程。"),
    "7657876546401847588": ("具身算法实习生", "AI/算法研发", "负责模仿学习、VLA、世界模型与机器人操作大模型算法研发。"),
    "7652758550867314950": ("流式视频生成评测实习生", "AI模型评测与研发", "负责视频生成benchmark、自动化评测流程、指标分析与实验设计；要求计算机/AI相关专业、机器学习基础、Python与PyTorch。"),
    "7647489944366172422": ("流式视频生成训练实习生", "AI/算法研发", "负责实时视频生成模型分布式训练及模型结构/训练策略迭代；要求计算机/AI相关专业、DiT、Python和PyTorch模型训练经验。"),
}
REVIEW = {
    "7686424818195384582": ("AI产品实习生-Z", "岗位明确要求了解AI大模型，但职责集中在需求调研、竞品整理、文档、开发跟进和测试支持；详情未写明算法、软件实现或技术分析任务，技术相关性需复核。"),
}


def read(path: str):
    return json.loads((E / path).read_text(encoding="utf-8-sig"))


def write(path: str, value) -> None:
    (E / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    page_files = [E / f"shengshu_social_page_{n:02d}.json" for n in range(1, 11)]
    pages = [json.loads(p.read_text(encoding="utf-8-sig")) for p in page_files]
    all_cards = [c for page in pages for c in page["cards"]]
    by_id = {c["id"]: c for c in all_cards}
    if len(all_cards) != 100 or len(by_id) != 100:
        raise ValueError(f"expected 100 unique social positions, got {len(all_cards)} cards/{len(by_id)} IDs")
    campus = read("shengshu_campus_list.json")
    if "开启新的工作（0）" not in campus["text"]:
        raise ValueError("campus zero-result list capture is incomplete")

    internship_cards = [c for c in all_cards if "实习" in c["text"].split("\n")[1]]
    if len(internship_cards) != 22:
        raise ValueError(f"expected 22 internship cards, got {len(internship_cards)}")
    target_cards = [c for c in internship_cards if any(city in c["text"].split("\n")[1] for city in ("北京", "上海", "广州", "深圳", "杭州"))]
    if len(target_cards) != 22:
        raise ValueError(f"expected 22 target-city internships, got {len(target_cards)}")
    ids = {c["id"] for c in target_cards}
    if not set(MAIN).issubset(ids) or not set(REVIEW).issubset(ids):
        raise ValueError("a classified position is missing from target-city internship list")

    all_details: dict[str, dict] = {}
    detail_files = []
    for job_id in (*MAIN, *REVIEW):
        name = f"shengshu_detail_{job_id}.json"
        data = read(name)
        if not data["url"].endswith(f"/{job_id}/detail"):
            raise ValueError(f"detail URL mismatch for {job_id}: {data['url']}")
        card = by_id[job_id]
        if data["text"].splitlines()[5] != card["title"]:
            raise ValueError(f"detail title mismatch for {job_id}")
        all_details[job_id] = data
        detail_files.append(name)

    main_rows = []
    for job_id, (title, category, rationale) in MAIN.items():
        card = by_id[job_id]
        detail = all_details[job_id]["text"]
        lines = detail.splitlines()
        split = lines.index("职位要求") if "职位要求" in lines else len(lines)
        desc_start = lines.index("职位描述") + 1 if "职位描述" in lines else 7
        responsibilities = "\n".join(lines[desc_start:split]).strip()
        requirements = "\n".join(lines[split + 1:]).strip() if split < len(lines) else ""
        raw_category = card["text"].splitlines()[1].replace("北京实习", "").strip()
        main_rows.append({
            "company_name": "生数科技",
            "company_website": None,
            "career_url": SOCIAL,
            "title": title,
            "detail_url": card["url"],
            "source_url": SOCIAL,
            "collection_method": METHOD,
            "source_job_id": job_id,
            "cities": ["北京"],
            "recruitment_type": "实习",
            "raw_category": raw_category,
            "category": category,
            "category_evidence": rationale,
            "responsibilities": responsibilities,
            "requirements": requirements,
            "published_at": None,
            "raw_payload": {"listing_text": card["text"], "detail_text": detail},
        })

    review_rows = []
    for job_id, (title, rationale) in REVIEW.items():
        card = by_id[job_id]
        detail = all_details[job_id]["text"]
        lines = detail.splitlines()
        split = lines.index("职位要求") if "职位要求" in lines else len(lines)
        desc_start = lines.index("职位描述") + 1 if "职位描述" in lines else 7
        review_rows.append({
            "company_name": "生数科技",
            "company_website": None,
            "career_url": SOCIAL,
            "title": title,
            "detail_url": card["url"],
            "source_url": SOCIAL,
            "collection_method": METHOD,
            "source_job_id": job_id,
            "cities": ["北京"],
            "recruitment_type": "实习",
            "raw_category": card["text"].splitlines()[1].replace("北京实习", "").strip(),
            "category": "AI产品",
            "category_evidence": rationale,
            "responsibilities": "\n".join(lines[desc_start:split]).strip(),
            "requirements": "\n".join(lines[split + 1:]).strip() if split < len(lines) else "",
            "published_at": None,
            "raw_payload": {"listing_text": card["text"], "detail_text": detail},
        })

    decided = set(MAIN) | set(REVIEW)
    excluded = []
    excluded_reasons = {
        "财务实习生": "财务/审计职能工作，与AI或计算机技术工作无关。",
        "海外AI产品运营实习生": "AI产品运营岗位，职责为社媒社群、内容生态、用户运营和营销活动，无研发或技术分析任务。",
        "CSM实习生": "客户成功与销售支持岗位，包含客户数据整理，但无AI/计算机研发职责。",
        "产品营销实习生": "产品营销、内容制作和推广工作，无计算机技术职责。",
        "投融资实习生": "投融资职能工作，与目标技术方向无关。",
        "海外AI产品运营实习生-D": "AI产品日常运营、内容生态和用户调研工作，无研发或技术分析任务。",
        "海外运营实习生": "海外市场用户增长和运营推广工作，无技术职责。",
        "海外产品运营实习生（英语）": "AI视频工具产品运营工作，职责为产品运营与全球推广，无技术实现任务。",
        "模型产品增长运营实习生": "围绕AI模型产品开展用户增长和内容运营，不承担技术研发或计算工作。",
        "海外社媒内容运营实习生": "社交媒体内容运营工作，无技术职责。",
        "用户运营": "用户运营岗位，无计算机或AI技术职责。",
        "招聘实习生": "招聘职能岗位，与目标技术方向无关。",
    }
    decisions = []
    for card in target_cards:
        job_id = card["id"]
        if job_id in decided:
            decision = "main" if job_id in MAIN else "review"
            reason = MAIN[job_id][2] if job_id in MAIN else REVIEW[job_id][1]
        else:
            decision = "excluded"
            reason = excluded_reasons.get(card["title"])
            if not reason:
                raise ValueError(f"missing exclusion rationale: {card['title']}")
            excluded.append({"source_job_id": job_id, "title": card["title"], "city": "北京", "reason": reason})
        decisions.append({"source_job_id": job_id, "title": card["title"], "city": "北京", "decision": decision, "reason": reason, "detail_url": card["url"]})

    options = read("shengshu_social_city_beijing.json")["cities"]
    if not all(city in options for city in ("北京", "上海", "深圳")) or any(city in options for city in ("广州", "杭州")):
        raise ValueError(f"unexpected official city filter options: {options}")
    city_totals = {"北京": 99, "上海": 3, "深圳": 3, "广州": 0, "杭州": 0}
    internship_city_counts = {"北京": 22, "上海": 0, "深圳": 0, "广州": 0, "杭州": 0}

    classification = {
        "company": "生数科技",
        "source_url": ENTRY,
        "career_url": SOCIAL,
        "target_city_internship_counts": internship_city_counts,
        "decisions": decisions,
        "excluded_count": len(excluded),
        "excluded_positions": excluded,
    }
    write("shengshu_classification_decisions.json", classification)
    write("shengshu_city_filter_audit.json", {
        "social_ats": SOCIAL,
        "official_city_options": options,
        "all_position_results_by_city": city_totals,
        "target_city_internship_counts_from_all_10_list_pages": internship_city_counts,
        "city_filter_results_overlap": "上海、深圳筛选各返回3岗；这3条职位卡均同时列出北京、上海、深圳，因此各城市筛选结果不可相加。",
        "unavailable_filter_cities": ["广州", "杭州"],
    })

    evidence_files = [
        "shengshu_home_webfetch.json", "shengshu_social_webfetch.json", "shengshu_campus_webfetch.json",
        "shengshu_campus_list.json", "shengshu_social_city_beijing.json", "shengshu_social_city_shanghai.json",
        "shengshu_social_city_shenzhen.json", "shengshu_city_filter_audit.json",
        *[f"shengshu_social_page_{n:02d}.json" for n in range(1, 11)],
        *detail_files, "shengshu_classification_decisions.json", "shengshu_session_closed.json",
    ]
    now = datetime.now(timezone.utc).isoformat()
    batch = {
        "company": "生数科技",
        "source_url": ENTRY,
        "career_url": SOCIAL,
        "collection_method": METHOD,
        "source_chain": [ENTRY, SOCIAL, CAMPUS, "https://shengshu.jobs.feishu.cn/692892/"],
        "collection": {
            "run_started_at": "2026-10-22",
            "pages_read": 11,
            "reported_total": 100,
            "page_counts": [0, *([10] * 10)],
            "page_counts_by_list": {"campus_list": [0], "social_all_positions": [10] * 10},
            "target_city_internship_cards": len(target_cards),
            "main_candidates": len(main_rows),
            "review_candidates": len(review_rows),
            "excluded_count": len(excluded),
            "unique_source_positions": len(by_id),
            "stable_source_ids_unique": True,
            "target_city_counts": internship_city_counts,
            "city_filter_options": options,
            "all_position_city_filter_totals": city_totals,
            "session_id": "session_a0ff1b27-5869-4562-8d17-5993e3ea8f4c",
            "session_closed": True,
            "collection_completed_at_utc": now,
            "issues": [
                "校招官网职位列表当前显示0岗；主要采集源为官网链接的社招门户。",
                "社招列表共100岗，10页，每页10岗；全量卡片中22条标注为实习，均为北京。",
                "城市筛选菜单只有北京、上海、深圳、旧金山；广州、杭州未提供筛选项。上海、深圳筛选各返回3岗，三岗均标注北京/上海/深圳，故筛选结果重叠；三岗均为全职。",
            ],
            "evidence_files": evidence_files,
        },
        "jobs": main_rows,
        "review_candidates": review_rows,
    }
    write("shengshu_batch.json", batch)
    write("shengshu_run.json", {"company": "生数科技", "completed_at_utc": now, "pages_read": 11, "reported_total": 100, "main": len(main_rows), "review": len(review_rows), "excluded_internships": len(excluded), "session_closed": True})
    print(f"main={len(main_rows)} review={len(review_rows)} excluded={len(excluded)} target_internships={len(target_cards)} total={len(by_id)} pages=11")


if __name__ == "__main__":
    main()
