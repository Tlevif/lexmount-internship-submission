from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVID = ROOT / "evidence" / "collector"
SOURCE = "https://join.yingdao.com/"
LIST_URL = "https://join.yingdao.com/index/position/list"
METHOD = "通过影刀官网的职位导航进入官方 Feishu ATS 招聘站，使用 Lexmount Cloud Browser 读取职位列表6个分页，并对五城技术类岗位逐条打开详情核验岗位类型和内容。"

pages = [
    json.loads((EVID / f"yingdao_page_{number}.json").read_text(encoding="utf-8-sig"))
    for number in range(1, 7)
]
expected = [10, 10, 10, 10, 10, 4]
if [len(page["cards"]) for page in pages] != expected:
    raise ValueError("expected all six pages with 10,10,10,10,10,4 cards")
if any(str(page.get("count")) != "54" for page in pages):
    raise ValueError("all listing pages should show the same 54-position total")

cards = []
for page in pages:
    for card in page["cards"]:
        lines = [line.strip() for line in card["card_text"].splitlines() if line.strip()]
        if len(lines) < 2:
            raise ValueError("listing card is missing title or employment type")
        title, metadata = lines[:2]
        if "全职" not in metadata:
            raise ValueError(f"position is not explicitly full-time: {title} / {metadata}")
        cards.append({
            "title": title,
            "metadata": metadata,
            "detail_url": card["detail_url"],
            "card_text": card["card_text"],
            "page": page["page"],
        })

if len(cards) != 54 or len({card["detail_url"] for card in cards}) != 54:
    raise ValueError("expected 54 unique listed positions")

details = json.loads((EVID / "yingdao_technical_details.json").read_text(encoding="utf-8-sig"))
if len(details) != 8 or any(len(item.get("detail_text", "")) < 100 for item in details):
    raise ValueError("eight full technical detail pages must be captured")
if any("全职" not in item.get("detail_text", "") for item in details):
    raise ValueError("a technical detail does not confirm full-time status")

header = json.loads((EVID / "yingdao_listing_header.json").read_text(encoding="utf-8-sig"))
city_options = list(dict.fromkeys(header["city_filters"]))
required_cities = {"北京", "上海", "广州", "深圳", "杭州"}
if not required_cities.issubset(set(city_options)):
    raise ValueError("the visible ATS city filters do not include all five target cities")

all_city_counts: Counter[str] = Counter()
for card in cards:
    city_text = card["metadata"].split("全职", 1)[0]
    all_city_counts[city_text] += 1

listing_cards = [
    {
        "title": card["title"],
        "metadata": card["metadata"],
        "detail_url": card["detail_url"],
        "page": card["page"],
        "decision": "excluded_non_internship",
        "reason": "官方职位卡明确标注全职，不属于实习岗位。",
    }
    for card in cards
]
batch = {
    "company": "影刀RPA",
    "source_url": LIST_URL,
    "source_chain": [SOURCE, LIST_URL],
    "collection": {
        "method": METHOD,
        "pages_read": len(pages),
        "reported_total": len(cards),
        "page_counts": expected,
        "target_city_internship_cards": 0,
        "candidate_details_read": len(details),
        "main_count": 0,
        "review_count": 0,
        "excluded_count": len(cards),
        "session_closed": True,
        "issues": [
            "官网 WebFetch 首次读取的是客户端渲染壳；Cloud Browser 显示首页“职位”链接进入 join.yingdao.com/index/position/list，页面元数据标注为影刀社招官网。",
            "当前职位列表共54条、6页，逐页为10、10、10、10、10、4条。职位筛选提供城市与职能分类，没有实习或招聘类型筛选。",
            "已检查城市筛选选项，包含北京、上海、广州、深圳、杭州；54条职位卡全部标注全职，故当前列表没有目标实习岗位。",
            "打开8条五城技术相关职位详情（含两条不同的杭州RPA工程师记录），详情均再次标注全职。",
        ],
    },
    "jobs": [],
    "review_candidates": [],
}
(EVID / "yingdao_batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

summary = {
    "official_site": SOURCE,
    "official_list_url": LIST_URL,
    "official_list_name": "影刀社招官网",
    "city_filter_options": city_options,
    "internship_filter_available": False,
    "reported_total": len(cards),
    "pages_read": len(pages),
    "page_counts": expected,
    "all_cards_full_time": True,
    "city_counts_as_listed": dict(all_city_counts),
    "target_technical_details_read": [
        {"title": item["title"], "metadata": item["metadata"], "detail_url": item["detail_url"], "detail_characters": len(item["detail_text"])}
        for item in details
    ],
    "decisions": {"main": 0, "review": 0, "excluded_non_internship": len(cards)},
    "browser_session_closed": True,
    "listing_cards": listing_cards,
}
(EVID / "yingdao_classification_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(f"Wrote zero-result batch: pages={len(pages)} positions={len(cards)} main=0 review=0 details={len(details)}")
