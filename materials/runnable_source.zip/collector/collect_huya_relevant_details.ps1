$ErrorActionPreference='Stop'
$SessionId='session_7ee14698-fa71-43a3-967b-2881a6e3e23c'; $Target='3491C2AC44960A99EEE291467AB56813'; $cli='C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
$wanted=@('(2027届)大模型算法工程师','(2027届)多模态视频生成算法工程师','(2027届)AI推理后台开发工程师','(2027届)AIGC语音大模型算法工程师','(2027届)AI财务应用专员-技术方向','(2027届)产品经理-AI内容','(2027届)AI短视频编导','(2027届)AI视觉设计师-运营方向','(2027届)AI音视频研发工程师','(2027届)全栈开发工程师-AI应用方向')
$list=Get-Content evidence/collector/huya_mokahr_list_pages_raw.json -Raw|ConvertFrom-Json
$index=@{}; foreach($p in $list){foreach($c in $p.cards){$index[$c.title]=$c}}
$out='evidence/collector/huya_relevant_details_raw.json'; $details=[System.Collections.Generic.List[object]]::new()
foreach($title in $wanted){
 if(!$index.ContainsKey($title)){continue}; $row=$index[$title]
 $nav=& $cli action open-url --session-id $SessionId --target-id $Target --url $row.detail_url|ConvertFrom-Json
 if(!$nav.ok){throw "Navigation failed $title"}
 Start-Sleep -Milliseconds 700
 $rr=& $cli action eval --session-id $SessionId --target-id $Target --expression 'JSON.stringify({url:location.href,text:document.body.innerText})'|ConvertFrom-Json
 if(!$rr.ok){throw "Detail read failed $title"}; $body=$rr.data|ConvertFrom-Json
 if($body.url -ne $row.detail_url){throw "URL mismatch $title"}
 $details.Add([pscustomobject]@{title=$title;detail_url=$row.detail_url;city=$row.city;official_labels=$row.labels;listing_page=$p.page;detail_text=$body.text})
 $details|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $out -Encoding utf8
 Write-Output "Captured $title"
}
Write-Output "Captured $($details.Count) relevant details"

