"""Deterministic collectors for verified career pages."""

from .core import collect_company, iter_company_pages

__all__ = ["collect_company", "iter_company_pages"]
