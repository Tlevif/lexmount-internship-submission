"""Read outstanding public job pages in isolated Lexmount sessions."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib,json,subprocess,time
from collector.detail_sections import extract_sections
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence/rebuild20261027/browser'
CLI=r'C:\Users\Lenovo\.agents\skills\lexmount-browser\bin\browser-cli.exe'
SESSIONS=['session_d8c8072d-df71-416a-9f06-94ca9d349275','session_eb509a39-2de9-4b64-bc90-a6013799b613','session_2446390b-323a-4409-91af-ed6619022d60']
def run(args):
 p=subprocess.run([CLI,*args],capture_output=True,text=True,encoding='utf-8',timeout=70)
 r=json.loads(p.stdout or p.stderr)
 if not r.get('ok'):raise RuntimeError(r)
 return r['data']
def work(pair):
 sid,jobs=pair;tabs=run(['session','targets','--session-id',sid]);pages=[x for x in tabs if x['type']=='page'];assert len(pages)==1;tid=pages[0]['id']
 def act(kind,*args):return run(['action',kind,'--session-id',sid,'--target-id',tid,*args])
 for i,j in enumerate(jobs,1):
  p=OUT/(hashlib.sha256((j['company_name']+'|'+str(j['source_job_id'])).encode()).hexdigest()[:24]+'.json')
  if p.exists():continue
  record={'company_name':j['company_name'],'source_job_id':str(j['source_job_id']),'source_url':j['detail_url'],'checked_at_utc':datetime.now(timezone.utc).isoformat(),'session_id':sid,'target_id':tid,'tool':'Lexmount Cloud Browser'}
  try:
   act('raw','--method','Page.navigate','--params-json',json.dumps({'url':j['detail_url']}));time.sleep(2.5)
   expression='JSON.stringify({url:location.href,text:document.body.innerText,links:[...document.querySelectorAll("a[href]")].map(x=>({text:x.innerText,url:x.href})).filter(x=>x.text.includes("新链接")||x.text.includes("Agent Harness"))})'
   state=json.loads(act('eval','--expression',expression))
   if len(state.get('text',''))<100:time.sleep(2);state=json.loads(act('eval','--expression',expression))
   record.update(state);record.update(extract_sections(state.get('text','')))
  except Exception as e:record['error']=str(e)
  p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
  print(sid[-5:],i,'/',len(jobs),j['company_name'],len(record.get('text','')),flush=True)
if __name__=='__main__':
 jobs=json.loads((ROOT/'evidence/rebuild20261027/browser_targets.json').read_text('utf-8'))
 jobs=[j for j in jobs if j['company_name'] not in {'华为','360集团'}]
 with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(work,[(s,jobs[i::3]) for i,s in enumerate(SESSIONS)]))
