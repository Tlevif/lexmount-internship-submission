const $ = s => document.querySelector(s);
let offset = 0, total = 0;
const pageSize = 20;
const escapeHtml = text => String(text ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateText = text => text ? String(text).slice(0,10) : '原站未提供';
async function loadJobs(){
  const data = Object.fromEntries(new FormData($('#filters')).entries());
  const params = new URLSearchParams(Object.entries(data).filter(([,v])=>v));
  params.set('limit',pageSize); params.set('offset',offset);
  try{
    const response = await fetch('/api/jobs?'+params);
    if(!response.ok) throw new Error('岗位读取失败');
    const result = await response.json(); total = result.total;
    $('#result-count').textContent = `找到 ${total} 个岗位`;
    $('#jobs').innerHTML = result.items.length ? result.items.map(job => `<article class="job" data-id="${job.id}" tabindex="0"><div class="job-top"><div><p class="company">${escapeHtml(job.company_name)}</p><h3>${escapeHtml(job.title)}</h3></div><span class="arrow">↗</span></div><div class="tag-row"><span class="tag category">${escapeHtml(job.category)}</span>${(job.cities||[]).map(city=>`<span class="tag">${escapeHtml(city)}</span>`).join('')}<span class="tag">${escapeHtml(job.recruitment_type)}</span></div></article>`).join('') : '<div class="empty">暂无匹配岗位。可以更换筛选条件，或稍后等待采集任务完成。</div>';
    $('#prev').disabled = offset===0; $('#next').disabled = offset+pageSize>=total;
    const pages=Math.max(1,Math.ceil(total/pageSize));
    $('#page-label').textContent = `第 ${Math.floor(offset/pageSize)+1} / ${pages} 页`;
    $('#page-number').max=pages;$('#page-number').value=Math.floor(offset/pageSize)+1;$('#page-number').disabled=!total;$('#page-jump button').disabled=!total;$('#jump-error').textContent='';
  }catch(err){$('#jobs').innerHTML=`<div class="empty">${escapeHtml(err.message)}</div>`}
}
async function loadMeta(){
  const [stats,companies] = await Promise.all([fetch('/api/stats').then(r=>r.json()),fetch('/api/companies').then(r=>r.json())]);
  $('#stat-jobs').textContent=stats.jobs;
  $('#stat-companies').textContent=stats.verified_companies;
  $('#stat-companies-with-jobs').textContent=stats.active_employers;
  $('#city-stats').innerHTML=(stats.by_city||[]).map(x=>`<div class="city-stat"><span>${escapeHtml(x.city)}</span><strong>${x.count}</strong></div>`).join('') || '<p>暂无数据</p>';
  const categorySelect=$('#category-filter');
  categorySelect.innerHTML='<option value="">全部方向</option>'+(stats.by_category||[]).map(x=>`<option value="${escapeHtml(x.category)}">${escapeHtml(x.category)}（${x.count}）</option>`).join('');
  const select=$('#company-filter');
  select.innerHTML='<option value="">全部企业</option>'+companies.filter(x=>x.job_count).map(x=>`<option value="${escapeHtml(x.name)}">${escapeHtml(x.name)}</option>`).join('');
}
const missingDetail = j => j.detail_enrichment?.status==='offline' ? '岗位已下线，任职要求尚未核验' : j.detail_enrichment?.status==='not_found' ? '官网暂未检索到该岗位，任职要求尚未核验' : '尚未提取，待核验';
async function openDetail(id){
  const response=await fetch('/api/jobs/'+id); if(!response.ok) return;
  const j=await response.json();
  const validUrl=/^https?:\/\//i.test(j.detail_url||'') ? j.detail_url : '#';
  $('#detail-content').innerHTML=`<p class="company">${escapeHtml(j.company_name)}</p><h2>${escapeHtml(j.title)}</h2><div class="tag-row"><span class="tag category">${escapeHtml(j.category)}</span>${(j.cities||[]).map(c=>`<span class="tag">${escapeHtml(c)}</span>`).join('')}<span class="tag">${escapeHtml(j.recruitment_type)}</span></div><div class="detail-section"><h3>岗位职责</h3>${escapeHtml(j.responsibilities||missingDetail(j))}</div><div class="detail-section"><h3>任职要求</h3>${escapeHtml(j.requirements||missingDetail(j))}</div><div class="detail-section"><h3>技术栈</h3>${escapeHtml((j.classification?.skills||[]).join(" · "))}</div><a class="apply" href="${escapeHtml(validUrl)}" target="_blank" rel="noopener noreferrer">前往企业官网 ↗</a>`;
  $('#detail').showModal();
}
$('#filters').addEventListener('submit',e=>{e.preventDefault();offset=0;loadJobs()});
$('#export-jobs').addEventListener('click',()=>{
  const params=new URLSearchParams(Object.entries(Object.fromEntries(new FormData($('#filters')).entries())).filter(([,v])=>v));
  window.location.href='/api/jobs/export.csv?'+params.toString();
});
$('#page-jump').addEventListener('submit',e=>{e.preventDefault();const value=$('#page-number').value.trim(),n=Number(value),pages=Math.max(1,Math.ceil(total/pageSize));if(!value||!Number.isInteger(n)||n<1||n>pages){$('#jump-error').textContent=`请输入 1 至 ${pages} 的整数页码`;return}offset=(n-1)*pageSize;loadJobs()});
$('#prev').addEventListener('click',()=>{offset=Math.max(0,offset-pageSize);loadJobs()});
$('#next').addEventListener('click',()=>{offset+=pageSize;loadJobs()});
$('#jobs').addEventListener('click',e=>{const card=e.target.closest('.job');if(card)openDetail(card.dataset.id)});
$('#jobs').addEventListener('keydown',e=>{if(e.key==='Enter'){const card=e.target.closest('.job');if(card)openDetail(card.dataset.id)}});
$('#close-detail').addEventListener('click',()=>$('#detail').close());
loadJobs();loadMeta().catch(()=>{});

const taskStatus = status => ({queued:'排队中',running:'运行中',paused:'已暂停',completed:'已完成',completed_with_errors:'完成但有错误',failed:'失败',cancelled:'已取消'}[status]||status);
async function loadDiscoveryTasks(){
  const host=$('#discovery-tasks');
  try{
    const response=await fetch('/api/tasks?task_type=discovery&limit=8');
    if(!response.ok) throw new Error('任务读取失败');
    const tasks=await response.json();
    host.innerHTML=tasks.length?tasks.map(task=>{
      const events=(task.events||[]).slice(-3).map(event=>`${escapeHtml(event.at||'')} ${escapeHtml(event.message||event.stage||'')}`).join('<br>');
      const action=task.status==='running'||task.status==='queued'?`<button class="task-action" data-task="${escapeHtml(task.id)}" data-action="pause">暂停</button>`:task.status==='paused'?`<button class="task-action" data-task="${escapeHtml(task.id)}" data-action="resume">继续</button>`:'';
      return `<article class="discovery-task"><div class="discovery-task-head"><span><strong class="task-status">${escapeHtml(taskStatus(task.status))}</strong> · ${escapeHtml(task.started_at||'')}</span><span class="task-actions">${action}</span></div><div class="task-events">${events||'等待调度器执行'}</div></article>`;
    }).join(''):'<p class="small">暂无发现任务</p>';
    if(tasks.some(task=>['queued','running','paused'].includes(task.status))) setTimeout(loadDiscoveryTasks,10000);
  }catch(error){host.innerHTML=`<p class="small">${escapeHtml(error.message)}</p>`}
}
$('#discovery-form').addEventListener('submit',async event=>{
  event.preventDefault();
  const form=Object.fromEntries(new FormData(event.currentTarget).entries());
  const config={target_cities:form.cities.split(/[、,，\s]+/).filter(Boolean),industries:form.industries.split(/[、,，\s]+/).filter(Boolean),candidate_limit:Number(form.candidate_limit),search_budget:Number(form.search_budget)};
  const button=event.currentTarget.querySelector('button');button.disabled=true;
  try{
    const response=await fetch('/api/discovery/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({config})});
    const result=await response.json();if(!response.ok)throw new Error(result.detail||'任务创建失败');
    await loadDiscoveryTasks();
  }catch(error){$('#discovery-tasks').innerHTML=`<p class="small">${escapeHtml(error.message)}</p>`}
  finally{button.disabled=false}
});
$('#discovery-tasks').addEventListener('click',async event=>{
  const button=event.target.closest('[data-action]');if(!button)return;
  button.disabled=true;
  try{
    const response=await fetch(`/api/tasks/${encodeURIComponent(button.dataset.task)}/${button.dataset.action}`,{method:'POST'});
    if(!response.ok){const result=await response.json();throw new Error(result.detail||'任务操作失败')}
    await loadDiscoveryTasks();
  }catch(error){$('#discovery-tasks').insertAdjacentHTML('afterbegin',`<p class="small">${escapeHtml(error.message)}</p>`)}
});
loadDiscoveryTasks();
