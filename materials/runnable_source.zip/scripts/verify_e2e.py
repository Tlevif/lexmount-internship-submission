"""Import a saved, real Lexmount collection and check the public API."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient

from app.db import upsert_jobs
from app.main import app

ROOT = Path(__file__).resolve().parents[1]
sources = [ROOT / "evidence" / "collector" / name for name in
           ("bytedance_jobs_filtered.json", "baichuan_jobs_filtered.json")]
jobs = [row for source in sources for row in json.loads(source.read_text(encoding="utf-8"))]
assert jobs and all(row["collection_method"] == "browser" for row in jobs)
result = upsert_jobs(jobs)

with TestClient(app) as client:
    response = client.get("/api/jobs", params={"recruitment_type": "实习"})
    assert response.status_code == 200, response.text
    listing = response.json()
    assert listing["total"] >= len(jobs)
    assert {row["company_name"] for row in listing["items"]} == {"字节跳动", "百川智能"}
    detail = client.get(f"/api/jobs/{listing['items'][0]['id']}")
    assert detail.status_code == 200
    assert client.get("/").status_code == 200
    assert client.get("/api/stats").json()["jobs"] >= len(jobs)

report = {"observed_at_utc": datetime.now(timezone.utc).isoformat(),
          "sources": [str(source.relative_to(ROOT)) for source in sources],
          "raw_jobs": len(jobs),
          "upsert": result, "query_total": listing["total"],
          "first_title": listing["items"][0]["title"],
          "detail_status": detail.status_code, "homepage_status": 200}
out = ROOT / "evidence" / "e2e.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False))
