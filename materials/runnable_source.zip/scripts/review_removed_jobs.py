"""Apply the removal review, retaining original deletion evidence and timestamps."""
from pathlib import Path
import json, re, sys, sqlite3, collections, shutil
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.core import normalize_job, fingerprint
from app.classification import classify_content, SKILLS, hit

def read(path):return [json.loads(x) for x in path.read_text('utf8').split('\n') if x]
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')

def main():
    out=ROOT/'evidence/removal_review20261028';out.mkdir(exist_ok=True)
    archive=ROOT/'data/archive/20261027-before-rebuild'
    backup=ROOT/'data/archive/20261028-before-removal-review';backup.mkdir(exist_ok=True)
    if not (backup/'jobs.jsonl').exists():
        shutil.copy2(ROOT/'data/jobs.jsonl',backup/'jobs.jsonl')
        with sqlite3.connect(ROOT/'data/jobs.sqlite3') as a,sqlite3.connect(backup/'jobs.sqlite3') as b:a.backup(b)
    current=read(backup/'jobs.jsonl');removed=read(archive/'removed_non_cs.jsonl')
    incomplete=read(archive/'unverified_details.jsonl') if (archive/'unverified_details.jsonl').exists() else []
    # These boundary cases were reviewed against the saved official full texts.
    reject={84:'学科知识数据生产，编程仅加分',210:'模型使用与人工评测，Python仅优先',425:'埋点产品与分析工作，缺少必需计算机技能',699:'时尚标签与穿搭美学',919:'产品运营与业务指标分析',2102:'人因、美学与用户体验研究',440:'产品方案、PRD与业务评估，未核验工程开发任务',2236:'客户提示词与创作支持，未核验工程开发任务',2050:'内容策略与案例测试，仅要求AI产品使用',2227:'综合团队入口，已有具体研究员和研发岗位'}
    extra={258:'大模型后训练与强化学习',277:'大模型评测与安全',279:'大模型Agent算法',409:'数据工程与数据库',428:'全栈与应用开发',472:'大模型基模架构与模型研究',474:'大模型多模态与生成',475:'大模型多模态与生成',460:'软件测试与质量工程',463:'软件测试与质量工程',1284:'全栈与应用开发',2071:'网络与IT基础设施'}
    category={22:'大模型应用开发',117:'大模型应用开发',118:'图形图像与游戏技术',201:'大模型评测与安全',205:'大模型评测与安全',209:'大模型评测与安全',212:'大模型评测与安全',214:'大模型综合算法',218:'系统与计算基础设施',222:'大模型多模态与生成',226:'大模型评测与安全',243:'大模型训练系统与算力',272:'系统与计算基础设施',289:'大模型数据工程与合成',290:'系统与计算基础设施',293:'大模型评测与安全',296:'大模型数据工程与合成',297:'大模型应用算法',298:'大模型数据工程与合成',300:'大模型评测与安全',312:'大模型应用算法',313:'大模型基模架构与模型研究',318:'大模型多模态与生成',319:'大模型多模态与生成',322:'大模型应用算法',324:'大模型Agent算法',325:'大模型多模态与生成',330:'大模型多模态与生成',331:'系统与计算基础设施',335:'具身智能与机器人算法',337:'大模型多模态与生成',339:'大模型多模态与生成',341:'大模型多模态与生成',343:'大模型多模态与生成',344:'大模型应用算法',347:'大模型Agent算法',350:'大模型应用开发',352:'系统与计算基础设施',353:'大模型Agent算法',354:'大模型应用算法',355:'大模型评测与安全',364:'大模型Agent算法',365:'大模型Agent算法',368:'大模型多模态与生成',372:'大模型多模态与生成',373:'大模型多模态与生成',375:'系统与计算基础设施',388:'芯片与数字系统',390:'芯片与数字系统',391:'芯片与数字系统',421:'后端与分布式服务',426:'大模型应用开发',434:'大模型应用开发',435:'大模型Agent算法',436:'大模型数据工程与合成',438:'计算机安全',448:'大模型应用开发',449:'大模型应用开发',468:'决策优化与数据挖掘',484:'计算机视觉与图像算法',485:'图形图像与游戏技术',495:'语音与音频算法',1404:'大模型应用开发',1671:'数据工程与数据库',1846:'大模型应用开发'}
    restored=[];audit=[]
    for index,raw in enumerate(removed):
        raw=json.loads(json.dumps(raw,ensure_ascii=False));decision=classify_content(raw)
        if index in reject:decision.update(keep=False,category='非计算机岗位' if index!=2227 else '综合招聘入口',reason=reject[index])
        if index in extra:decision.update(keep=True,category=extra[index],reason='职责明确承担计算研究、软件开发或技术支持任务，结合完整要求复核确认')
        if index==422:
            # A single Huawei listing contains unrelated hardware directions.
            # Restore only its explicitly computer-related sub-directions.
            duties=raw['responsibilities'];req=raw['requirements']
            def section(text,name):
                m=re.search(r'【'+name+r'】\n(.*?)(?=\n\n【|\Z)',text,re.S);assert m;return m.group(1)
            battery=section(duties,'电池');vehicles=section(duties,'车辆工程技术')
            raw['title']='硬件技术工程师（电池云端大数据算法、车辆仿真软件方向）'
            raw['responsibilities']='【电池云端大数据算法】\n'+next(x for x in battery.split('\n') if '云端大数据算法' in x)+'\n\n【车辆仿真软件】\n'+next(x for x in vehicles.split('\n') if '仿真平台建设' in x)
            raw['requirements']='【电池云端大数据算法】\n'+next(x for x in section(req,'电池').split('\n') if '至少熟悉一门编程语言' in x)+'\n\n【车辆仿真软件】\n'+next(x for x in section(req,'车辆工程技术').split('\n') if '嵌入式软件' in x)
            raw.setdefault('raw_payload',{})['source_label_note']='仅展示原岗位中已核验的计算机算法和仿真软件方向；其他硬件方向未纳入。'
            decision.update(keep=True,category='系统与计算基础设施',reason='综合硬件岗位仅恢复云端算法与车辆仿真软件子方向')
        if index in category and decision['keep']:decision['category']=category[index]
        if decision['keep']:
            decision['skills']=[name for name,pattern in SKILLS.items() if hit(pattern,raw['responsibilities']+'\n'+raw['requirements'])]
            # Full fields and official URLs remain the review evidence; short
            # original regex hits alone are not presented as sufficient proof.
            decision['evidence']=[{'field':field,'text':raw[field]} for field in ['responsibilities','requirements']]
            review={k:decision[k] for k in ['keep','category','reason','skills','evidence']}
            raw.setdefault('raw_payload',{})['scope_review']=review
            job=normalize_job(raw);restored.append(job)
        audit.append(dict(index=index,company=raw['company_name'],source_job_id=raw.get('source_job_id'),title=raw['title'],detail_url=raw['detail_url'],status='restored' if decision['keep'] else 'remain_removed',category=decision['category'],reason=decision['reason'],evidence=decision.get('evidence',[]),original_archive='data/archive/20261027-before-rebuild/removed_non_cs.jsonl'))
    jobs=current+restored
    assert len(jobs)==len({fingerprint(j) for j in jobs})
    with sqlite3.connect(ROOT/'data/jobs.sqlite3') as con,sqlite3.connect(archive/'jobs.sqlite3') as old:
        columns=[x[1] for x in old.execute('PRAGMA table_info(jobs)')]
        for j in restored:
            fp=fingerprint(j)
            if not con.execute('SELECT 1 FROM jobs WHERE fingerprint=?',(fp,)).fetchone():
                saved=old.execute('SELECT * FROM jobs WHERE fingerprint=?',(fp,)).fetchone();assert saved
                values=dict(zip(columns,saved));values.pop('id')
                con.execute('INSERT INTO jobs ('+','.join(values)+') VALUES ('+','.join('?' for _ in values)+')',list(values.values()))
            payload=dict(j.get('raw_payload') or {});payload['classification']=j['classification']
            con.execute('UPDATE jobs SET title=?,category=?,category_evidence=?,responsibilities=?,requirements=?,raw_payload=? WHERE fingerprint=?',(j['title'],j['category'],j['category_evidence'],j['responsibilities'],j['requirements'],json.dumps(payload,ensure_ascii=False),fp))
        assert con.execute('SELECT COUNT(*) FROM jobs').fetchone()[0]==len(jobs)
    (ROOT/'data/jobs.jsonl').write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in jobs),encoding='utf8')
    dump(out/'classification_audit.json',audit)
    deleted=[dict(company=j['company_name'],title=j['title'],source_job_id=j.get('source_job_id'),detail_url=j['detail_url'],missing=[k for k in ['responsibilities','requirements'] if not str(j.get(k) or '').strip()],status='deleted_by_user_request') for j in incomplete]
    if deleted:dump(out/'deleted_incomplete_details.json',deleted)
    else:deleted=json.loads((out/'deleted_incomplete_details.json').read_text('utf8'))
    # User requested removal of the unresolved queue. Historical full snapshots
    # remain as provenance, never as active or pending records.
    (archive/'unverified_details.jsonl').unlink(missing_ok=True)
    summary=dict(reviewed_at_utc=datetime.now(timezone.utc).isoformat(),reviewed_removed_jobs=len(removed),restored_jobs=len(restored),remain_removed_jobs=len(removed)-len(restored),deleted_incomplete_jobs=len(deleted),pending_incomplete_jobs=0,previous_active_jobs=len(current),active_jobs=len(jobs),companies=len({j['company_name'] for j in jobs}),by_category=dict(collections.Counter(j['category'] for j in jobs)),method='对全部2295条已移除记录重跑职责与要求检查；复核技术信号、边界岗位和候选记录；具体人工复核决定随岗位保存。历史删除判断被本次逐条结果取代。',incomplete_meaning='12条缺少可核验任职要求，1条职责和要求均未取得；不等同于非技术岗位。按用户要求删除待处理记录。')
    dump(out/'SUMMARY.json',summary)
    lines=['# 已移除岗位复核（2026-10-28）','',f"此前2295条已从主库、SQLite及Demo移除。本次复核恢复{len(restored)}条，维持移除{len(removed)-len(restored)}条；当前{len(jobs)}条。",'', '误删原因包括技术职称词表过窄、中英文研究职称、跨学科计算研究、必需技能与优先项同句、岗位标题前置部门名称。具体恢复岗位、职责、要求、官网和分类见 classification_audit.json。维持移除的记录包括非技术任务、综合入口及技术证据不足，不能一概称作已证明非技术。','', '13条详情不完整：12条缺少可核验要求，1条两个字段均缺少。它们此前未进入演示；本次从待处理队列删除，待处理数为0。完整历史快照仅供追溯。','', '## 恢复岗位示例','']
    lines += [f"- {a['company']}｜{a['title']}｜{a['category']}" for a in audit if a['status']=='restored']
    (ROOT/'docs/REMOVAL_REVIEW.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in summary.items() if k!='by_category'},ensure_ascii=False))
if __name__=='__main__':main()
