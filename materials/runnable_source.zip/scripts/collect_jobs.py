"""Resume a verified career-site crawl into shared append-only JSONL files.

Example: python -X utf8 -m scripts.collect_jobs --company 字节跳动
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from app.db import upsert_jobs
from collector import iter_company_pages
from scripts.job_store import append_unique, existing_fingerprints, mark_page, read_progress, save_progress

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "data" / "jobs.jsonl"
REVIEW = ROOT / "data" / "review_candidates.jsonl"
PROGRESS = ROOT / "data" / "collection_progress.json"
CURATION = ROOT / "data" / "curation_decisions.json"


def config_for(company: str) -> dict:
    for path in (ROOT / "configs" / "sites").glob("*.json"):
        config = json.loads(path.read_text(encoding="utf-8"))
        if company == (config.get("company_name") or config.get("name")):
            if config.get("verified_for_collection") is not True:
                raise ValueError(f"Site is not verified for collection: {company}")
            return config
    raise ValueError(f"No site configuration for {company}")


def crawl(company: str, start_page: int | None = None, end_page: int | None = None,
          audit_range: bool = False) -> dict:
    config = config_for(company)
    progress = read_progress(PROGRESS)
    if start_page is None:
        source = progress["sources"].get(company, {})
        last = source.get("last_completed_page", 0)
        total = source.get("reported_total", 0)
        pages = math.ceil(total / int(config.get("page_size", 10))) if total else 0
        start_page = 1 if pages and last >= pages else last + 1
    if start_page < 1 or (end_page is not None and end_page < start_page):
        raise ValueError("Invalid page range")
    seen = existing_fingerprints(MAIN)
    review_seen = existing_fingerprints(REVIEW)
    reviewed_ids = (json.loads(CURATION.read_text(encoding="utf-8")).get("move_to_review", {})
                    if CURATION.exists() else {})
    counts = {"pages": 0, "raw_cards": 0, "eligible": 0, "appended": 0,
              "review_candidates": 0, "review_appended": 0, "db_inserted": 0,
              "db_updated": 0}
    expected_pages = None
    totals: set[int] = set()
    iterator = iter_company_pages(config, start_page=start_page, end_page=end_page)
    try:
        for page_result in iterator:
            page = int(page_result["page"])
            total = int(page_result["reported_total"])
            raw_count = int(page_result["raw_count"])
            jobs = page_result["jobs"]
            review = page_result["review_candidates"]
            manually_reviewed = [job for job in jobs if job.get("source_job_id") in reviewed_ids]
            jobs = [job for job in jobs if job.get("source_job_id") not in reviewed_ids]
            review = review + manually_reviewed
            page_size = int(config.get("page_size", 10))
            expected_pages = math.ceil(total / page_size) if total else None
            if expected_pages and page < expected_pages and raw_count < page_size:
                raise RuntimeError(f"Incomplete page {page}: {raw_count} cards, expected {page_size}")
            if len(jobs) + len(review) != page_result["eligible_count"]:
                raise RuntimeError(f"Eligible count mismatch on page {page}")
            appended = append_unique(MAIN, jobs, seen)
            review_appended = append_unique(REVIEW, review, review_seen)
            db_result = upsert_jobs(jobs) if jobs else {"inserted": 0, "updated": 0}
            if not audit_range:
                mark_page(progress, company, page, total, raw_count, len(jobs), len(review))
                save_progress(PROGRESS, progress)
            counts["pages"] += 1
            counts["raw_cards"] += raw_count
            counts["eligible"] += len(jobs)
            counts["appended"] += appended
            counts["review_candidates"] += len(review)
            counts["review_appended"] += review_appended
            counts["db_inserted"] += db_result["inserted"]
            counts["db_updated"] += db_result["updated"]
            totals.add(total)
            print(json.dumps({"company": company, "page": page, "expected_pages": expected_pages,
                              "raw": raw_count, "eligible": len(jobs), "new": appended,
                              "review": len(review), "review_new": review_appended}, ensure_ascii=False), flush=True)
    finally:
        iterator.close()
    return {"company": company, "audit_range": audit_range, "start_page": start_page,
            "last_completed_page": progress["sources"].get(company, {}).get("last_completed_page"),
            "expected_pages_at_last_page": expected_pages,
            "reported_totals_seen": sorted(totals), **counts,
            "output": str(MAIN), "review_output": str(REVIEW),
            "complete": bool(expected_pages and progress["sources"].get(company, {}).get("last_completed_page", 0) >= expected_pages)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--company", required=True)
    parser.add_argument("--start-page", type=int)
    parser.add_argument("--end-page", type=int)
    parser.add_argument("--audit-range", action="store_true",
                        help="Revisit an explicit range without changing the forward checkpoint")
    args = parser.parse_args()
    if args.audit_range and (args.start_page is None or args.end_page is None):
        parser.error("--audit-range requires --start-page and --end-page")
    print(json.dumps(crawl(args.company, args.start_page, args.end_page, args.audit_range), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
