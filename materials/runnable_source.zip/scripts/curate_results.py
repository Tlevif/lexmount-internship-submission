"""Apply reviewed corrections to the shared catalog without losing source records."""
from __future__ import annotations

import json
import os
from pathlib import Path

from app.core import fingerprint
from app.db import connect, init_db
from scripts.collect_jobs import MAIN, REVIEW, ROOT
from scripts.job_store import append_unique, existing_fingerprints

DECISIONS = ROOT / "data" / "curation_decisions.json"


def main() -> None:
    decisions = json.loads(DECISIONS.read_text(encoding="utf-8"))["move_to_review"]
    rows = [json.loads(line) for line in MAIN.read_text(encoding="utf-8").split("\n") if line.strip()]
    moved = [row for row in rows if row.get("source_job_id") in decisions]
    kept = [row for row in rows if row.get("source_job_id") not in decisions]
    review_ids = {json.loads(line).get("source_job_id") for line in REVIEW.read_text(encoding="utf-8").split("\n")
                  if line.strip()} if REVIEW.exists() else set()
    missing = sorted(set(decisions) - {row.get("source_job_id") for row in moved} - review_ids)
    if missing:
        raise ValueError(f"Curation IDs missing from both files: {missing}")
    if not moved:
        return
    # Keep every original record in review before replacing the main catalog.
    append_unique(REVIEW, moved, existing_fingerprints(REVIEW))
    tmp = MAIN.with_name(MAIN.name + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as stream:
        for row in kept:
            stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, MAIN)
    init_db()
    keys = [fingerprint(row) for row in moved]
    with connect() as con:
        con.executemany("UPDATE jobs SET status='uncertain' WHERE fingerprint=?", [(key,) for key in keys])
    print(json.dumps({"moved_to_review": len(moved), "main_remaining": len(kept),
                      "review_total": sum(1 for _ in REVIEW.open(encoding="utf-8"))}, ensure_ascii=False))


if __name__ == "__main__":
    main()
