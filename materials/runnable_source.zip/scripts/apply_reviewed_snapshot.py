from pathlib import Path
import json,re,collections,csv,sqlite3,hashlib
from datetime import datetime,timezone
from app.core import normalize_job,fingerprint
from app.classification import classify_content
from collector.rebuild_details import missing
ROOT=Path('.');E=ROOT/'evidence/rebuild20261027'
js=[json.loads(x) for x in (E/'working_jobs.jsonl').read_text('utf-8').split('\n') if x]
before=[json.loads(x) for x in Path('data/archive/20261027-before-rebuild/jobs.jsonl').read_text('utf-8').split('\n') if x]
old={fingerprint(j):j for j in before}
for j in js:
 if j['company_name']=='华为':
  f=E/'huawei'/(str(j['source_job_id'])+'.json')
  if not f.exists():continue
  d=json.loads(f.read_text('utf-8'));directions=[]
  for x in d['directions']:
   if x['direction']=='UX设计':
    def part(text,number):
     m=re.search(r'(?:^|\n)'+str(number)+r'、[^\n]+',text)
     return m.group(0).strip() if m else ''
    x=dict(x,direction='HCI与前端技术',responsibilities='\n'.join(part(x.get('responsibilities',''),n) for n in [2,5]),requirements='\n'.join(part(x.get('requirements',''),n) for n in [2,5]))
   if classify_content(dict(title=j['title']+'（'+x['direction']+'）',responsibilities=x.get('responsibilities'),requirements=x.get('requirements')))['keep']:directions.append(x)
  if directions:
   j.setdefault('raw_payload',{})['original_title']=j['title'];j['title']+='（'+'、'.join(x['direction'] for x in directions)+'方向）'
   for k in ['responsibilities','requirements']:j[k]='\n\n'.join('【'+x['direction']+'】\n'+x[k] for x in directions if x.get(k))
   j['raw_payload']['source_label_note']='综合岗位仅展示已核验的计算机技术方向；完整原文与其他方向保存在补采证据。'
kept=[];excluded=[];pending=[];audit=[]
for j in js:
 n=normalize_job(j);d=n['classification'];absent=[k for k in ['responsibilities','requirements'] if missing(n.get(k))]
 umbrella=j['company_name']=='DeepSeek' and j['title']=='Agent Harness 团队'
 if absent:status='detail_unverified';reason='官网复读后仍未获得可核验字段：'+','.join(absent);pending.append(n)
 elif umbrella:status='removed_non_job';reason='综合团队招聘入口，技术方向已由研究员与研发工程师岗位分别展示';excluded.append(n)
 elif d['keep']:status='retained';reason=d['reason'];kept.append(n)
 else:status='removed_non_cs';reason=d['reason'] if d['category']!='待核验' else '职责和任职要求未确认到计算机技术工作';excluded.append(n)
 o=old[fingerprint(j)];audit.append(dict(company_name=j['company_name'],source_job_id=j.get('source_job_id'),title=j['title'],old_category=o.get('category'),new_category=d['category'] if status=='retained' else None,status=status,reason=reason,skills=d['skills'],detail_url=j['detail_url'],fields_filled=[k for k in ['responsibilities','requirements'] if missing(o.get(k)) and not missing(j.get(k))]))
assert len(kept)+len(excluded)+len(pending)==5213
assert all(j['classification']['keep'] and all(not missing(j.get(k)) for k in ['responsibilities','requirements']) for j in kept)
assert len(kept)==len(set(fingerprint(j) for j in kept))
for name,rows in [('jobs',kept),('removed_non_cs',excluded),('unverified_details',pending)]:
 path=Path('data/jobs.jsonl') if name=='jobs' else Path('data/archive/20261027-before-rebuild')/(name+'.jsonl')
 path.write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in rows),encoding='utf-8')
(E/'classification_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'checked_at_utc':datetime.now(timezone.utc).isoformat(),'before_jobs':5213,'retained_jobs':len(kept),'removed_non_cs_or_umbrella':len(excluded),'unverified_detail_jobs':len(pending),'companies_with_jobs':len(set(j['company_name'] for j in kept)),'fields_filled':dict(collections.Counter(k for a in audit for k in a['fields_filled'])),'jobs_filled':sum(bool(a['fields_filled']) for a in audit),'by_category':dict(collections.Counter(j['category'] for j in kept)),'retained_missing':{k:sum(missing(j.get(k)) for j in kept) for k in ['responsibilities','requirements']},'classification_version':'cs-content-v2','scope':'按岗位名称、实际职责及任职要求确认计算机技术工作；不使用旧分类；综合入口不作为独立岗位。'}
(E/'SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
# Keep historical first-seen/collected timestamps while applying the reviewed snapshot.
with sqlite3.connect('data/jobs.sqlite3') as con:
 for j in kept:
  if not con.execute('SELECT 1 FROM jobs WHERE fingerprint=?',(j['fingerprint'],)).fetchone():
   with sqlite3.connect('data/archive/20261027-before-rebuild/jobs.sqlite3') as archived:
    saved=archived.execute('SELECT * FROM jobs WHERE fingerprint=?',(j['fingerprint'],)).fetchone()
    columns=[x[1] for x in archived.execute('PRAGMA table_info(jobs)')];values=dict(zip(columns,saved));values.pop('id',None)
    con.execute('INSERT INTO jobs ('+','.join(values)+') VALUES ('+','.join('?' for _ in values)+')',list(values.values()))
  payload=dict(j.get('raw_payload') or {});payload['classification']=j['classification']
  con.execute('UPDATE jobs SET title=?,category=?,category_evidence=?,responsibilities=?,requirements=?,detail_url=?,raw_payload=? WHERE fingerprint=?',(j['title'],j['category'],j['category_evidence'],j['responsibilities'],j['requirements'],j['detail_url'],json.dumps(payload,ensure_ascii=False),j['fingerprint']))
 ids=set(j['fingerprint'] for j in kept)
 for (fp,) in con.execute('SELECT fingerprint FROM jobs').fetchall():
  if fp not in ids:con.execute('DELETE FROM jobs WHERE fingerprint=?',(fp,))
 assert con.execute('SELECT COUNT(*) FROM jobs').fetchone()[0]==len(kept)
print(json.dumps(summary,ensure_ascii=False))
