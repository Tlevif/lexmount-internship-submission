"""Reclassify the retained snapshot without changing collection timestamps or scope."""
from pathlib import Path
import collections, json, sqlite3, sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.core import normalize_job, fingerprint
from app.taxonomy import VERSION, SOURCES, RULES

def main():
    backup=ROOT/'data/archive/20261028-before-taxonomy';backup.mkdir(parents=True,exist_ok=True)
    source=ROOT/'data/jobs.jsonl';db=ROOT/'data/jobs.sqlite3'
    if not (backup/'jobs.jsonl').exists():
        (backup/'jobs.jsonl').write_bytes(source.read_bytes())
        with sqlite3.connect(db) as con, sqlite3.connect(backup/'jobs.sqlite3') as target:con.backup(target)
    jobs=[json.loads(x) for x in (backup/'jobs.jsonl').read_text('utf8').split('\n') if x]
    updated=[];audit=[]
    for raw in jobs:
        j=normalize_job(raw);assert j['classification']['keep'] and j['responsibilities'] and j['requirements'],j['title']
        audit.append({'company':j['company_name'],'title':j['title'],'source_job_id':j.get('source_job_id'),'old_category':raw['category'],'category':j['category'],'classification':j['classification'],'detail_url':j['detail_url']})
        updated.append(j)
    assert len(updated)==len(jobs)==2905
    with sqlite3.connect(db) as con:
        for j in updated:
            row=con.execute('SELECT raw_payload FROM jobs WHERE fingerprint=?',(fingerprint(j),)).fetchone();assert row is not None,j['title']
            payload=json.loads(row[0] or '{}');payload['classification']=j['classification']
            cur=con.execute('UPDATE jobs SET category=?,category_evidence=?,raw_payload=? WHERE fingerprint=?',(j['category'],j['category_evidence'],json.dumps(payload,ensure_ascii=False),fingerprint(j)))
            assert cur.rowcount==1
    source.write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in updated),encoding='utf8')
    out=ROOT/'evidence/taxonomy20261028';out.mkdir(parents=True,exist_ok=True)
    counts=dict(collections.Counter(j['category'] for j in updated))
    summary={'version':VERSION,'jobs':len(updated),'by_category':counts,'large_model_jobs':sum(v for k,v in counts.items() if k.startswith('大模型')),'large_model_categories':len([k for k in counts if k.startswith('大模型')]),'sources':SOURCES,'policy':'标题确定候选分工，职责核对交付任务，任职要求核对技术能力；团队介绍和仅加分项不单独改变分类；沿用已核验计算机技术岗位范围。'}
    for name,obj in [('SUMMARY.json',summary),('classification_audit.json',audit)]:
        (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf8')
    lines=['# 技术岗位分类依据（2026-10-28）','',summary['policy'],'','公开招聘参考：']+[f"- [{x['title']}]({x['url']})" for x in SOURCES]+['','按本库岗位任务整理大模型方向：']
    descriptions=['训练框架、分布式并行、训练稳定性及算力调度','推理引擎、量化、算子、延迟与部署','训练数据管道、语料清洗、数据配比及合成','能力评测、基准、模型安全、红队与可解释性','SFT、偏好优化、奖励模型及RL训练','预训练、持续预训练及训练缩放规律','模型结构、注意力、MoE及长上下文','视觉/音频/视频语言模型与内容生成','智能体规划、决策、工具学习及多智能体算法','Agent、RAG、工作流和模型API的工程集成','检索增强、领域适配、生成式搜索及推荐应用']
    lines += [f'- **{r[0]}**：{description}（{counts.get(r[0],0)}条）' for r,description in zip(RULES,descriptions)]
    lines += [f"- **大模型综合算法**：职责涉及多个阶段，原文未明确单一分工（{counts.get('大模型综合算法',0)}条）。",'',f"总计{len(updated)}条、{len(counts)}个技术类别。其中大模型{summary['large_model_jobs']}条、{summary['large_model_categories']}个类别。其余按推荐搜索广告、视觉、语音、自然语言、具身智能、决策挖掘、通用机器学习和软件工程方向分类。",'', '逐条分类及原文命中片段见 evidence/taxonomy20261028/classification_audit.json；旧版快照见 data/archive/20261028-before-taxonomy/。']
    (ROOT/'docs/TAXONOMY.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
