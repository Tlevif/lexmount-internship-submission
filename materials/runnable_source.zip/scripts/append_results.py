"""Append verified jobs from another collector to the shared result file."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from app.db import upsert_jobs
from scripts.collect_jobs import MAIN
from scripts.job_store import append_unique, existing_fingerprints


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True,
                        help="JSON array of verified job dictionaries")
    args = parser.parse_args()
    jobs = json.loads(args.input.read_text(encoding="utf-8"))
    if not isinstance(jobs, list):
        parser.error("input must contain a JSON array")
    for row in jobs:
        if not all(row.get(key) for key in ("company_name", "title", "detail_url", "source_url", "collection_method")):
            parser.error("each job requires company_name, title, detail_url, source_url, collection_method")
    count = append_unique(MAIN, jobs, existing_fingerprints(MAIN))
    db_result = upsert_jobs(jobs) if jobs else {"inserted": 0, "updated": 0}
    print(json.dumps({"input": str(args.input), "read": len(jobs),
                      "appended": count, "output": str(MAIN), "database": db_result}, ensure_ascii=False))


if __name__ == "__main__":
    main()
