"""Idempotently integrate one verified company crawl into shared storage."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from app.core import fingerprint
from app.db import connect, upsert_jobs
from scripts.collect_jobs import MAIN, PROGRESS, REVIEW, ROOT
from scripts.job_store import append_unique, existing_fingerprints, read_progress, save_progress


def read_batch(path: Path) -> dict:
    batch = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(batch, dict) or not isinstance(batch.get("company"), str):
        raise ValueError("batch must contain a company name")
    if not isinstance(batch.get("collection"), dict):
        raise ValueError("batch must contain collection metadata")
    if not isinstance(batch.get("jobs", []), list) or not isinstance(batch.get("review_candidates", []), list):
        raise ValueError("jobs and review_candidates must be arrays")
    for row in batch.get("jobs", []) + batch.get("review_candidates", []):
        if row.get("company_name") != batch["company"]:
            raise ValueError("batch company does not match a job record")
        if not all(row.get(key) for key in ("company_name", "title", "detail_url", "source_url", "collection_method")):
            raise ValueError("each job needs company_name, title, detail_url, source_url and collection_method")
    if not batch.get("source_url"):
        raise ValueError("batch must record its verified source_url")
    main_ids = {fingerprint(row) for row in batch.get("jobs", [])}
    review_ids = {fingerprint(row) for row in batch.get("review_candidates", [])}
    if len(main_ids) != len(batch.get("jobs", [])) or len(review_ids) != len(batch.get("review_candidates", [])):
        raise ValueError("duplicate job identity inside a batch")
    if main_ids & review_ids:
        raise ValueError("a job cannot be both included and awaiting review")
    return batch


def integrate(batch: dict, main_path: Path = MAIN, review_path: Path = REVIEW,
              progress_path: Path = PROGRESS) -> dict:
    jobs = batch.get("jobs", [])
    review = batch.get("review_candidates", [])
    main_seen = existing_fingerprints(main_path)
    review_seen = existing_fingerprints(review_path)
    batch_main = {fingerprint(row) for row in jobs}
    batch_review = {fingerprint(row) for row in review}
    if batch_main & review_seen or batch_review & main_seen:
        raise ValueError("batch identities already exist in the opposite output file")

    appended = append_unique(main_path, jobs, main_seen)
    review_appended = append_unique(review_path, review, review_seen)
    main_db = upsert_jobs(jobs) if jobs else {"collected": 0, "inserted": 0, "updated": 0}
    review_db = upsert_jobs(review) if review else {"collected": 0, "inserted": 0, "updated": 0}
    if review:
        with connect() as con:
            for row in review:
                con.execute("UPDATE jobs SET status='uncertain' WHERE fingerprint=?", (fingerprint(row),))

    meta = batch["collection"]
    pages = int(meta.get("pages_read", 0) or 0)
    raw_page_counts = meta.get("page_counts") or []
    page_counts_by_list = raw_page_counts if isinstance(raw_page_counts, dict) else None
    page_counts = (
        [count for counts in raw_page_counts.values() for count in counts]
        if page_counts_by_list is not None
        else raw_page_counts
    )
    progress = read_progress(progress_path)
    if pages:
        progress.setdefault("sources", {}).setdefault(batch["company"], {}).update({
            "last_completed_page": pages,
            "reported_total": meta.get("reported_total"),
            "last_raw_count": page_counts[-1] if page_counts else None,
            "last_eligible_count": len(jobs),
            "last_review_count": len(review),
            "pages_read": pages,
            "page_counts": page_counts,
            "target_city_internship_cards": meta.get("target_city_internship_cards"),
            "excluded_count": meta.get("excluded_count"),
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
        })
        if page_counts_by_list is not None:
            progress["sources"][batch["company"]]["page_counts_by_list"] = page_counts_by_list
        save_progress(progress_path, progress)

    return {
        "company": batch["company"], "pages_read": pages,
        "reported_total": meta.get("reported_total"), "page_counts": page_counts,
        "main_input": len(jobs), "main_appended": appended,
        "review_input": len(review), "review_appended": review_appended,
        "main_database": main_db, "review_database": review_db,
        "source_url": batch["source_url"],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True, help="verified batch evidence JSON")
    args = parser.parse_args()
    print(json.dumps(integrate(read_batch(args.input)), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
