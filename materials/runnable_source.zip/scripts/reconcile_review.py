"""Promote clearly technical records from the append-only review file."""

from __future__ import annotations

import json
from datetime import datetime, timezone

from app.db import upsert_jobs
from app.core import fingerprint
from app.job_triage import triage_job
from scripts.collect_jobs import MAIN, REVIEW
from scripts.job_store import append_unique, existing_fingerprints


def main() -> None:
    if not REVIEW.exists():
        print(json.dumps({"reviewed": 0, "promoted": 0, "remaining": 0}))
        return
    rows = [json.loads(line) for line in REVIEW.read_text(encoding="utf-8").split("\n") if line.strip()]
    decisions = [triage_job(row) for row in rows]
    selected = [row for row, (decision, _) in zip(rows, decisions) if decision == "include"]
    seen = existing_fingerprints(MAIN)
    promoted = [row for row in selected if fingerprint(row) not in seen]
    appended = append_unique(MAIN, promoted, seen)
    db_result = upsert_jobs(promoted) if promoted else {"inserted": 0, "updated": 0}
    counts = {name: sum(decision == name for decision, _ in decisions)
              for name in ("include", "review", "exclude")}
    summary = {"observed_at_utc": datetime.now(timezone.utc).isoformat(),
               "reviewed": len(rows), "decisions": counts,
               "promoted_to_jobs_jsonl": appended, "db": db_result}
    (MAIN.parent / "review_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
