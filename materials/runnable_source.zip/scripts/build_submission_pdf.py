from pathlib import Path
import json
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT

root=Path(__file__).resolve().parents[1]
out=root/'submission/20261027'
summary=json.loads((out/'SUMMARY.json').read_text('utf8'))
pdfmetrics.registerFont(TTFont('Chinese','C:/Windows/Fonts/simhei.ttf'))
green=HexColor('#245842')
body=ParagraphStyle('Body',fontName='Chinese',fontSize=9.3,leading=14.5,spaceAfter=6,wordWrap='CJK',textColor=HexColor('#253a30'))
h1=ParagraphStyle('Title',parent=body,fontSize=24,leading=33,spaceAfter=18,textColor=green)
h2=ParagraphStyle('Heading',parent=body,fontSize=14,leading=22,spaceBefore=12,spaceAfter=9,keepWithNext=True,textColor=green)
small=ParagraphStyle('Small',parent=body,fontSize=8,leading=13,textColor=HexColor('#637366'))
story=[]
for line in (out/'REPORT.md').read_text('utf-8').split('\n'):
    line=line.strip()
    if not line: continue
    style=body
    if line.startswith('# '):style=h1;line=line[2:]
    elif line.startswith('## '):style=h2;line=line[3:]
    elif line.startswith('- '):line='- '+line[2:]
    parts=line.split('**'); text=''.join(('<b>'+escape(t)+'</b>') if i%2 else escape(t) for i,t in enumerate(parts))
    story.append(Paragraph(text,style))
story += [PageBreak(),Paragraph('运行截图 / Lexmount 云端读取',h1),Paragraph('2026-10-27，Lexmount Cloud Browser 打开百川官方飞书招聘列表。页面显示6条日常实习；页面文本、地址和会话标识保存在 cloud_recheck_20261027.json。',body)]
image=Image(str(out/'screenshots/cloud-baichuan.png'))
image.drawHeight=480*image.imageHeight/image.imageWidth;image.drawWidth=480
story.extend([image,Spacer(1,14),Paragraph('截图为本次真实云端页面。历史WebFetch的6条标题、Cloud Browser补全的详情链接和最终结果可以交叉核对。',body)])
story += [PageBreak(),Paragraph('运行截图 / 当前结果演示',h1),Paragraph(f"上：复核后的技术岗位结果，共{summary['jobs']:,}条、{summary['companies_with_jobs']}家企业。下：已恢复岗位的职责、要求、技术栈与来源。",body)]
imgs=[]
for filename in ['local-overview.png','local-baichuan.png']:
    im=Image(str(out/'screenshots'/filename));im.drawHeight=480*im.imageHeight/im.imageWidth;im.drawWidth=480;imgs.append(im)
story.append(Table([[imgs[0]],[imgs[1]]],colWidths=[480],style=TableStyle([('VALIGN',(0,0),(-1,-1),'TOP')])))
story.append(Paragraph('截图展示本次更新后的结果快照。批量云采集发生于2026-10-22至23日，百川于10月27日补充复核。完整结果快照可在材料页按企业、城市和方向检索。',small))

def chrome(c,doc):
    w,h=doc.pagesize;c.setFillColor(green);c.rect(40,h-29,w-80,2,fill=1,stroke=0)
    c.setFont('Chinese',8);c.setFillColor(HexColor('#6c7b70'));c.drawString(42,h-22,'LEXMOUNT 实践作品 | 企业官网实习岗位聚合平台')
    c.drawString(42,25,'材料版本 2026-10-28');c.drawRightString(w-42,25,str(doc.page))

doc=SimpleDocTemplate(str(out/'REPORT.pdf'),pagesize=(595.28,841.89),rightMargin=48,leftMargin=48,topMargin=49,bottomMargin=48,title='企业官网实习岗位聚合平台 - Lexmount活动作品说明',author='实习岗位雷达')
doc.build(story,onFirstPage=chrome,onLaterPages=chrome)
print(out/'REPORT.pdf')
