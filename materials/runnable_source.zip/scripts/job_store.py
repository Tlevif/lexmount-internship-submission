"""Append-only, company-neutral storage for collected job records."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

from app.core import fingerprint


def existing_fingerprints(path: Path) -> set[str]:
    seen: set[str] = set()
    if not path.exists():
        return seen
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                seen.add(fingerprint(json.loads(line)))
            except (ValueError, KeyError) as exc:
                raise ValueError(f"Invalid JSONL record at {path}:{line_number}") from exc
    return seen


def append_unique(path: Path, jobs: list[dict], seen: set[str]) -> int:
    """Append complete JSONL records once; fsync before checkpointing a page."""
    path.parent.mkdir(parents=True, exist_ok=True)
    new_records: list[tuple[str, dict]] = []
    for job in jobs:
        key = fingerprint(job)
        if key not in seen:
            new_records.append((key, job))
            seen.add(key)
    if not new_records:
        return 0
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        for _, job in new_records:
            stream.write(json.dumps(job, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    return len(new_records)


def read_progress(path: Path) -> dict:
    if not path.exists():
        return {"sources": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("sources"), dict):
        raise ValueError(f"Invalid progress file: {path}")
    return value


def save_progress(path: Path, progress: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(progress, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def mark_page(progress: dict, company: str, page: int, reported_total: int,
              raw_count: int, eligible_count: int, review_count: int) -> None:
    source = progress.setdefault("sources", {}).setdefault(company, {})
    source.update(last_completed_page=page, reported_total=reported_total,
                  last_raw_count=raw_count, last_eligible_count=eligible_count,
                  last_review_count=review_count,
                  updated_at_utc=datetime.now(timezone.utc).isoformat())
