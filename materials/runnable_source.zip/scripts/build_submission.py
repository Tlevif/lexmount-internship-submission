"""Package the reviewed computer-science snapshot and verifiable source evidence."""
from pathlib import Path
from datetime import datetime,timezone
import json,csv,hashlib,shutil,zipfile,sys,collections
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.core import normalize_job,fingerprint
from app.main import stats
from scripts.submission_ui import page,CSS,JS
OUT=ROOT/'submission/20261027';DIST=ROOT.parent/'submission-public'
URL='https://lexmount-internship-evidence-20261027.cherrydune65.chatgpt.site'
E=ROOT/'evidence/rebuild20261027'
def write(p,t):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t,encoding='utf-8')
def dump(p,v):write(p,json.dumps(v,ensure_ascii=False,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 OUT.mkdir(parents=True,exist_ok=True);DIST.mkdir(exist_ok=True)
 jobs=[normalize_job(json.loads(x)) for x in (ROOT/'data/jobs.jsonl').read_text('utf-8').split('\n') if x]
 rebuild=json.loads((E/'SUMMARY.json').read_text('utf-8'));N=len(jobs);C=len(set(j['company_name'] for j in jobs))
 assert N==rebuild['retained_jobs']==len(set(fingerprint(j) for j in jobs))
 assert all(j.get('responsibilities') and j.get('requirements') and j['classification']['keep'] for j in jobs)
 fields=['company_name','title','category','cities','recruitment_type','source_job_id','detail_url','source_url','company_website','career_url','responsibilities','requirements','published_at','collection_method','classification']
 clean=[];evidencefiles=set()
 for j in jobs:
  row={k:j.get(k) for k in fields};raw=j.get('raw_payload') or {};row['source_note']=raw.get('source_label_note')
  row['detail_sources']=[]
  for source in raw.get('detail_sources',[]):
   item=dict(source);p=item.get('evidence_file','')
   if p.startswith('evidence/rebuild20261027/') and not p.endswith('working_jobs.jsonl'):
    item['evidence_file']=p.replace('evidence/rebuild20261027/','evidence/full-rebuild/');evidencefiles.add(p)
   elif p.startswith('evidence/enrichment/20261027/'):
    item['evidence_file']=p.replace('evidence/enrichment/20261027/','evidence/detail-enrichment/')
   else:item.pop('evidence_file',None)
   row['detail_sources'].append(item)
  clean.append(row)
 dump(OUT/'results/jobs.json',clean);write(OUT/'results/jobs.jsonl',''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in clean))
 companies=json.loads((ROOT/'data/companies.json').read_text('utf-8'));dump(OUT/'results/companies.json',companies)
 with (OUT/'results/jobs.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['企业','岗位','技术分类','技术栈','城市','职责','任职要求','官网来源'])
  for j in clean:w.writerow([j['company_name'],j['title'],j['category'],'、'.join(j['classification']['skills']),'、'.join(j['cities']),j['responsibilities'],j['requirements'],j['detail_url']])
 # Preserve selected original runs and capture evidence referenced by retained records.
 picked=['evidence/discovery/baichuan-ats-domreuse.json','evidence/collector/baichuan_run.json','evidence/collector/tencent_run.json','evidence/collector/tencent_pagination_capture.json','evidence/collector/baidu_run.json','evidence/collector/kuaishou_run.json','evidence/collector/moka_run.json','evidence/live_api_collection.json','evidence/live_api_collection_initial_failure.json']
 copied=[]
 for name in picked:
  p=ROOT/name
  if p.exists():shutil.copy2(p,OUT/'evidence'/p.name);copied.append(p.name)
 for name in evidencefiles:
  p=ROOT/name;target=OUT/name.replace('evidence/rebuild20261027/','evidence/full-rebuild/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 for name in ['SUMMARY.json','classification_audit.json']:
  shutil.copy2(E/name,OUT/'evidence'/('REBUILD_'+name))
 shutil.copytree(ROOT/'evidence/enrichment/20261027',OUT/'evidence/detail-enrichment',dirs_exist_ok=True)
 summary={'packaged_at_utc':datetime.now(timezone.utc).isoformat(),'jobs':N,'unique_fingerprints':N,'companies_with_jobs':C,'company_catalog':len(companies),'by_company':dict(collections.Counter(j['company_name'] for j in jobs)),'by_category':rebuild['by_category'],'source_jobs_sha256':sha(ROOT/'data/jobs.jsonl'),'tests':'71 passed, 3 warnings','full_rebuild':rebuild,'collection_period':'2026-10-22至23日批量采集；2026-10-27全库详情补采与重新分类','cost':'未保存完整账单，未申报总费用或节省比例'}
 dump(OUT/'SUMMARY.json',summary);api=stats();assert api['jobs']==N and api['active_employers']==C;dump(OUT/'api_stats.json',api)
 shutil.copy2(ROOT/'tmp/rebuild-tests.txt',OUT/'test_results.txt')
 report=f'''# 计算机技术实习岗位聚合平台

Lexmount Real Task Challenge 作品说明 | 更新：2026-10-27

## 1. 解决什么问题

企业实习招聘分散在不同官网，动态页面、筛选和分页方式各异，逐站查找和比较耗时。本作品聚合北京、上海、广州、深圳、杭州的企业官网实习信息，统一展示计算机技术方向、岗位职责、任职要求、技术栈与来源链接。

## 2. 云平台参与了什么

Lexmount WebFetch 用于公开招聘入口发现、网页正文提取及 DOM 复用；Lexmount Cloud Browser 用于动态列表、分页、详情页和岗位方向选择。百川证据保留 DOM ID 896894、请求 ID 7e714c3c-c5f8-4232-b4cc-ac37f11377af，云浏览器截图展示6条日常实习。腾讯分页记录保留重复卡片的核验过程。

本次对全库检查缺失详情，复读官方网页及官方公开岗位接口。字节与飞书招聘接口用于读取具体岗位职责和要求；腾讯、阿里、小红书通过 WebFetch 和动态页面读取；百度通过官方列表接口逐页匹配原编号；蚂蚁、Moka 与华为等通过云浏览器核验。华为须选择具体岗位方向后才显示详情，综合岗位仅展示其中已核验的计算机技术方向。

Python 完成字段拆分、稳定标识去重、分类、JSONL 与 SQLite 同步；FastAPI 和网页提供检索、详情与 CSV 导出。人工确定目标和筛选标准，Codex 协助实现采集适配、核对边界岗位、检查原文与更新材料。线上演示使用已保存结果。

## 3. 已完成结果与统计依据

本次处理旧库5,213条记录，补齐{rebuild['fields_filled']['responsibilities']:,}条职责和{rebuild['fields_filled']['requirements']:,}条任职要求，共{rebuild['jobs_filled']:,}条记录补齐至少一个缺失字段。上述补采统计覆盖筛选前全库，包含之后移除的非技术岗位。

重新分类和筛选后，主库保留 **{N:,}条计算机技术实习岗位，来自{C}家企业，分为15个技术类别**。主库职责缺失0条、任职要求缺失0条。移除{rebuild['removed_non_cs_or_umbrella']:,}条不满足计算机技术准入条件或属于综合招聘入口的记录；另有{rebuild['unverified_detail_jobs']}条详情仍无法完整核验，单独归档，不进入演示。企业入口目录89家，有岗位企业数为筛选后的{C}家。

依据：results/jobs.jsonl、SUMMARY.json、api_stats.json、evidence/REBUILD_SUMMARY.json 和 evidence/REBUILD_classification_audit.json。逐条审计记录旧分类、新分类、处理结果、原因、技术依据和官网链接。变更前完整 JSONL 与 SQLite 备份保留在项目 data/archive/20261027-before-rebuild/。

旧分类已取消。当前分类依次核对岗位名称、实际技术任务与要求，旧部门标签不参与判断。营销团队中的后端开发、需要 Shader 编程的技术美术等按实际技术方向保留；法务、客服、纯策划、视觉设计、纯营销、一般业务分析以及仅人工标注或使用办公/AI工具的岗位移除。产品或运营名称的岗位只有在承担实际工程开发且明确要求编程能力时才保留。详情页展示识别到的技术栈与分类依据。

## 4. 发现的问题与验证结果

- 详情漏采：旧页面提示把“未提取”误写成“原站未提供”。本次重新读取缺失字段，处理双语标题、重复小标题、内嵌栏目和动态加载；未取得内容的记录独立归档。
- 栏目写错：Kimi 推理岗把 Python、C++、CUDA 要求标作岗位职责。按实际原文拆分，并保留来源备注。DeepSeek 旧详情提示迁移，沿官网新链接只提取对应研发方向。
- 分类污染：部门介绍、业务名称及宽泛关键词会把技术岗分到业务类别，也会把业务岗误判成技术。新规则从实际职责中剔除团队介绍，并检查编程及计算机要求；AI工具使用和加分项不单独构成准入依据。
- 动态页面与分页：WebFetch 可能只返回页面壳，云浏览器补足；腾讯重复页用稳定ID去重。历史采集的页面数与当前保留数分开记录。
- 数据装载：JSONL 只按 LF 分行，避免岗位正文中的 Unicode 分隔符破坏记录。当前软件测试 **71项通过**，3条依赖弃用提示；新增案例覆盖旧标签忽略、营销团队后端、技术美术、非技术移除和中英文技术词识别。

历史双企业成功任务于2026-10-22 06:18:36至06:19:07 UTC运行，耗时31秒，处理11条，新增6条、更新5条、错误0，依据 evidence/live_api_collection.json。该耗时对应这一任务；失败尝试作为反馈证据保留。未保存完整工时和账单，未申报总成本或节省比例。

## 5. 如何演示和核验

材料入口：{URL}/

页面无需登录，可在其他主机查看作品说明、按企业/城市/技术方向检索{N:,}条岗位、打开官网链接、阅读职责和要求，并下载完整提交包。备用入口：https://tlevif.github.io/lexmount-internship-submission/ 。目录核验状态沿用历史入口调查；岗位是否仍开放以官网为准。

建议先查看百川云端截图与采集记录，再抽查岗位详情及官网，最后对照 SUMMARY.json 与分类审计清单。执行 python verify_package.py 可核对包内文件 SHA256、记录数、稳定标识唯一性以及职责与要求完整性。

## 6. 文件用途和运行方法

- results/jobs.jsonl、jobs.json、jobs.csv：筛选后的完整技术岗位结果；CSV含职责、要求、技术栈和官网链接。
- evidence/REBUILD_SUMMARY.json、REBUILD_classification_audit.json：本次全库补采、重新分类及移除记录。
- evidence/full-rebuild/：保留岗位引用的官方接口响应和云端页面原文；evidence/detail-enrichment/为此前待审核补采的历史证据。
- cloud_recheck_20261027.json 与 screenshots/：真实云端运行材料和结果界面。
- workflow.json：说明性执行流程，用于理解各步骤用途。
- runnable_source.zip：最小可运行源码与当前技术岗位数据。解压后按 RUN.md 安装依赖，启动只读 FastAPI；只读演示无需云账号。重新采集需要安装并登录 Lexmount CLI，并继续核验详情。

主要采集期为2026-10-22至23日，2026-10-27补充详情、复核、分类与材料更新。数据库装载时间不作为原站发布时间。原站没有公布发布时间时保持为空。
'''
 write(OUT/'REPORT.md',report)
 form=f'''# 活动表单填写文案

## 作品名称
计算机技术实习岗位聚合平台：用Lexmount云端采集实现企业官网岗位检索

## 想解决什么问题
企业实习信息分散在不同官网，动态渲染和分页方式各异，逐站查找和比较耗时。本作品聚合北京、上海、广州、深圳、杭州的计算机技术实习信息，统一展示分类、职责、要求、技术栈与官方来源。

## 怎么做的，云平台参与了什么
使用Lexmount WebFetch发现招聘入口、提取网页并复用DOM；使用Lexmount Cloud Browser操作动态列表、分页、详情与华为岗位方向。结合官方公开岗位接口补齐字段，Python完成拆分、去重、内容分类和JSONL/SQLite入库，FastAPI及网页提供检索、详情与CSV导出。人工确定目标和标准，Codex协助实现适配、复核原文与边界岗位。材料包含云会话、请求、分页记录、原文和截图。

## 结果与发现
检查旧库5,213条，补齐{rebuild['fields_filled']['responsibilities']}条职责、{rebuild['fields_filled']['requirements']}条要求，共{rebuild['jobs_filled']}条补齐缺失字段。取消旧分类后，按名称、职责和计算机要求重分，保留{N}条、{C}家企业、15个技术类别，主库两项字段缺失均为0；移除{rebuild['removed_non_cs_or_umbrella']}条不满足准入条件或属于综合入口的记录，另{rebuild['unverified_detail_jobs']}条详情未完整核验单独归档。依据为SUMMARY.json、完整结果及逐条分类审计。发现漏采、错误栏目、动态页面壳、重复分页和部门标签污染，已通过官网复读、字段拆分、稳定ID和内容分类验证处理。71项测试通过。历史双企业任务31秒处理11条（新增6、更新5、错误0），仅对应此任务；未保存完整账单和工时。主要采集为10月22至23日，10月27日补采复核。

## 作品演示或运行材料链接
{URL}/

## 材料访问说明
公开只读，无需账号和提取码，可在其他主机访问。作品说明、云端截图、完整技术岗位结果、分类审计、证据、PDF及ZIP集中在同一链接。备用入口：https://tlevif.github.io/lexmount-internship-submission/ 。
'''
 write(OUT/'FORM_TEXT.md',form)
 write(OUT/'README.md',f'# 活动提交材料\n\n请先阅读REPORT.pdf或REPORT.md；FORM_TEXT.md可用于活动表单。\n\n当前结果为{N}条计算机技术岗位，{C}家有岗位企业。职责和要求缺失均为0。详细补采、分类与移除依据见SUMMARY.json及evidence/REBUILD_classification_audit.json。\n\n材料入口：{URL}/\n\n运行 python verify_package.py 校验本包。源码运行说明位于runnable_source.zip内的RUN.md。\n')
 dump(OUT/'workflow.json',{'format':'descriptive-process-manifest-v2','importable_to_lexmount':False,'steps':['WebFetch发现与正文读取','Cloud Browser动态列表、分页与方向选择','官方详情补采与字段拆分','按职责和要求分类并剔除非计算机岗位','JSONL/SQLite同步、界面演示与证据打包']})
 verifier='''from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
m=json.loads((p/'MANIFEST.json').read_text('utf-8'))
for n,d in m['files'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==d,n
rows=[json.loads(x) for x in (p/'results/jobs.jsonl').read_text('utf-8').split('\\n') if x]
s=json.loads((p/'SUMMARY.json').read_text('utf-8'))
assert len(rows)==s['jobs']==len({(j['company_name'],j['source_job_id'] or j['detail_url']) for j in rows})
assert all(j['responsibilities'] and j['requirements'] and j['classification']['keep'] for j in rows)
assert not any(j['category'] in ['待审核','待核验','非计算机岗位'] for j in rows)
print(f'OK: {len(m["files"])} files, {len(rows)} complete technical jobs.')
'''
 write(OUT/'verify_package.py',verifier)
 with zipfile.ZipFile(OUT/'runnable_source.zip','w',zipfile.ZIP_DEFLATED) as z:
  for folder in ['app','frontend','collector','configs','discovery','scripts','tests']:
   for p in (ROOT/folder).rglob('*'):
    if p.is_file() and p.suffix in {'.py','.js','.css','.html','.json','.ps1'} and '__pycache__' not in p.parts:z.write(p,p.relative_to(ROOT).as_posix())
  z.write(ROOT/'requirements.txt','requirements.txt')
  for n in ['jobs.jsonl','companies.json']:z.write(ROOT/'data'/n,'data/'+n)
  z.writestr('RUN.md','# 本地只读演示\n\nPython 3.11+。执行：\n\n```powershell\npython -m pip install -r requirements.txt\n$env:DEMO_READ_ONLY="1"\npython -m uvicorn app.main:app --host 127.0.0.1 --port 8000\n```\n\n浏览 http://127.0.0.1:8000/ 。首次启动装载当前技术岗位。只读演示无需云凭据；重新采集需安装并登录Lexmount CLI、核验详情和分类。\n')
 html=page(report,summary,copied)
 html=html.replace('5,213',f'{N:,}').replace('<b>35</b>',f'<b>{C}</b>').replace('<b>69</b>','<b>71</b>').replace('69项软件测试记录','71项软件测试记录')
 html=html.replace('完整'+f'{N:,}'+'条保留结果；包含技术、业务与待审核方向。',f'完整{N:,}条计算机技术岗位，15个类别；职责与任职要求均已核验。')
 html=html.replace('materials/evidence/detail-enrichment/SUMMARY.json">待审核岗位详情补采与状态','materials/evidence/REBUILD_SUMMARY.json">全库补采、重新分类与移除统计')
 html=html.replace('② 本机FastAPI运行总览。最近确认时间为演示数据库装载时间，采集时间以原始证据为准。','② 更新后的计算机技术岗位结果演示。').replace('③ 百川结果筛选与详情；可对照云端列表的标题、城市和来源。','③ 更新后的岗位筛选与详情，可核对职责、要求及技术栈。')
 html=html.replace('本次处理旧库'+f'{N:,}'+'条记录','本次处理旧库5,213条记录')
 html=html.replace('demo.js?v=20261027-details','demo.js?v=20261027-cs-v3')
 write(DIST/'index.html',html);write(DIST/'site.css',CSS.replace('#f6f7f2ed','#f6f7f2'))
 js=JS.replace('20261027-details','20261027-cs-v3').replace('百川复核与待审核详情补采于10月27日','全库详情补采与重新分类于10月27日')
 js=js.replace('<h3>岗位职责</h3>','<h3>技术依据</h3><p>${esc((j.classification?.skills||[]).join(" · "))}</p><p class="note">${esc(j.classification?.reason||"")}</p><h3>岗位职责</h3>')
 js=js.replace('${j.detail_enrichment?', '${j.source_note?`<p class="note">${esc(j.source_note)}</p>`:""}${j.detail_sources?.length?`<p class="note">补采依据：${j.detail_sources.map(x=>x.evidence_file?`<a href="materials/${esc(x.evidence_file)}" target="_blank">${esc(x.method)}</a>`:esc(x.method)).join(" · ")}</p>`:""}${j.detail_enrichment?')
 js=js.replace("['企业','岗位','方向','城市','来源']","['企业','岗位','方向','技术栈','城市','职责','任职要求','来源']").replace("j.category,j.cities.join('、'),j.detail_url]","j.category,(j.classification?.skills||[]).join('、'),j.cities.join('、'),j.responsibilities,j.requirements,j.detail_url]")
 js=js.replace("$('#filters').reset()","HTMLFormElement.prototype.reset.call($('#filters'))")
 js=js.replace("fetch('materials/results/jobs.json?v=20261027-cs-v3')","fetch('materials/results/jobs.json?v=20261027-cs-v3',{cache:'no-store'})")
 write(DIST/'demo.js',js)
 print(json.dumps({'jobs':N,'employers':C,'referenced_evidence_files':len(evidencefiles)},ensure_ascii=False))
def finalize():
 files={p.relative_to(OUT).as_posix():sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='MANIFEST.json'};dump(OUT/'MANIFEST.json',{'algorithm':'SHA256','files':files})
 archive=ROOT/'submission-20261027.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(OUT.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(OUT).as_posix())
 shutil.copytree(OUT,DIST/'materials',dirs_exist_ok=True);shutil.copy2(archive,DIST/'submission.zip');shutil.copy2(archive,ROOT/'submission.zip')
 print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size}))
if __name__=='__main__':finalize() if '--finalize' in sys.argv else main()
