"""Run one verified employer through the API task path and save a real result."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app

ROOT = Path(__file__).resolve().parents[1]

with TestClient(app) as client:
    names = ["字节跳动", "百川智能"]
    start = client.post("/api/collect", json={"companies": names})
    start.raise_for_status()
    task_id = start.json()["id"]
    deadline = time.monotonic() + 150
    while time.monotonic() < deadline:
        task = client.get(f"/api/tasks/{task_id}").json()
        if task["status"] != "running":
            break
        time.sleep(2)
    else:
        raise TimeoutError(f"Collection task still running: {task_id}")
    company_counts = {}
    for name in names:
        response = client.get("/api/jobs", params={"company": name, "recruitment_type": "实习"})
        response.raise_for_status()
        company_counts[name] = response.json()["total"]
    report = {"observed_at_utc": datetime.now(timezone.utc).isoformat(),
              "task": task, "company_counts": company_counts,
              "query_total": client.get("/api/jobs", params={"recruitment_type": "实习"}).json()["total"]}

out = ROOT / "evidence" / "live_api_collection.json"
out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(report, ensure_ascii=False))
