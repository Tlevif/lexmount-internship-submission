"""Reclassify clear business roles already stored in the shared catalog."""
from __future__ import annotations

import json
import shutil
import sqlite3

from app.core import classify, classify_business_role, fingerprint
from app.db import connect, init_db
from scripts.collect_jobs import MAIN, REVIEW


def main() -> None:
    backup_dir = MAIN.parent.parent / "evidence" / "curation"
    backup_dir.mkdir(parents=True, exist_ok=True)
    main_backup = backup_dir / "jobs_before_business_reclassification_20261023.jsonl"
    review_backup = backup_dir / "review_candidates_before_business_reclassification_20261023.jsonl"
    if MAIN.exists() and not main_backup.exists():
        shutil.copy2(MAIN, main_backup)
    if REVIEW.exists() and not review_backup.exists():
        shutil.copy2(REVIEW, review_backup)

    init_db()
    database_backup = backup_dir / "jobs_before_business_reclassification_20261023.sqlite3"
    if not database_backup.exists():
        with connect() as source, sqlite3.connect(database_backup) as target:
            source.backup(target)

    changed = 0
    promoted = 0
    counts: dict[str, int] = {}
    rewritten: list[dict] = []
    seen: set[str] = set()
    if MAIN.exists():
        for line in MAIN.read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            row = json.loads(line)
            decision = classify_business_role(row)
            if decision or row.get("category") == "待审核":
                decision = decision or classify(row)
            if decision and decision[0] != "待审核":
                row["category"], row["category_evidence"] = decision
                counts[decision[0]] = counts.get(decision[0], 0) + 1
                changed += 1
            seen.add(fingerprint(row))
            rewritten.append(row)

    remaining_review: list[dict] = []
    if REVIEW.exists():
        for line in REVIEW.read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            row = json.loads(line)
            decision = classify_business_role(row)
            if decision:
                row["category"], row["category_evidence"] = decision
                identity = fingerprint(row)
                if identity not in seen:
                    rewritten.append(row)
                    seen.add(identity)
                promoted += 1
                counts[decision[0]] = counts.get(decision[0], 0) + 1
            else:
                remaining_review.append(row)

    if MAIN.exists() or rewritten:
        tmp = MAIN.with_name(MAIN.name + ".tmp")
        tmp.write_text("".join(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n" for row in rewritten), encoding="utf-8")
        tmp.replace(MAIN)
    if REVIEW.exists():
        tmp = REVIEW.with_name(REVIEW.name + ".tmp")
        tmp.write_text("".join(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n" for row in remaining_review), encoding="utf-8")
        tmp.replace(REVIEW)

    db_changed = 0
    with connect() as con:
        rows = con.execute("SELECT fingerprint,title,category,raw_category,responsibilities,status FROM jobs").fetchall()
        for row in rows:
            decision = classify_business_role(dict(row))
            if not decision and row["category"] == "待审核":
                decision = classify(dict(row))
            if not decision or decision[0] == "待审核":
                continue
            category, evidence = decision
            con.execute(
                "UPDATE jobs SET category=?,category_evidence=?,status='active' WHERE fingerprint=?",
                (category, evidence, row["fingerprint"]),
            )
            db_changed += 1

    print(json.dumps({"jsonl_reclassified": changed, "promoted_from_review": promoted,
                      "database_reclassified": db_changed,
                      "categories": counts}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
