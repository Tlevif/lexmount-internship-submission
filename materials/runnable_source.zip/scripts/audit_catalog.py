"""Verify shared JSONL integrity and write a concise crawl manifest."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from app.core import fingerprint
from app.job_triage import triage_job
from scripts.collect_jobs import MAIN, PROGRESS, REVIEW, ROOT


def rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    # JSONL records are separated by LF. `str.splitlines()` also splits U+2028
    # and U+2029, which can legitimately occur inside job descriptions.
    return [json.loads(line) for line in path.read_text(encoding="utf-8").split("\n") if line.strip()]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else ""


def main() -> None:
    jobs, review = rows(MAIN), rows(REVIEW)
    ids = [fingerprint(row) for row in jobs]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate job identity in shared result file")
    progress = json.loads(PROGRESS.read_text(encoding="utf-8"))
    source = progress["sources"]["字节跳动"]
    last_page = source["last_completed_page"]
    byte_rows = [row for row in jobs + review if row.get("company_name") == "字节跳动"]
    observed_pages = {row.get("raw_payload", {}).get("page") for row in byte_rows}
    missing_pages = [page for page in range(1, last_page + 1) if page not in observed_pages]
    byte_ids = {row["source_job_id"] for row in byte_rows}
    main_byte_ids = {row["source_job_id"] for row in jobs if row.get("company_name") == "字节跳动"}
    review_only = [row for row in review if row.get("company_name") == "字节跳动"
                   and row["source_job_id"] not in main_byte_ids]
    review_decisions = dict(Counter(triage_job(row)[0] for row in review_only))
    counts = dict(Counter(row["company_name"] for row in jobs))
    review_counts = dict(Counter(row["company_name"] for row in review))
    report = {
        "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "output": str(MAIN.relative_to(ROOT)),
        "output_rows": len(jobs),
        "company_counts": counts,
        "review_company_counts": review_counts,
        "source_progress": progress["sources"],
        "output_sha256": digest(MAIN),
        "review_output": str(REVIEW.relative_to(ROOT)),
        "review_rows": len(review),
        "review_sha256": digest(REVIEW),
        "byte_last_completed_page": last_page,
        "byte_site_total_at_last_page": source["reported_total"],
        "byte_unique_ids_across_output_and_review": len(byte_ids),
        "byte_main_rows": len(main_byte_ids),
        "byte_review_only_decisions": review_decisions,
        "byte_outside_city_or_internship": source["reported_total"] - len(byte_ids),
        "missing_pages_with_no_retained_candidate": missing_pages,
        "note": "The site total changed during collection; classification is rule-based. Any remaining review candidates are awaiting human confirmation.",
    }
    out = ROOT / "data" / "collection_manifest.json"
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
