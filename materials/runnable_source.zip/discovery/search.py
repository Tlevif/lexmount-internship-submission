"""Budgeted public-web discovery through the project's Lexmount WebFetch CLI.

The CLI has no search subcommand. This module renders a public search-results
page with ``dump-dom`` and treats extracted links as unverified leads only.
It never writes to the formal company directory.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import time
from dataclasses import dataclass, field
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import quote_plus, urlparse

from bs4 import BeautifulSoup

from discovery.discover import DEFAULT_CLI, ROOT

DEFAULT_CITIES = ["北京", "上海", "广州", "深圳", "杭州", "南京", "苏州", "成都", "武汉"]
DEFAULT_INDUSTRIES = {
    "人工智能大模型": ["人工智能", "大模型", "AI Agent"],
    "软件与SaaS": ["软件", "SaaS", "企业服务"],
    "云计算基础设施": ["云计算", "云原生", "基础设施"],
    "网络安全": ["网络安全", "数据安全"],
    "数据服务": ["数据服务", "数据智能"],
    "游戏开发": ["游戏研发", "游戏开发"],
    "智能硬件": ["智能硬件", "机器人"],
    "计算机技术服务": ["计算机技术", "技术服务"],
}
DEFAULT_SIGNALS = {
    "ats": ["飞书招聘", "Moka招聘", "北森招聘", "企业招聘官网"],
    "directories": ["科技企业名录", "产业园入驻企业", "软件企业目录", "创业公司名录"],
    "ecosystem": ["合作伙伴", "生态企业", "开发者平台企业"],
}
DEFAULT_EXPANSION_TERMS = ["AI Agent", "具身智能", "智能硬件", "工业软件", "低代码", "数据智能"]
SEARCH_HOSTS = {"bing.com", "google.com", "baidu.com", "so.com", "sogou.com"}
SEARCH_RESULT_HOSTS = SEARCH_HOSTS | {
    "www.bing.com", "cn.bing.com", "www.google.com", "www.baidu.com",
    "www.so.com", "www.sogou.com",
}
SKIP_HOSTS = SEARCH_HOSTS | {
    "wikipedia.org", "zhihu.com", "baike.baidu.com", "weibo.com", "xiaohongshu.com",
    "douyin.com", "bilibili.com", "www.linkedin.com", "linkedin.com",
}
CAREER_SIGNALS = ("career", "jobs", "job", "join", "recruit", "hire", "campus", "zhaopin", "招聘", "职位", "岗位", "加入")
TECH_SIGNALS = ("科技", "技术", "软件", "人工智能", "大模型", "云计算", "网络安全", "数据", "游戏", "智能", "机器人", "芯片", "互联网", "研发", "飞书", "moka", "agi", "llm")
COMPANY_MARKERS = ("公司", "集团", "有限公司", "股份", "科技", "技术", "软件", "网络", "智能", "数科", "数据", "云", "机器人", "游戏")
EXCLUDED_TEXT = (
    "人民政府门户", "政府门户", "政府网站", "文化和旅游局", "文旅局", "旅游局",
    "旅游攻略", "旅游景点", "必去的景点", "景区", "百度百科", "百科全书",
    "大学", "学院", "学校", "研究生院", "高校招聘",
)


@dataclass
class SearchConfig:
    cities: list[str] = field(default_factory=lambda: list(DEFAULT_CITIES))
    industries: dict[str, list[str]] = field(default_factory=lambda: dict(DEFAULT_INDUSTRIES))
    signals: dict[str, list[str]] = field(default_factory=lambda: dict(DEFAULT_SIGNALS))
    max_queries: int = 24
    max_results: int = 120
    depth: int = 2
    pages_per_query: int = 1
    delay_seconds: float = 1.5
    timeout_ms: int = 60000
    search_url_template: str = "https://www.bing.com/search?q={query}&first={offset}"
    prior_channel_scores: dict[str, float] = field(default_factory=dict)
    expansion_terms: list[str] = field(default_factory=lambda: list(DEFAULT_EXPANSION_TERMS))

    @classmethod
    def from_dict(cls, values: dict) -> "SearchConfig":
        values = dict(values)
        if "cities" not in values and "target_cities" in values:
            values["cities"] = values["target_cities"]
        if "max_queries" not in values and "search_budget" in values:
            values["max_queries"] = values["search_budget"]
        if "max_results" not in values and "candidate_limit" in values:
            values["max_results"] = values["candidate_limit"]
        if isinstance(values.get("industries"), list):
            values["industries"] = {str(item): [str(item)] for item in values["industries"] if str(item).strip()}
        allowed = cls.__dataclass_fields__.keys()
        config = cls(**{key: value for key, value in values.items() if key in allowed})
        if not config.cities or not config.industries or not config.signals:
            raise ValueError("cities, industries, and signals must be non-empty")
        if config.max_queries < 1 or config.max_results < 1 or config.depth < 1 or config.pages_per_query < 1:
            raise ValueError("query/result/depth/page budgets must be positive")
        if config.delay_seconds < 0:
            raise ValueError("delay_seconds must be non-negative")
        if "{query}" not in config.search_url_template:
            raise ValueError("search_url_template must contain {query}")
        return config


class SearchLinkParser(HTMLParser):
    """Collect link text and a small surrounding snippet from rendered HTML."""

    def __init__(self):
        super().__init__()
        self.links: list[dict] = []
        self._current: dict | None = None
        self._text_stack: list[str] = []
        self.all_text: list[str] = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {"h2", "h3", "p", "li", "article", "div"}:
            self._text_stack.append("")
        if tag == "a" and attrs.get("href"):
            self._current = {"url": attrs["href"], "title": "", "snippet": ""}

    def handle_data(self, data):
        text = re.sub(r"\s+", " ", data).strip()
        if not text:
            return
        self.all_text.append(text)
        if self._current is not None:
            self._current["title"] = (self._current["title"] + " " + text).strip()
        for index in range(len(self._text_stack)):
            self._text_stack[index] = (self._text_stack[index] + " " + text).strip()

    def handle_endtag(self, tag):
        if tag == "a" and self._current is not None:
            self._current["snippet"] = " ".join(self._text_stack[-2:])[:700]
            self.links.append(self._current)
            self._current = None
        if tag in {"h2", "h3", "p", "li", "article", "div"} and self._text_stack:
            self._text_stack.pop()


def build_queries(config: SearchConfig, round_index: int = 0, discovered_terms: list[str] | None = None) -> list[dict]:
    """Build city × industry × channel queries; prioritize prior high-yield channels."""
    channels = sorted(
        config.signals.items(),
        key=lambda item: config.prior_channel_scores.get(item[0], 0.5),
        reverse=True,
    )
    queries: list[dict] = []
    for city in config.cities:
        for industry, terms in config.industries.items():
            terms_for_round = list(terms)
            if round_index > 0 and discovered_terms:
                terms_for_round = list(dict.fromkeys(terms_for_round + discovered_terms[: config.depth]))
            for channel, signals in channels:
                term = terms_for_round[(round_index + len(queries)) % len(terms_for_round)]
                signal = signals[(round_index + len(queries)) % len(signals)]
                query = (
                    f'{city} {term} 科技公司 {signal} 招聘 实习 '
                    '-site:gov.cn -site:edu.cn -site:ac.cn -政府门户 -旅游攻略 -景点 -学校 -大学 -百科'
                )
                queries.append({"query": query, "city": city, "industry": industry, "channel": channel})
    return queries


def _balanced_selection(plan: list[dict], limit: int) -> list[dict]:
    """Select a query batch that covers cities, industries and channels early."""
    remaining = list(plan)
    selected: list[dict] = []
    cities: set[str] = set()
    industries: set[str] = set()
    channels: set[str] = set()
    while remaining and len(selected) < limit:
        best_index = max(
            range(len(remaining)),
            key=lambda index: (
                int(remaining[index]["city"] not in cities)
                + int(remaining[index]["industry"] not in industries)
                + int(remaining[index]["channel"] not in channels),
                -index,
            ),
        )
        item = remaining.pop(best_index)
        selected.append(item)
        cities.add(item["city"])
        industries.add(item["industry"])
        channels.add(item["channel"])
    return selected


def _host(url: str) -> str:
    return (urlparse(url).hostname or "").lower().removeprefix("www.")


def _is_search_host(host: str) -> bool:
    return host in SEARCH_RESULT_HOSTS


def _excluded_reason(url: str, title: str, snippet: str) -> str | None:
    host = _host(url)
    lower = f"{title} {snippet} {url}".casefold()
    if host.endswith(".gov.cn") or host.endswith(".gov") or any(x in lower for x in EXCLUDED_TEXT[:3]):
        return "government_or_tourism_page"
    if any(x in lower for x in EXCLUDED_TEXT[3:10]):
        return "government_or_tourism_page"
    if host.endswith(".edu.cn") or host.endswith(".ac.cn") or any(x in lower for x in ("大学", "学院", "学校", "研究生院", "高校招聘")):
        return "education_page"
    if any(host == skip or host.endswith("." + skip) for skip in SKIP_HOSTS):
        return "generic_or_social_source"
    if any(x in lower for x in ("百度百科", "百科全书")):
        return "generic_or_social_source"
    return None


def _is_company_lead(title: str, url: str, snippet: str) -> bool:
    text = f"{title} {url} {snippet}".casefold()
    has_tech = any(signal.casefold() in text for signal in TECH_SIGNALS) or bool(re.search(r"\b(?:ai|saas|llm)\b", text))
    has_company_marker = any(marker.casefold() in text for marker in COMPANY_MARKERS)
    host = _host(url)
    is_ats = host.endswith(".jobs.feishu.cn") or host.endswith(".mokahr.com") or "beisen" in host
    has_recruiting = any(signal in text for signal in CAREER_SIGNALS) or is_ats
    # Search-result titles must identify an employer-like entity and connect it
    # to technology or recruitment. City pages and generic articles fail this.
    return (has_company_marker or is_ats) and has_tech and has_recruiting


def parse_search_page(html: str, search_page_url: str, *, limit: int = 20) -> tuple[list[dict], list[dict]]:
    """Parse only Bing's organic ``li.b_algo > h2 a`` results.

    Rejected cards remain as source evidence with a reason, but cannot become
    company candidates.
    """
    soup = BeautifulSoup(html or "", "html.parser")
    leads: list[dict] = []
    rejected: list[dict] = []
    seen = set()
    for card in soup.select("li.b_algo"):
        anchor = card.select_one("h2 a[href]")
        if not anchor:
            continue
        url = (anchor.get("href") or "").strip()
        title = re.sub(r"\s+", " ", anchor.get_text(" ", strip=True)).strip()
        parsed = urlparse(url)
        host = _host(url)
        if parsed.scheme not in {"http", "https"} or not host or _is_search_host(host):
            continue
        key = url.split("#", 1)[0].rstrip("/").lower()
        if key in seen:
            continue
        seen.add(key)
        full_text = re.sub(r"\s+", " ", card.get_text(" ", strip=True)).strip()
        snippet = full_text.replace(title, "", 1).strip(" |·—-:")[:700]
        reason = _excluded_reason(url, title, snippet)
        if reason is None and not _is_company_lead(title, url, snippet):
            reason = "insufficient_company_technology_or_recruiting_signals"
        item = {
            "title": title[:180], "url": url, "domain": host,
            "career_url": url if any(signal in (title + " " + url).lower() for signal in CAREER_SIGNALS) else None,
            "snippet": snippet, "search_page_url": search_page_url,
        }
        if reason:
            rejected.append({**item, "reason": reason})
        else:
            leads.append(item)
        if len(leads) + len(rejected) >= limit:
            break
    return leads, rejected


def extract_search_results(html: str, search_page_url: str, *, limit: int = 20) -> list[dict]:
    """Compatibility helper returning only high-confidence employer leads."""
    return parse_search_page(html, search_page_url, limit=limit)[0]


def _company_name(title: str) -> str:
    # Search-result titles are leads, not canonical legal names.
    title = re.split(r"[|｜—–-]", title, maxsplit=1)[0]
    title = re.sub(r"^(加入|欢迎加入|Join|Careers? at|Jobs? at)\s*", "", title, flags=re.IGNORECASE)
    title = re.sub(r"\s*(招聘信息|校园招聘|社会招聘|人才招聘|招聘|官方网站|官网|职位列表|Careers?)\s*$", "", title, flags=re.IGNORECASE)
    title = re.sub(r"^(北京|上海|广州|深圳|杭州|南京|苏州|成都|武汉)\s*", "", title)
    title = re.sub(r"\s+", " ", title).strip(" -|｜·")
    return title[:100]


def _dump_dom(cli: Path, url: str, timeout_ms: int) -> dict:
    if not cli.exists():
        raise FileNotFoundError(f"WebFetch CLI unavailable: {cli}")
    proc = subprocess.run(
        [str(cli), "dump-dom", "--url", url, "--format", "json", "--timeout-ms", str(timeout_ms)],
        capture_output=True, text=True, encoding="utf-8", timeout=timeout_ms / 1000 + 30, check=False,
    )
    if proc.returncode:
        raise RuntimeError(f"WebFetch dump-dom exited {proc.returncode}: {proc.stderr[:300]}")
    result = json.loads(proc.stdout)
    if result.get("error"):
        raise RuntimeError(str(result["error"]))
    return result


def _search_url(template: str, query: str, page: int) -> str:
    return template.format(query=quote_plus(query), page=page, offset=(page - 1) * 10)


def run_search(config: SearchConfig, *, cli: Path = DEFAULT_CLI, fetcher=None, sleep=time.sleep) -> dict:
    """Run a bounded, serial WebFetch search plan and return candidate evidence.

    ``fetcher`` is injectable only for deterministic tests. Production defaults
    to the skill-local WebFetch CLI and does not create a separate HTTP client.
    """
    fetch = fetcher or (lambda url: _dump_dom(cli, url, config.timeout_ms))
    candidates_by_url: dict[str, dict] = {}
    domain_first_channel: dict[str, str] = {}
    seen_domains: set[str] = set()
    channel_counts: dict[str, dict[str, int]] = {}
    query_log: list[dict] = []
    excluded_results: list[dict] = []
    discovered_terms: list[str] = []
    query_budget = config.max_queries
    result_budget = config.max_results
    queries_used = 0

    for round_index in range(config.depth):
        plan = build_queries(config, round_index, discovered_terms)
        rounds_left = config.depth - round_index
        round_budget = (query_budget - queries_used + rounds_left - 1) // rounds_left
        plan = _balanced_selection(plan, round_budget)
        for item in plan:
            if queries_used >= query_budget or result_budget <= 0:
                break
            queries_used += 1
            metrics = channel_counts.setdefault(item["channel"], {"results": 0, "new_domains": 0, "duplicate_domains": 0})
            for page in range(1, config.pages_per_query + 1):
                if result_budget <= 0:
                    break
                page_url = _search_url(config.search_url_template, item["query"], page)
                record = {**item, "page": page, "search_page_url": page_url, "status": "ok", "results": 0}
                try:
                    response = fetch(page_url)
                    html = response.get("html") or ""
                    observed, rejected = parse_search_page(html, response.get("final_url") or page_url, limit=result_budget)
                    result_count = len(observed) + len(rejected)
                    metrics["results"] += result_count
                    for raw in observed:
                        is_new_domain = raw["domain"] not in seen_domains
                        if is_new_domain:
                            seen_domains.add(raw["domain"])
                            domain_first_channel[raw["domain"]] = item["channel"]
                            metrics["new_domains"] += 1
                        else:
                            metrics["duplicate_domains"] += 1
                        key = raw["url"].split("#", 1)[0].rstrip("/").lower()
                        if key in candidates_by_url:
                            continue
                        name = _company_name(raw["title"])
                        if len(name) < 2:
                            continue
                        evidence = [{"url": raw["url"], "relation": "search_result"}]
                        candidate = {
                            "name": name,
                            "website": None,
                            "career_url": raw["career_url"],
                            "source_url": raw["url"],
                            "source": f'web_search:{item["channel"]}',
                            "verification_status": "candidate",
                            "industry_group": item["industry"],
                            "discovery_query": item["query"],
                            "search_page_url": page_url,
                            "result_title": raw["title"],
                            "result_snippet": raw["snippet"],
                            "evidence": evidence,
                        }
                        candidates_by_url[key] = candidate
                        for term in config.expansion_terms:
                            if term.lower() in (raw["title"] + " " + raw["snippet"]).lower() and term not in discovered_terms:
                                discovered_terms.append(term)
                    for rejected_item in rejected:
                        if len(excluded_results) < 250:
                            excluded_results.append({**rejected_item, "query": item["query"]})
                    record["results"] = result_count
                    record["company_leads"] = len(observed)
                    record["excluded_sources"] = len(rejected)
                    result_budget -= result_count
                    query_log.append(record)
                    if config.delay_seconds and (result_budget > 0):
                        sleep(config.delay_seconds)
                except Exception as exc:  # Preserve per-query failures and continue within budget.
                    record["status"] = "error"
                    record["error"] = str(exc)[:500]
                    query_log.append(record)
                    break
            if queries_used >= query_budget:
                break
        if queries_used >= query_budget or result_budget <= 0:
            break

    channel_scores = {}
    for channel, counts in channel_counts.items():
        total = counts["results"]
        # New domains improve the score; repeated domains lower it. 0.5 is a
        # neutral prior for channels not represented in prior runs.
        observed_score = (counts["new_domains"] / total) if total else config.prior_channel_scores.get(channel, 0.5)
        prior = config.prior_channel_scores.get(channel, 0.5)
        channel_scores[channel] = round(0.65 * observed_score + 0.35 * prior, 4)
    return {
        "status": "candidate_evidence_only",
        "limits": {
            "max_queries": config.max_queries, "max_results": config.max_results,
            "depth": config.depth, "pages_per_query": config.pages_per_query,
            "delay_seconds": config.delay_seconds,
        },
        "queries_executed": queries_used,
        "pages_fetched": len(query_log),
        "results_observed": sum(row["results"] for row in query_log),
        "candidates": list(candidates_by_url.values()),
        "excluded_results": excluded_results,
        "query_log": query_log,
        "domain_first_channel": domain_first_channel,
        "channel_metrics": channel_counts,
        "channel_scores": channel_scores,
        "expansion_terms": discovered_terms,
        "formal_directory_written": False,
    }


def main():
    parser = argparse.ArgumentParser(description="Bounded company discovery using Lexmount WebFetch")
    parser.add_argument("--config", type=Path, help="JSON search-budget and keyword configuration")
    parser.add_argument("--cli", type=Path, default=DEFAULT_CLI)
    parser.add_argument("--output", type=Path, default=ROOT / "discovery" / "search_run.json")
    args = parser.parse_args()
    values = json.loads(args.config.read_text(encoding="utf-8")) if args.config else {}
    result = run_search(SearchConfig.from_dict(values), cli=args.cli)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"], "queries": result["queries_executed"],
        "results": result["results_observed"], "candidates": len(result["candidates"]),
        "output": str(args.output), "formal_directory_written": False,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
