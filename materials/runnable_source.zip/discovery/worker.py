"""Serial worker for queued discovery tasks in the existing task table.

The worker records each handoff in the existing task event trail. Search results
enter the shared company directory only as pending candidates. Collection is
limited to exact-name matches of independently verified site configurations.
"""
from __future__ import annotations

import argparse
import json
import time
from datetime import datetime, timezone
from pathlib import Path

from app.companies import _directory_lock, upsert_companies
from app.db import connect, init_db
from app.tasks import (append_task_events, claim_discovery_task, finish_discovery_task,
                       get_discovery_strategy, list_tasks, requeue_discovery_task,
                       requeue_running_discovery_tasks, save_discovery_strategy)
from discovery.search import SearchConfig, run_search

ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = ROOT / "configs" / "sites"
RUN_DIR = ROOT / "evidence" / "discovery" / "runs"
WORKER_LOCK = ROOT / "data" / ".discovery-worker"


def _event(task_id: str, stage: str, message: str, **details) -> None:
    append_task_events(task_id, [{"stage": stage, "message": message, **details}])


def _wait_unpaused(task_id: str) -> bool:
    while True:
        with connect() as con:
            row = con.execute("SELECT status,paused FROM tasks WHERE id=?", (task_id,)).fetchone()
        if row is None or row["status"] in {"cancelled", "failed", "completed", "completed_with_errors"}:
            return False
        if not row["paused"]:
            return True
        time.sleep(0.5)


def _candidate_record(candidate: dict) -> dict:
    source_url = candidate.get("source_url") or candidate.get("search_page_url")
    evidence = [{"url": source_url, "relation": "discovery_source"}] if source_url else []
    if candidate.get("career_url"):
        evidence.append({"url": candidate["career_url"], "relation": "unverified_recruitment_result"})
    return {
        "name": candidate["name"],
        "aliases": candidate.get("aliases") or [],
        "website": candidate.get("website"),
        "career_url": candidate.get("career_url"),
        "source_url": source_url,
        "source": candidate.get("source") or "public_web_discovery; pending verification",
        "verification_status": "pending_verification",
        "industry_group": candidate.get("industry_group"),
        "discovery_evidence": evidence,
    }


def _verified_configs() -> dict[str, dict]:
    result = {}
    for path in CONFIG_DIR.glob("*.json"):
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if config.get("verified_for_collection") is True:
            result[str(config.get("company_name") or config.get("name") or path.stem)] = config
    return result


def _collect_matching(name: str, config: dict, task_id: str) -> dict:
    """Use the configured Lexmount adapter and the standard shared importer."""
    from collector import collect_company
    from scripts.import_collection_batch import integrate

    _event(task_id, "collection_started", "核验配置匹配，调用现有采集器", agent="collector", company=name,
           adapter=config.get("adapter"))
    jobs = collect_company(config)
    for job in jobs:
        job.setdefault("collection_method", config.get("adapter") or "browser")
    batch = {
        "company": name,
        "source_url": config.get("career_url") or config.get("url"),
        "collection": {
            "pages_read": 1,
            "reported_total": len(jobs),
            "page_counts": [len(jobs)],
            "adapter": config.get("adapter"),
            "collector": "discovery.worker",
        },
        "jobs": jobs,
        "review_candidates": [],
    }
    result = integrate(batch)
    _event(task_id, "collection_persisted", "采集结果已通过统一岗位导入器写入", agent="collector",
           company=name, result=result)
    return result


def run_task(task: dict) -> dict:
    task_id = task["id"]
    config_values = dict(task.get("config") or {})
    prior_strategy = get_discovery_strategy()
    saved_scores = prior_strategy.get("prior_channel_scores") or {}
    saved_scores.update(config_values.get("prior_channel_scores") or {})
    if saved_scores:
        config_values["prior_channel_scores"] = saved_scores
    saved_terms = prior_strategy.get("expansion_terms") or []
    requested_terms = config_values.get("expansion_terms") or []
    if saved_terms or requested_terms:
        config_values["expansion_terms"] = list(dict.fromkeys([*saved_terms, *requested_terms]))
    config = SearchConfig.from_dict(config_values)
    errors: list[dict] = []
    summary = {"candidates": 0, "inserted": 0, "updated": 0, "collected": 0, "jobs_inserted": 0}
    trail = []
    try:
        if not claim_discovery_task(task_id):
            return {"id": task_id, "status": "not_claimed"}
        trail.append({"stage": "planner_started", "message": "按预算生成地区、行业与公开来源搜索计划", "agent": "discovery_planner"})
        if not _wait_unpaused(task_id):
            return {"id": task_id, "status": "stopped"}
        trail.append({"stage": "search_started", "message": "使用 Lexmount WebFetch 搜索公开网页", "agent": "candidate_discovery"})
        append_task_events(task_id, trail)
        result = run_search(config)
        next_strategy = {
            "prior_channel_scores": result.get("channel_scores") or {},
            "expansion_terms": list(dict.fromkeys([*saved_terms, *result.get("expansion_terms", [])]))[-100:],
            "last_channel_metrics": result.get("channel_metrics") or {},
            "last_run_at": datetime.now(timezone.utc).isoformat(),
        }
        save_discovery_strategy(next_strategy)
        trail = [{"stage": "search_finished", "message": "搜索完成；候选仍需企业与招聘入口核验", "agent": "candidate_discovery",
                  "queries": result["queries_executed"], "results": result["results_observed"],
                  "candidate_count": len(result["candidates"])}]
        if not _wait_unpaused(task_id):
            return {"id": task_id, "status": "stopped"}
        records = [_candidate_record(item) for item in result["candidates"]]
        summary["candidates"] = len(records)
        if records:
            trail.append({"stage": "dedupe_started", "message": "与完整企业目录按名称、别名、官网及 ATS 租户去重", "agent": "company_verifier"})
            append_task_events(task_id, trail)
            write = upsert_companies(records)
            summary["inserted"] = write["inserted"]
            summary["updated"] = write["updated"]
            trail = [{"stage": "candidates_persisted", "message": "候选线索已写入统一企业目录并标记待验证",
                      "agent": "company_verifier", "write_result": write}]
        RUN_DIR.mkdir(parents=True, exist_ok=True)
        run_path = RUN_DIR / f"{task_id}.json"
        run_path.write_text(json.dumps({"task_id": task_id, "created_at": datetime.now(timezone.utc).isoformat(),
                                        "search_result": result}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        try:
            evidence_path = str(run_path.relative_to(ROOT)).replace("\\", "/")
        except ValueError:
            evidence_path = str(run_path)
        append_task_events(task_id, trail + [{"stage": "evidence_saved", "message": "查询与候选证据已保存", "path": evidence_path}])

        # Discovery output never promotes a company. Job collection is available
        # only when the same canonical name already has an approved site config.
        verified_configs = _verified_configs()
        requested = task.get("companies") or []
        if requested:
            collect_names = [name for name in requested if name in verified_configs]
        else:
            candidate_names = {record["name"] for record in records}
            collect_names = [name for name in verified_configs if name in candidate_names]
        for name in collect_names:
            if not _wait_unpaused(task_id):
                return {"id": task_id, "status": "stopped"}
            for attempt in range(1, 3):
                try:
                    collected = _collect_matching(name, verified_configs[name], task_id)
                    summary["collected"] += collected["main_input"]
                    summary["jobs_inserted"] += collected["main_database"]["inserted"]
                    break
                except Exception as exc:
                    if attempt == 2:
                        errors.append({"company": name, "error": str(exc)[:500], "attempts": attempt})
                    else:
                        time.sleep(1)
        status = "completed_with_errors" if errors else "completed"
        finish_discovery_task(task_id, status, summary, errors)
        return {"id": task_id, "status": status, "summary": summary, "errors": errors, "evidence": str(run_path)}
    except Exception as exc:
        errors.append({"stage": "worker", "error": str(exc)[:500]})
        finish_discovery_task(task_id, "failed", summary, errors)
        return {"id": task_id, "status": "failed", "summary": summary, "errors": errors}


def work_once() -> dict | None:
    init_db()
    queued = [row for row in list_tasks("discovery", 200) if row["status"] == "queued" and not row.get("paused")]
    if not queued:
        return None
    return run_task(queued[-1])


def main() -> None:
    parser = argparse.ArgumentParser(description="Process queued company-discovery tasks")
    parser.add_argument("--once", action="store_true", help="process one task and exit")
    parser.add_argument("--poll-seconds", type=float, default=3.0)
    args = parser.parse_args()
    if args.poll_seconds < 0.25:
        parser.error("--poll-seconds must be at least 0.25")
    with _directory_lock(WORKER_LOCK):
        requeue_running_discovery_tasks()
        while True:
            try:
                result = work_once()
            except KeyboardInterrupt:
                with connect() as con:
                    active = con.execute("SELECT id FROM tasks WHERE task_type='discovery' AND status='running' LIMIT 1").fetchone()
                if active:
                    requeue_discovery_task(active["id"], "收到中断信号，任务返回队列以便续跑")
                raise
            if result:
                print(json.dumps(result, ensure_ascii=False))
            if args.once:
                break
            if result is None:
                time.sleep(args.poll_seconds)


if __name__ == "__main__":
    main()
