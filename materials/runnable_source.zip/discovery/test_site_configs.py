import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_galbot_moka_config_uses_only_confirmed_urls():
    config = json.loads((ROOT / "configs" / "sites" / "galbot.json").read_text(encoding="utf-8"))
    run = json.loads((ROOT / "evidence" / "collector" / "galbot_moka_run.json").read_text(encoding="utf-8"))
    metadata = run["metadata"]
    assert config["company_website"] == metadata["company_website"]
    assert config["career_url"] == metadata["career_url"]
    assert config["career_url"].endswith("#/jobs?project=100130135")
    assert config["adapter"] == metadata["adapter"] == "mokahr_campus"
    assert config["verified_for_collection"] is True
    assert metadata["raw_card_count"] == config["page_size"] == 9
    assert config["evidence"] == "evidence/collector/galbot_moka_run.json"
