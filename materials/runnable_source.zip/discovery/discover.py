"""Import the user workbook and probe recruitment links with Lexmount WebFetch.

The workbook is the only permitted seed. Probing never leaves a seed host.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag

from discovery.catalog import merge_companies

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_XLSX = ROOT.parent / "国内互联网及科技企业招聘官网清单_51家.xlsx"
DEFAULT_CLI = Path(r"C:\Users\Lenovo\.agents\skills\lexmount-webfetch\bin\webfetch-cli.exe")
SIGNALS = ("招聘", "实习", "校园", "岗位", "职位", "career", "intern", "job", "campus", "join")


def import_workbook(path: Path = DEFAULT_XLSX) -> list[dict]:
    import openpyxl

    sheet = openpyxl.load_workbook(path, read_only=True, data_only=True).active
    companies = []
    seen = set()
    for row in sheet.values:
        if not row or not isinstance(row[0], int) or len(row) < 5:
            continue
        url = str(row[4] or "").strip()
        name = str(row[2] or "").strip()
        parsed = urlparse(url)
        if not name or parsed.scheme not in ("http", "https") or not parsed.hostname:
            continue
        key = (name.casefold(), parsed.hostname.lower())
        if key in seen:
            continue
        seen.add(key)
        companies.append({
            "name": name,
            "website": None,  # Workbook supplies career URLs, not company websites.
            "website_inferred_from_career_host": False,
            "career_url": url,
            "source": path.name,
            "verification_status": "seed_unverified",
            "industry_group": str(row[1] or "").strip(),
            "business": str(row[3] or "").strip(),
        })
    return companies


class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links: list[tuple[str, str]] = []
        self.href = ""
        self.text = ""

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self.href = dict(attrs).get("href", "")
            self.text = ""

    def handle_data(self, data):
        if self.href:
            self.text += data

    def handle_endtag(self, tag):
        if tag == "a" and self.href:
            self.links.append((self.href, re.sub(r"\s+", " ", self.text).strip()))
            self.href = self.text = ""


def candidate_links(html: str, base_url: str, allowed_host: str) -> list[dict]:
    parser = LinkParser()
    parser.feed(html)
    candidates = []
    seen = set()
    for href, label in parser.links:
        url = urldefrag(urljoin(base_url, href))[0]
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or parsed.hostname != allowed_host:
            continue
        if url in seen or not any(s in (label + " " + url).lower() for s in SIGNALS):
            continue
        seen.add(url)
        candidates.append({"url": url, "label": label})
    return candidates


def webfetch(command: str, url: str, cli: Path = DEFAULT_CLI) -> dict:
    if not cli.exists():
        raise FileNotFoundError(f"WebFetch CLI unavailable: {cli}")
    proc = subprocess.run(
        [str(cli), command, "--url", url, "--format", "json"],
        capture_output=True, text=True, encoding="utf-8", timeout=90, check=False,
    )
    if proc.returncode:
        raise RuntimeError(f"WebFetch {command} exited {proc.returncode}: {proc.stderr[:300]}")
    result = json.loads(proc.stdout)
    if result.get("error"):
        raise RuntimeError(str(result["error"]))
    return result


def probe(company: dict, cli: Path = DEFAULT_CLI) -> dict:
    url = company["career_url"]
    host = urlparse(url).hostname
    dump = webfetch("dump-dom", url, cli)
    final_url = dump.get("final_url") or url
    # A cross-host redirect can establish the seed landing page, but no new
    # off-host candidate is followed automatically.
    links = candidate_links(dump.get("html") or "", final_url, host)
    return {
        "company": company["name"], "seed_url": url,
        "final_url": final_url, "request_id": dump.get("request_id"),
        "dom_id": dump.get("dom_id"), "status_code": dump.get("status_code"),
        "engine": dump.get("engine"), "candidate_links": links,
        "jobs_confirmed": 0,
    }


def extract_summary(company: dict, cli: Path = DEFAULT_CLI) -> dict:
    result = webfetch("extract", company["career_url"], cli)
    content = result.get("main_text") or ""
    return {
        "company": company["name"], "seed_url": company["career_url"],
        "final_url": result.get("final_url"), "request_id": result.get("request_id"),
        "dom_id": result.get("dom_id"), "status_code": result.get("status_code"),
        "engine": result.get("engine"), "title": result.get("title"),
        "text_length": len(content), "text_excerpt": content[:1200],
        "jobs_confirmed": 0,
        "note": "Excerpt alone is not sufficient to verify internship job records.",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--xlsx", type=Path, default=DEFAULT_XLSX)
    ap.add_argument("--candidates", type=Path, help="JSON list of agent-discovered company candidates")
    ap.add_argument("--apply", action="store_true", help="write candidate changes to the shared company directory")
    ap.add_argument("--probe", help="Company name from workbook; invokes Lexmount WebFetch")
    ap.add_argument("--extract", help="Company name from workbook; saves a WebFetch extraction summary")
    ap.add_argument("--cli", type=Path, default=DEFAULT_CLI)
    args = ap.parse_args()
    output = ROOT / "data" / "companies.json"
    if args.candidates:
        candidates = json.loads(args.candidates.read_text(encoding="utf-8"))
        if not isinstance(candidates, list):
            raise SystemExit("Candidate input must be a JSON list")
        result = merge_companies(candidates, output, apply=args.apply)
        print(json.dumps(result, ensure_ascii=False))
        return

    companies = import_workbook(args.xlsx)
    # The workbook remains the original seed. Merge it so an ordinary discovery
    # refresh cannot erase subsequently verified companies from the directory.
    seed_candidates = [
        {
            **company,
            "source_url": company["career_url"],
            "evidence": [{"url": company["career_url"], "relation": "seed_recruitment_entry"}],
        }
        for company in companies
    ]
    result = merge_companies(seed_candidates, output, apply=True)
    print(json.dumps({"seed_companies": len(companies), **result}, ensure_ascii=False))
    if args.probe:
        company = next((x for x in companies if x["name"] == args.probe), None)
        if not company:
            raise SystemExit(f"Company not found in workbook: {args.probe}")
        result = probe(company, args.cli)
        evidence = ROOT / "evidence" / "discovery" / f"{args.probe}.json"
        evidence.parent.mkdir(parents=True, exist_ok=True)
        evidence.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"evidence": str(evidence), "candidate_links": len(result["candidate_links"])}, ensure_ascii=False))
    if args.extract:
        company = next((x for x in companies if x["name"] == args.extract), None)
        if not company:
            raise SystemExit(f"Company not found in workbook: {args.extract}")
        result = extract_summary(company, args.cli)
        evidence = ROOT / "evidence" / "discovery" / f"{args.extract}-extract.json"
        evidence.parent.mkdir(parents=True, exist_ok=True)
        evidence.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"evidence": str(evidence), "text_length": result["text_length"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
