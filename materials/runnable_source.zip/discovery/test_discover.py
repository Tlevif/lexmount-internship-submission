import unittest

from discovery.discover import candidate_links, import_workbook


class DiscoveryTests(unittest.TestCase):
    def test_workbook_seed_and_provenance(self):
        companies = import_workbook()
        self.assertEqual(len(companies), 51)
        self.assertEqual(len({c["career_url"] for c in companies}), 51)
        self.assertTrue(all(c["verification_status"] == "seed_unverified" for c in companies))
        self.assertTrue(all(c["website"] is None for c in companies))

    def test_only_same_host_job_links(self):
        html = '<a href="/jobs/intern">实习</a><a href="https://elsewhere.test/jobs">岗位</a>'
        links = candidate_links(html, "https://example.test/careers", "example.test")
        self.assertEqual(links, [{"url": "https://example.test/jobs/intern", "label": "实习"}])


if __name__ == "__main__":
    unittest.main()
