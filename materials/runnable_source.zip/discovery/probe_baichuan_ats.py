"""Verify Baichuan's own link to its ATS and reuse a WebFetch DOM ID.

Usage: python -m discovery.probe_baichuan_ats --dom-id <id from dump-dom>
The DOM ID is deliberately supplied from an actual preceding call, never guessed.
"""

import argparse
import json
import re
import subprocess
from pathlib import Path

from bs4 import BeautifulSoup

from discovery.discover import DEFAULT_CLI, ROOT, webfetch

SOURCE = "https://careers.baichuan-inc.com/"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dom-id", required=True)
    parser.add_argument("--cli", type=Path, default=DEFAULT_CLI)
    args = parser.parse_args()

    source = webfetch("dump-dom", SOURCE, args.cli)
    soup = BeautifulSoup(source.get("html") or "", "html.parser")
    internship_link = next(
        (a.get("href") for a in soup.select("a[href]") if "日常实习招聘" in a.get_text(" ", strip=True)),
        None,
    )
    if not internship_link:
        raise RuntimeError("Baichuan homepage no longer links to a daily internship page")
    proc = subprocess.run(
        [str(args.cli), "extract", "--dom-id", args.dom_id, "--format", "json"],
        capture_output=True, text=True, encoding="utf-8", timeout=90, check=True,
    )
    result = json.loads(proc.stdout)
    content = result.get("main_text") or ""
    titles = list(dict.fromkeys(re.findall(r"(【日常实习】.{2,90}?) 北京 实习", content)))
    output = {
        "source_page": SOURCE,
        "source_request_id": source.get("request_id"),
        "official_internship_link": internship_link,
        "ats_dom_id_reused": args.dom_id,
        "ats_extract_request_id": result.get("request_id"),
        "ats_status_code": result.get("status_code"),
        "ats_final_url": result.get("final_url"),
        "reported_listing_count": 6 if "开启新的工作（6）" in content else None,
        "observed_titles": titles,
        "observed_city": "北京" if titles else None,
        "detail_urls_verified": [],
        "collection_ready": False,
        "reason": "WebFetch extraction shows job text, but exposes no stable detail URL; raw DOM is an app shell without job cards.",
    }
    path = ROOT / "evidence" / "discovery" / "baichuan-ats-domreuse.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"evidence": str(path), "titles": len(titles), "request_id": result.get("request_id")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
