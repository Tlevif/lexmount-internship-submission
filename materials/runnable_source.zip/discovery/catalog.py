"""Evidence checks and idempotent updates for the shared company directory.

Discovery agents may exchange candidate dictionaries, but this module is the
single path that promotes candidates into ``data/companies.json``.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
COMPANIES_PATH = ROOT / "data" / "companies.json"
ATS_HOSTS = {
    "app.mokahr.com", "jobs.feishu.cn", "feishu.cn", "liepin.com",
    "kanzhun.com", "beisen.com", "northstarhr.com",
}
VERIFIED_STATES = {"verified", "recruitment_verified", "job_verified", "verified_for_collection"}


def _normalize_name(value: str) -> str:
    value = (value or "").casefold().strip()
    value = re.sub(r"[\s·•,，.。()（）\[\]【】_-]+", "", value)
    for suffix in ("股份有限公司", "有限责任公司", "有限公司", "集团", "公司"):
        if value.endswith(suffix):
            value = value[: -len(suffix)]
            break
    return value


def _host(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urlparse(value if "://" in value else "https://" + value)
    host = (parsed.hostname or "").lower().rstrip(".")
    return host.removeprefix("www.") or None


def _valid_http_url(value: str | None) -> bool:
    try:
        parsed = urlparse(value or "")
        return parsed.scheme in {"http", "https"} and bool(parsed.hostname)
    except ValueError:
        return False


def validate_candidate(candidate: dict) -> tuple[bool, list[str]]:
    """Return whether a candidate has enough provenance for explicit promotion.

    ``evidence`` is a list of ``{url, relation}`` records. Verified records
    require evidence linking the company to its official site and its careers
    entry. A search-result URL alone only supports a pending candidate.
    """
    errors: list[str] = []
    if not str(candidate.get("name", "")).strip():
        errors.append("missing company name")
    if not _valid_http_url(candidate.get("source_url")):
        errors.append("source_url must be an HTTP(S) evidence page")
    if not _valid_http_url(candidate.get("career_url")):
        errors.append("career_url must be an HTTP(S) page")
    website = candidate.get("website")
    if website and not _valid_http_url(website):
        errors.append("website must be an HTTP(S) URL")
    evidence = candidate.get("evidence") or []
    valid_evidence = [e for e in evidence if isinstance(e, dict) and _valid_http_url(e.get("url"))]
    if not valid_evidence:
        errors.append("at least one evidence URL is required")
    state = candidate.get("verification_status", "candidate")
    if state in VERIFIED_STATES:
        relations = {e.get("relation") for e in valid_evidence}
        if not website:
            errors.append("verified company requires its official website")
        if "official_company_site" not in relations:
            errors.append("verified company requires official_company_site evidence")
        if "official_recruitment_link" not in relations:
            errors.append("verified company requires official_recruitment_link evidence")
    elif state not in {"candidate", "pending_verification", "seed_unverified"}:
        errors.append(f"unsupported verification_status: {state}")
    return not errors, errors


def _identity_match(existing: dict, candidate: dict) -> bool:
    candidate_names = {_normalize_name(candidate.get("name", ""))}
    candidate_names.update(_normalize_name(x) for x in candidate.get("aliases", []) if x)
    existing_names = {_normalize_name(existing.get("name", ""))}
    existing_names.update(_normalize_name(x) for x in existing.get("aliases", []) if x)
    if candidate_names & existing_names:
        return True
    candidate_domains = {_host(candidate.get("website"))}
    existing_domains = {_host(existing.get("website"))}
    candidate_domains.discard(None)
    existing_domains.discard(None)
    candidate_domains.update(_host(x) for x in candidate.get("official_domains", []) if x)
    existing_domains.update(_host(x) for x in existing.get("official_domains", []) if x)
    candidate_domains.discard(None)
    existing_domains.discard(None)
    return bool(candidate_domains & existing_domains)


def _merge(existing: dict, candidate: dict) -> dict:
    """Add supported discovery facts without downgrading established records."""
    merged = dict(existing)
    for key in ("website", "career_url", "industry_group", "business"):
        if candidate.get(key) and not merged.get(key):
            merged[key] = candidate[key]
    aliases = list(dict.fromkeys([*(merged.get("aliases") or []), *(candidate.get("aliases") or [])]))
    if aliases:
        merged["aliases"] = aliases
    evidence = list(merged.get("discovery_evidence") or [])
    for item in candidate.get("evidence") or []:
        if item not in evidence:
            evidence.append(item)
    if candidate.get("source_url") and not any(x.get("url") == candidate["source_url"] for x in evidence):
        evidence.append({"url": candidate["source_url"], "relation": "discovery_source"})
    if evidence:
        merged["discovery_evidence"] = evidence
    state_rank = {"candidate": 0, "pending_verification": 0, "seed_unverified": 0,
                  "verified": 1, "recruitment_verified": 2, "verified_for_collection": 2,
                  "job_verified": 3}
    if state_rank.get(candidate.get("verification_status"), 0) > state_rank.get(merged.get("verification_status"), 0):
        merged["verification_status"] = candidate["verification_status"]
    return merged


@contextmanager
def _directory_lock(path: Path):
    """Serialize directory writers across processes on Windows and POSIX."""
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = open(lock_path, "a+b")
    try:
        if os.name == "nt":
            import msvcrt

            while True:
                try:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(0.05)
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        if os.name == "nt":
            import msvcrt

            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            except OSError:
                pass
        else:
            import fcntl

            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def merge_companies(candidates: list[dict], path: Path = COMPANIES_PATH, *, apply: bool = False) -> dict:
    """Validate, deduplicate and optionally upsert into the formal directory.

    Dry run is the default. The write path re-reads under a process lock and
    atomically replaces the same JSON file consumed by existing services.
    """
    prepared: list[dict] = []
    rejected: list[dict] = []
    for candidate in candidates:
        valid, errors = validate_candidate(candidate)
        if not valid:
            rejected.append({"name": candidate.get("name"), "errors": errors})
            continue
        # ATS tenants are not corporate identity domains; avoid treating a
        # shared provider hostname as proof that two employers are duplicates.
        record = dict(candidate)
        career_host = _host(record.get("career_url"))
        website_host = _host(record.get("website"))
        if career_host and career_host in ATS_HOSTS and not website_host:
            record["website_inferred_from_career_host"] = False
        prepared.append(record)

    if apply:
        # All production writes use the platform's single company-directory
        # writer. This module adds stricter evidence validation and dry-run
        # analysis, while app.companies owns locking and atomic persistence.
        from app.companies import upsert_companies

        records = []
        for candidate in prepared:
            item = {key: value for key, value in candidate.items() if key != "evidence"}
            item["discovery_evidence"] = candidate.get("evidence", [])
            item["source"] = candidate.get("source") or candidate["source_url"]
            records.append(item)
        write_result = upsert_companies(records, path=path)
        with path.open("r", encoding="utf-8") as source:
            total = len(json.load(source))
        return {
            "applied": True,
            "directory": str(path),
            "total": total,
            "added": [result["name"] for result in write_result["items"] if result["action"] == "inserted"],
            "updated": [result["name"] for result in write_result["items"] if result["action"] == "updated"],
            "duplicates": [result["name"] for result in write_result["items"] if result["action"] == "unchanged"],
            "rejected": rejected,
            "write_result": write_result,
        }

    with _directory_lock(path):
        existing = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
        if not isinstance(existing, list):
            raise ValueError(f"Company directory must be a JSON list: {path}")
        result = [dict(row) for row in existing]
        added, updated, duplicates = [], [], []
        for candidate in prepared:
            match = next((i for i, row in enumerate(result) if _identity_match(row, candidate)), None)
            if match is not None:
                before = result[match]
                after = _merge(before, candidate)
                if after != before:
                    result[match] = after
                    updated.append(candidate["name"])
                else:
                    duplicates.append(candidate["name"])
            else:
                new_record = {k: v for k, v in candidate.items() if k not in {"evidence"}}
                new_record["discovery_evidence"] = candidate.get("evidence", [])
                new_record["source"] = candidate.get("source") or candidate["source_url"]
                result.append(new_record)
                added.append(candidate["name"])
        if apply and (added or updated):
            path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
            try:
                with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as output:
                    json.dump(result, output, ensure_ascii=False, indent=2)
                    output.write("\n")
                    output.flush()
                    os.fsync(output.fileno())
                os.replace(temp_name, path)
            finally:
                if os.path.exists(temp_name):
                    os.unlink(temp_name)
        return {
            "applied": apply,
            "directory": str(path),
            "total": len(result),
            "added": added if apply else [],
            "would_add": added if not apply else [],
            "updated": updated if apply else [],
            "would_update": updated if not apply else [],
            "duplicates": duplicates,
            "rejected": rejected,
        }
