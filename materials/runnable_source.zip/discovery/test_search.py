from discovery.search import SearchConfig, _company_name, build_queries, extract_search_results, parse_search_page, run_search


def test_query_planner_covers_city_industry_and_channel_and_respects_limit():
    config = SearchConfig.from_dict({
        "cities": ["北京", "上海", "深圳"],
        "industries": {"AI": ["大模型"], "SaaS": ["企业服务"]},
        "signals": {"ats": ["飞书招聘"], "directory": ["产业园企业名录"]},
    })
    queries = build_queries(config)
    assert len(queries) == 12
    assert {row["city"] for row in queries} == {"北京", "上海", "深圳"}
    assert {row["industry"] for row in queries} == {"AI", "SaaS"}
    assert {row["channel"] for row in queries} == {"ats", "directory"}


def test_search_result_parser_keeps_public_source_evidence_and_filters_noise():
    html = '''
      <a href="https://www.bing.com/search?q=foo">下一页</a>
      <a href="https://outside.example/">杭州人工智能科技有限公司招聘</a>
      <li class="b_algo"><h2><a href="https://newco.example/careers">新公司科技有限公司招聘官网</a></h2><p>AI Agent 团队招人</p></li>
      <a href="https://zhihu.com/question/123">知乎结果页面</a>
    '''
    results = extract_search_results(html, "https://www.bing.com/search?q=foo")
    assert len(results) == 1
    assert results[0]["career_url"] == "https://newco.example/careers"
    assert results[0]["search_page_url"].startswith("https://www.bing.com/")


def test_company_name_uses_clean_title_text():
    assert _company_name("加入 MiniMax | Join the Future of AGI") == "MiniMax"
    assert _company_name("北京 星云人工智能科技有限公司招聘信息") == "星云人工智能科技有限公司"


def test_official_ats_company_page_is_a_lead_with_tech_context():
    html = '''
    <li class="b_algo"><h2><a href="https://tenant.jobs.feishu.cn/index">加入 MiniMax</a></h2>
    <p>Join our AGI team. AI foundation model positions are open.</p></li>
    '''
    leads, _ = parse_search_page(html, "https://cn.bing.com/search?q=MiniMax", limit=10)
    assert len(leads) == 1
    assert _company_name(leads[0]["title"]) == "MiniMax"
    assert leads[0]["career_url"] == "https://tenant.jobs.feishu.cn/index"


def test_run_search_enforces_query_page_result_budgets_and_is_candidate_only():
    config = SearchConfig.from_dict({
        "cities": ["北京", "上海"],
        "industries": {"AI": ["大模型"], "SaaS": ["企业服务"]},
        "signals": {"ats": ["飞书招聘"], "directory": ["科技企业名录"]},
        "max_queries": 3,
        "max_results": 100,
        "depth": 2,
        "pages_per_query": 2,
        "delay_seconds": 0,
    })
    calls = []

    def fetch(url):
        calls.append(url)
        n = len(calls)
        html = f'<li class="b_algo"><h2><a href="https://company{n}.example/careers">企业{n}科技有限公司招聘</a></h2><p>AI Agent</p></li>'
        return {"html": html, "final_url": url}

    result = run_search(config, fetcher=fetch, sleep=lambda _: None)
    assert result["queries_executed"] <= 3
    assert result["pages_fetched"] <= 6
    assert len(calls) == result["pages_fetched"]
    assert result["status"] == "candidate_evidence_only"
    assert result["formal_directory_written"] is False
    assert result["candidates"]
    assert all(item["verification_status"] == "candidate" for item in result["candidates"])
    assert all(item["evidence"][0]["relation"] == "search_result" for item in result["candidates"])
    assert "AI Agent" in result["expansion_terms"]


def test_config_rejects_unbounded_or_invalid_values():
    try:
        SearchConfig.from_dict({"max_queries": 0})
    except ValueError as error:
        assert "budgets must be positive" in str(error)
    else:
        raise AssertionError("invalid budget was accepted")


def test_frontend_task_config_shape_is_normalized():
    config = SearchConfig.from_dict({
        "target_cities": ["北京", "深圳"],
        "industries": ["人工智能", "SaaS"],
        "search_budget": 7,
        "candidate_limit": 19,
    })
    assert config.cities == ["北京", "深圳"]
    assert config.industries == {"人工智能": ["人工智能"], "SaaS": ["SaaS"]}
    assert config.max_queries == 7
    assert config.max_results == 19


def test_government_tourism_and_generic_city_pages_are_not_company_candidates():
    html = '''
    <ol id="b_results">
      <li class="b_algo"><h2><a href="https://www.beijing.gov.cn/">北京市人民政府门户网站</a></h2><p>北京城市信息与科技政策</p></li>
      <li class="b_algo"><h2><a href="https://www.visitbeijing.com.cn/article/1">北京旅游攻略：30个好玩的地方</a></h2><p>旅游景点路线推荐</p></li>
      <li class="b_algo"><h2><a href="https://baike.baidu.com/item/beijing">北京市_百度百科</a></h2><p>北京城市介绍</p></li>
    </ol>
    '''
    leads, rejected = parse_search_page(html, "https://cn.bing.com/search?q=...", limit=20)
    assert leads == []
    assert len(rejected) == 3
    assert {item["reason"] for item in rejected} >= {
        "government_or_tourism_page", "generic_or_social_source",
    }
