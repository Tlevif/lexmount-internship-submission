"""Seed import and same-site recruitment entry discovery."""
