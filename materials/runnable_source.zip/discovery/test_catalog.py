"""Tests for the shared-directory promotion boundary."""

import json

from discovery.catalog import merge_companies, validate_candidate


def candidate(**overrides):
    record = {
        "name": "新锐科技（北京）有限公司",
        "website": "https://www.newtech.example/",
        "career_url": "https://newtech.example/careers",
        "source_url": "https://directory.example/company/newtech",
        "source": "公开企业目录",
        "verification_status": "verified",
        "evidence": [
            {"url": "https://www.newtech.example/about", "relation": "official_company_site"},
            {"url": "https://www.newtech.example/careers", "relation": "official_recruitment_link"},
        ],
    }
    record.update(overrides)
    return record


def test_verified_candidate_requires_official_site_and_recruitment_evidence():
    valid, errors = validate_candidate(candidate(evidence=[]))
    assert not valid
    assert any("official_company_site" in error for error in errors)
    assert any("official_recruitment_link" in error for error in errors)


def test_dry_run_does_not_modify_shared_directory(tmp_path):
    path = tmp_path / "companies.json"
    original = [{"name": "原有企业", "career_url": "https://old.example/jobs"}]
    path.write_text(json.dumps(original, ensure_ascii=False), encoding="utf-8")

    result = merge_companies([candidate()], path)

    assert result["would_add"] == ["新锐科技（北京）有限公司"]
    assert json.loads(path.read_text(encoding="utf-8")) == original


def test_upsert_is_idempotent_and_keeps_official_directory(tmp_path):
    path = tmp_path / "companies.json"
    path.write_text(json.dumps([{"name": "新锐科技", "career_url": "https://newtech.example/jobs"}], ensure_ascii=False), encoding="utf-8")

    company = candidate(aliases=["新锐科技"])
    first = merge_companies([company], path, apply=True)
    second = merge_companies([company], path, apply=True)
    stored = json.loads(path.read_text(encoding="utf-8"))

    assert first["added"] == []
    assert first["updated"] == ["新锐科技"]
    assert second["duplicates"] == ["新锐科技"]
    assert len(stored) == 1
    assert stored[0]["website"] == "https://www.newtech.example/"


def test_shared_ats_host_does_not_merge_different_companies(tmp_path):
    path = tmp_path / "companies.json"
    path.write_text("[]", encoding="utf-8")
    candidates = [
        candidate(name="甲公司", website=None, career_url="https://app.mokahr.com/campus-recruitment/a", verification_status="candidate"),
        candidate(name="乙公司", website=None, career_url="https://app.mokahr.com/campus-recruitment/b", verification_status="candidate"),
    ]
    result = merge_companies(candidates, path, apply=True)
    assert len(json.loads(path.read_text(encoding="utf-8"))) == 2
    assert result["added"] == ["甲公司", "乙公司"]
